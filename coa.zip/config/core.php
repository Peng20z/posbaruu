<?php

return [
    'db_connection_cookie' => env('DB_CONNECTION_COOKIE', 'db_connection'),
    'databases' => [
        'mysql' => [
            'driver' => 'mysql',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', 3306),
            'database' => env('DB_DATABASE', 'anonymous'),
            'username' => env('DB_USERNAME', 'root'),
            'password' => env('DB_PASSWORD', ''),
            'unix_socket' => env('DB_SOCKET', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'prefix_indexes' => true,
            'strict' => true,
            'engine' => null,
            'options' => extension_loaded('pdo_mysql') ? array_filter([
                PDO::MYSQL_ATTR_SSL_CA => env('MYSQL_ATTR_SSL_CA'),
            ]) : [],
        ],
        'mysql_secondary' => [
            'driver' => 'mysql',
            'host' => env('DB_SECONDARY_HOST', '127.0.0.1'),
            'port' => env('DB_SECONDARY_PORT', 3306),
            'database' => env('DB_SECONDARY_DATABASE', 'anonymous_secondary'),
            'username' => env('DB_SECONDARY_USERNAME', 'root'),
            'password' => env('DB_SECONDARY_PASSWORD', ''),
            'unix_socket' => env('DB_SECONDARY_SOCKET', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'prefix_indexes' => true,
            'strict' => true,
            'engine' => null,
            'options' => extension_loaded('pdo_mysql') ? array_filter([
                PDO::MYSQL_ATTR_SSL_CA => env('MYSQL_ATTR_SSL_CA'),
            ]) : [],
        ],
    ]
];
