@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('products.index') }}" class="btn btn-success" title="Back"><i
                            class="fa fa-arrow-left"></i> Back</a>
                        @can('product_uoms_create')
                            <a href="{{ route('products.uoms.create', $product) }}" class="btn btn-success" title="Create"><i
                                    class="fa fa-plus"></i>
                                Add Uom</a>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title"><strong>{{ $product->name }}</strong> Uom List</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Is Base</th>
                                            <th>Is Default</th>
                                            <th>Buy Price</th>
                                            <th>Sell Price</th>
                                            <th>Quantity</th>
                                            <th>Discount</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($product->uoms as $productUom)
                                            <tr>
                                                <td>{{ $productUom->id }}</td>
                                                <td>{{ $productUom->name }}</td>
                                                <td>{!! $productUom->pivot->is_base == true ? '<i class="fa fa-check"></i>' : '' !!}</td>
                                                <td>{!! $productUom->pivot->is_default == true ? '<i class="fa fa-check"></i>' : '' !!}</td>
                                                <td>{{ rupiah($productUom->pivot?->buy_price ?? 0) }}</td>
                                                <td>{{ rupiah($productUom->pivot?->sell_price ?? 0) }}</td>
                                                <td>{{ $productUom->pivot->quantity }}</td>
                                                <td>
                                                    @if (count($productUom->pivot?->discounts ?? []) > 0)
                                                        <ul>
                                                            @foreach ($productUom->pivot?->discounts ?? [] as $qty => $price)
                                                                <li>{{ $qty . ' => ' . rupiah($price) }}</li>
                                                            @endforeach
                                                        </ul>
                                                    @else
                                                        0
                                                    @endif
                                                </td>
                                                <td>
                                                    <a href="{{ route('products.uoms.edit', [$product->id, $productUom->pivot->id]) }}"
                                                        class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
