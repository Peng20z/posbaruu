@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('customer-groups.products.index', $customerGroup) }}" class="btn btn-success"
                            title="Back"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <form method="post"
                            action="{{ route('customer-groups.products.update', [$customerGroup, $customerGroupProduct]) }}"
                            class="form-loading">
                            @csrf
                            @method('PUT')
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Edit Product Uom</h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Product</label>
                                        <input type="text" value="{{ $customerGroupProduct->product?->name }}"
                                            class="form-control @error('name') is-invalid @enderror" placeholder="Name"
                                            required readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Uom</label>
                                        <input type="text" value="{{ $customerGroupProduct->uom?->name }}"
                                            class="form-control @error('name') is-invalid @enderror" placeholder="Name"
                                            required readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Sell Price</label>
                                        <input name="sell_price" type="text" id="sell_price"
                                            value="{{ $customerGroupProduct->sell_price }}"
                                            class="form-control price-format @error('sell_price') is-invalid @enderror"
                                            placeholder="Sell Price" required>
                                        @error('sell_price')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Discounts</h3>
                                </div>
                                <div class="card-body">
                                    <button id="btn-add" type="button" class="btn btn-success mb-2"><i
                                            class="fa fa-plus"></i> Add Discount</button>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Qty</th>
                                                    <th>Discount Input</th>
                                                    <th>Is Percentage</th>
                                                    <th style="background-color: #D3D3D3">Nominal</th>
                                                    <th style="background-color: #D3D3D3">Percentage</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="discount-body">
                                                @forelse ($customerGroupProduct?->discounts ?? [] as $qty => $price)
                                                    <tr>
                                                        <td>
                                                            <input type="number" name="discounts[qty][]"
                                                                class="form-control" min="0"
                                                                value="{{ $qty }}">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="discounts[price][]"
                                                                class="form-control price-format input-product-discount"
                                                                min="0" value="{{ $price }}">
                                                        </td>
                                                        <td>
                                                            <input type="hidden" value="0"
                                                                name="discounts[is_percentage][]" class="checkbox">
                                                            <input type="checkbox" class="form-control">
                                                        </td>
                                                        <td style="background-color: #D3D3D3">
                                                            <span class="nominal-calc price-format">{{ $price ?? '' }}</span>
                                                        </td>
                                                        <td style="background-color: #D3D3D3">
                                                            <span
                                                                class="percentage-calc">{{ $customerGroupProduct->sell_price ? ($price / $customerGroupProduct->sell_price) * 100 . '%' : '' }}</span>
                                                        </td>
                                                        <td><button type="button" class="btn-delete btn btn-danger"><i
                                                                    class="fa fa-trash"></i></button></td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td>
                                                            <input type="number" name="discounts[qty][]"
                                                                class="form-control" min="0" value="0">
                                                        </td>
                                                        <td>
                                                            <input type="text" name="discounts[price][]"
                                                                class="form-control price-format input-product-discount"
                                                                min="0" value="0">
                                                        </td>
                                                        <td>
                                                            <input type="hidden" value="0"
                                                                name="discounts[is_percentage][]" class="checkbox">
                                                            <input type="checkbox" class="form-control">
                                                        </td>
                                                        <td style="background-color: #D3D3D3">
                                                            <span class="nominal-calc price-format"></span>
                                                        </td>
                                                        <td style="background-color: #D3D3D3">
                                                            <span class="percentage-calc"></span>
                                                        </td>
                                                        <td></td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
        </section>
    </div>
@endsection

@push('js')
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('.price-format').priceFormat({
                prefix: '',
                centsLimit: 0,
                thousandsSeparator: '.'
            });

            $('body').on('keyup', '.input-product-discount', function() {
                discount = unformatPrice($(this).val());
                let sellPrice = unformatPrice(document.getElementById("sell_price").value);
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let percentage = (discount / sellPrice * 100).toFixed(2)
                let isPercentage = parent.find('.checkbox').val();
                console.log(isPercentage);
                if (isPercentage == 1) {

                    parent.find('.nominal-calc').text(Math.round(discount * sellPrice / 100))
                    parent.find('.percentage-calc').text(discount + '%')
                    initPriceFormat();
                } else {
                    parent.find('.nominal-calc').text(discount)
                    parent.find('.percentage-calc').text(percentage + '%')
                    initPriceFormat();
                }

            });

            $('body').on('change', ':checkbox', function() {
                let sellPrice = unformatPrice(document.getElementById("sell_price").value);
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let discount = unformatPrice(parent.find('.input-product-discount').val());
                let percentage = (discount / sellPrice * 100).toFixed(2)

                if (this.checked == true) {
                    $(this).parent().find('.checkbox').val(1);

                    parent.find('.nominal-calc').text(Math.round(discount * sellPrice / 100))
                    parent.find('.percentage-calc').text(discount + '%')
                    initPriceFormat();
                } else {
                    $(this).parent().find('.checkbox').val(0);

                    parent.find('.nominal-calc').text(discount)
                    parent.find('.percentage-calc').text(percentage + '%')
                    initPriceFormat();
                }
            });

            let html = `<tr>
                            <td>
                                <input type="number" name="discounts[qty][]" class="form-control" min="0" value="0">
                            </td>
                            <td>
                                <input type="text" name="discounts[price][]"
                                class="form-control price-format input-product-discount"
                                min="0" value="0">
                            </td>
                            <td>
                                <input type="hidden" value="0"
                                    name="discounts[is_percentage][]" class="checkbox">
                                <input type="checkbox" class="form-control">
                            </td>
                            <td style="background-color: #D3D3D3">
                                <span class="nominal-calc price-format"></span>
                            </td>
                            <td style="background-color: #D3D3D3">
                                <span class="percentage-calc"></span>
                            </td>
                            <td>
                                <button type="button" class="btn-delete btn btn-danger"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>`;

            $('body').on('click', '.btn-delete', function() {
                $(this).parent().parent().remove();
            });

            $('#btn-add').click(function() {
                $('#discount-body').append(html)
            });
        });
    </script>
@endpush
