@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('purchase-orders.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('purchase-orders.update', $purchaseOrder) }}"
                                class="form-loading">
                                @csrf
                                @method('PUT')
                                <div class="card card-primary card-outline shadow">
                                    <div class="card-header">
                                        <h3 class="card-title">Purchase Order</h3>
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label class="required">Code</label>
                                            <input type="hidden" name="code"
                                                class="form-control @error('code') is-invalid @enderror"
                                                value="{{ $purchaseOrder->code }}">
                                            @error('code')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <input type="type" name="po_number"
                                                class="form-control @error('po_number') is-invalid @enderror"
                                                value="{{ $purchaseOrder->po_number }}">
                                            @error('po_number')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label class="required">Supplier</label>
                                            <select name="supplier_id" id="supplier_id"
                                                class="form-control select2 @error('supplier_id') is-invalid @enderror"
                                                required>
                                                @foreach ($suppliers as $id => $name)
                                                    <option value="{{ $id }}"
                                                        @if (old('supplier_id', $purchaseOrder->supplier_id) == $id) selected @endif>
                                                        {{ $name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('supplier_id')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label class="required">PO Terms</label>
                                            <select name="terms" id="terms"
                                                class="form-control select2 @error('terms') is-invalid @enderror" required>
                                                @foreach ($poTerms as $terms)
                                                    <option value="{{ $terms->value }}"
                                                        @if (old('terms', $purchaseOrder->terms) == $terms->value) selected @endif>
                                                        {{ $terms->value }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('terms')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label class="required">Description</label>
                                            <textarea name="description" id="description" rows="2" class="form-control">{{ old('description', $purchaseOrder->description) }}</textarea>
                                            @error('description')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="card card-primary card-outline shadow">
                                    <div class="card-header">
                                        <h3 class="card-title">Purchase Order Details</h3>
                                    </div>
                                    <div class="card-body">
                                        <label>Product</label>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Code</th>
                                                        <th>Product Name</th>
                                                        <th>Qty</th>
                                                        <th>Uom</th>
                                                        <th>Unit Price</th>
                                                        <th>Tax</th>
                                                        <th>Discount</th>
                                                        <th>Total Price</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody id="table-body">
                                                    @foreach ($purchaseOrder->details as $i => $detail)
                                                        <tr class="detail-row">
                                                            <input type="hidden"
                                                                name="items[{{ $i }}][product_id]"
                                                                class="input-product-id"
                                                                value="{{ $detail->product_id }}" />
                                                            <td>{{ $detail->product_id }}</td>
                                                            <td>{{ $detail->product?->name }}</td>
                                                            <td>
                                                                <input type="number"
                                                                    name="items[{{ $i }}][qty]"
                                                                    value="{{ $detail->qty }}"
                                                                    class="form-control input-product-qty" min="1" />
                                                            </td>
                                                            <td><select name="items[{{ $i }}][uom_id]"
                                                                    id="uom_id" class="form-control input-uom" required>
                                                                    @foreach ($detail->product->uoms as $uom)
                                                                        <option value="{{ $uom->id }}"
                                                                            @if (old('uom_id', $detail->uom_id) == $uom->id) selected @endif>
                                                                            {{ $uom->name }}</option>
                                                                    @endforeach
                                                                </select></td>
                                                            <td>
                                                                <div class="d-flex">
                                                                    <input type="text" value="{{ $detail->unit_price }}"
                                                                        name="items[{{ $i }}][unit_price]"
                                                                        class="form-control input-product-price"
                                                                        data-type="currency" min="0" />
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-toggle="modal"
                                                                        data-target="#mdlPriceHistory{{ $i }}"><i
                                                                            class="fa fa-history"></i></button>
                                                                    <div class="modal inmodal fade"
                                                                        id="mdlPriceHistory{{ $i }}"
                                                                        role="dialog" tabindex="-1" aria-hidden="true">
                                                                        <div class="modal-dialog modal-lg">
                                                                            <div class="modal-content">
                                                                                <div class="modal-body">
                                                                                    <label for="">History</label>
                                                                                    <br>
                                                                                    <table
                                                                                        class="table table-bordered table-hover">
                                                                                        <tr>
                                                                                            <th>Date</th>
                                                                                            <th>Unit Price</th>
                                                                                            <th>Discount</th>
                                                                                            <th>Total Price</th>
                                                                                        </tr>
                                                                                        @foreach ($detail->priceHistories as $priceHistory)
                                                                                            <tr class="price-history"
                                                                                                data-price={{ $priceHistory->unit_price }}
                                                                                                data-discount={{ $priceHistory->discount }}>
                                                                                                <td>{{ $priceHistory->created_at }}
                                                                                                </td>
                                                                                                <td class="price-format">
                                                                                                    {{ $priceHistory->unit_price }}
                                                                                                </td>
                                                                                                <td>{{ $priceHistory->discount }}%
                                                                                                </td>
                                                                                                <td class="price-format">
                                                                                                    {{ $priceHistory->unit_price * (100 - $priceHistory->discount) }}
                                                                                                </td>
                                                                                            </tr>
                                                                                        @endforeach
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td style="width: 5%">
                                                                <input type="checkbox"
                                                                    name="items[{{ $i }}][ppn]"
                                                                    class="form-control input-ppn"
                                                                    @if ($detail->tax > 0) checked @endif />
                                                            </td>
                                                            <td class="d-flex">
                                                                <input value="{{ $detail->discount }}"
                                                                    name="items[{{ $i }}][discount]"
                                                                    class="form-control input-discount" min="0" />%
                                                            </td>
                                                            <td>
                                                                <input type="text"
                                                                    value="{{ rupiah($detail->total_price) }}"
                                                                    class="form-control price-format input-product-total-price"
                                                                    min="0" readonly disabled />
                                                            </td>
                                                            <td>
                                                                <button type="button"
                                                                    class="btn btn-danger btn-sm btn-delete"><i
                                                                        class="fa fa-trash"></i></button>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="8" class="border-right-0 border-left-0">
                                                            <div class="form-group">
                                                                <label>Select Product</label>
                                                                <div class="d-flex">
                                                                    <select name="product_id" id="product_id"
                                                                        class="form-control w-75">
                                                                    </select>
                                                                    <button class="btn btn-primary ml-2" id="add-product"
                                                                        type="button"><i class="fa fa-plus"></i> Add
                                                                        Product</button>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7">Sub Total</th>
                                                        <th>
                                                            <input type="text" class="form-control price-format"
                                                                value="{{ rupiah($purchaseOrder->total_price + $purchaseOrder->additional_discount) }}"
                                                                id="sub-total-accumulation" readonly disabled>
                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="6">Additional Discount</th>
                                                        <th class="d-flex">
                                                            <input type="number" class="form-control" step="any"
                                                                name="additional_discount"
                                                                id="input-additional-discount-percentage"
                                                                value="{{ $purchaseOrder->additional_discount }}"
                                                                max="100">
                                                            <p class=""> %</p>
                                                        </th>
                                                        <th>
                                                            <input type="text" class="form-control"
                                                                data-type="currency"
                                                                value="{{ number_format(($purchaseOrder->additional_discount / 100) * $purchaseOrder->total_price, 2) ?? 0 }}"
                                                                id="input-additional-discount">
                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7">Grand Total</th>
                                                        <th>
                                                            <input type="text" class="form-control price-format"
                                                                value="{{ rupiah($purchaseOrder->total_price) }}"
                                                                id="total-price-accumulation" readonly disabled>
                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary" id="clickToSubmit">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            let selectedProducts = []; // buat nampung products yg sudah terpilih
            let selectedProductIds = []; // buat nampung id product yg sudah terpilih
            let i = {{ $i + 1 }};


            let supplierId = document.getElementById('supplier_id').value;
            async function initSelectedProducts() {
                @foreach ($purchaseOrder->details->pluck('product_id') as $productId)
                    selectedProducts.push(await getProduct('{{ $productId }}',
                        supplierId));
                @endforeach
            }
            initSelectedProducts()


            $("#clickToSubmit").on("keydown", function(e) {
                if (e.keyCode === 13) {
                    e.preventDefault();
                }
            });

            $('#product_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Select product',
                ajax: {
                    url: '{{ route('api.products.index') }}',
                    dataType: 'json',
                    delay: 300,
                    data: function(params) {
                        return {
                            'per_page': 30,
                            'select': 'id,name as text', // select2 only accept return data (id and text)
                            'filter[name]': params.term, // search term / search by nama product
                            'filter[ids]': selectedProductIds
                                .toString(), // search where id product not in
                            'filter[is_active]': 1,
                            page: params.page || params.current_page || 1
                        };
                    },
                    processResults: function(data, params) {
                        params.current_page = params.current_page || 1;
                        return {
                            results: data.data,
                            pagination: {
                                more: (params.current_page * 30) < data.total
                            }
                        };
                    },
                    autoWidth: true,
                    cache: true
                }
            });

            $('body').on('click', '.btn-delete', function() {
                $(this).parent().parent().remove();
            });

            $('#add-product').on('click', async function() {
                let productId = $('#product_id').val();

                if (productId) {
                    try {
                        let supplierId = document.getElementById('supplier_id').value;
                        let product = await getProduct(productId, supplierId);

                        let uomsSelectForm =
                            `<select name="items[${i}][uom_id]" class="form-control select2 input-product-uom_id" required>`;
                        $.each(product.uoms, function(i, uom) {
                            uomsSelectForm +=
                                `<option value="${uom.id}" ${uom.pivot.is_default && 'selected'} data-product_id="${product.id}">${uom.name}</option>`;
                        });
                        uomsSelectForm += `</select>`;

                        let priceHistories = ``;
                        $.each(product.priceHistory, function(index, value) {
                            let totalPrice = value.unit_price * (100 - value.discount);
                            priceHistories +=
                                `<tr class="price-history" data-price=${value.unit_price} data-discount=${value.discount}>
                                    <td>${value.created_at}</td>
                                    <td class="price-format">${value.unit_price}</td>
                                    <td>${value.discount}%</td>
                                    <td class="price-format">${totalPrice}</td>
                                </tr>`
                        });

                        let html = `<tr class="detail-row">
                            <input type="hidden" name="items[${i}][product_id]" class="input-product-id" value="${product.id}"/>
                            <td>${product.id}</td>
                            <td>${product.name}</td>
                            <td>
                                <input type="number" name="items[${i}][qty]" value="1" class="form-control input-product-qty" onfocus="this.select();" data-price="${product.buy_price}" min="1" />
                                </td>
                            <td>${uomsSelectForm}</td>
                            <td>
                                <div class="d-flex">
                                    <input value="${product.buy_price}" name="items[${i}][unit_price]" class="form-control input-product-price" data-type="currency" min="0"/>
                                    <button type="button" class="btn btn-secondary" data-toggle="modal"
                                        data-target="#mdlPriceHistory${i}"><i class="fa fa-history"></i></button>
                                        <div class="modal inmodal fade" id="mdlPriceHistory${i}" role="dialog" tabindex="-1"
                                            aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-body">
                                                        <label for="">History</label> <br>
                                                        <table class="table table-bordered table-hover">
                                                            <tr>
                                                                <th>Date</th>
                                                                <th>Unit Price</th>
                                                                <th>Discount</th>
                                                                <th>Total Price</th>
                                                            </tr>
                                                            ${priceHistories}
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <span class="error invalid-feedback">Sell price lower than capital price</span>
                                </div>
                            </td>
                            <td style="width: 5%">
                                <input type="checkbox" name="items[${i}][ppn]" class="form-control input-ppn" value="1"/>
                            </td>
                            <td class="d-flex">
                                <input type="number" step="any" name="items[${i}][discount]" class="form-control input-discount" max="100" value="0"/>%
                            </td>
                            <td>
                                <input type="text" value="${product.buy_price}" class="form-control input-product-total-price price-format" min="0" readonly disabled/>
                            </td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm btn-delete"><i
                                        class="fa fa-trash"></i></button>
                            </td>
                        </tr>`;
                        i++;
                        // cek kalo productnya sudah di insert ke table jangan di insert lagi
                        if (!selectedProductIds.includes(product.id.toString())) {
                            selectedProducts.push(
                                product
                            ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            // selectedProductIds.push(
                            //     productId
                            // ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            $('#table-body').append(html).find('.input-product-qty').focus();
                            $('#product_id').val('').change();
                            setTotalPriceAccumulation()

                            initPriceFormat();
                        }
                    } catch (error) {
                        toastr.error(error.message);
                    }
                }
            });

            $('body').on('click', '.price-history', function() {
                let price = $(this).data('price');
                let discount = $(this).data('discount');

                let parent = $(this).closest('.detail-row');
                parent.find('.input-product-price').val(price);
                parent.find('.input-discount').val(discount);
                $('.modal').modal('hide');

                setTotalPricePerProduct(parent, false);
            });

            $('body').on('change', '.input-product-qty', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            $('body').on('change', '.input-product-price', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            // fungsi untuk handle ketika ceklist ppn
            $('body').on('change', '.input-ppn', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                setTotalPricePerProduct(parent, false);
            });

            $('body').on('keyup', '.input-discount', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent, false);
            });

            $('body').on('change', '.input-product-uom_id', async function() {
                let selectedUomId = $(this).val();
                let productId = $(this).find(':selected').data('product_id');
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                try {
                    let supplierId = $('#supplier_id').val();
                    let productUom = await getProductUom(productId, selectedUomId, supplierId);

                    parent.find('.input-product-price').text(productUom.buy_price);
                    parent.find('.input-product-qty').data('price', productUom.buy_price);

                    setTotalPricePerProduct(parent);
                } catch (error) {
                    // handle jika get product nya error
                    toastr.error(error.message);
                }
            });

            // fungsi untuk hitung total akumulasi harga per product
            // fungsi ini akan dipanggil ketika +/- product, ceklist ppn, dan ganti uom
            async function setTotalPricePerProduct(parent) {
                let productId = parent.find('.input-product-id').val();
                let qty = parent.find('.input-product-qty').val();
                let selectedUomId = parent.find('.input-product-uom_id').val();


                let product = selectedProducts?.find(product => product.id == productId);
                let discount = parent.find('.input-discount').val();
                let price = unformatPrice(parent.find('.input-product-price').val());
                let totalPrice = (price - (discount / 100 * price)) * qty;

                // cek kalo pake ppn tambahin 11% dari harga
                if (parent.find('.input-ppn').is(':checked')) {
                    totalPrice = totalPrice + parseFloat(totalPrice * 0.11);
                }

                // set total price nya ke total price per product
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                parent.find('.input-product-total-price').val(customToFixed(totalPrice));

                initPriceFormat();
                setTotalPriceAccumulation();
            }

            $('body').on('change', '#input-additional-discount', function() {
                subTotal = unformatPrice($('#sub-total-accumulation').val());

                additionalDiscount = unformatPrice($(this).val());

                $('#input-additional-discount-percentage').val(customToFixed(additionalDiscount / subTotal *
                    100))

                setTotalPriceAccumulation();
            });

            $('body').on('change', '#input-additional-discount-percentage', function() {
                subTotal = unformatPrice($('#sub-total-accumulation').val());
                additionalDiscount = $(this).val();

                $('#input-additional-discount').val(customToFixed(additionalDiscount * subTotal / 100))
                setTotalPriceAccumulation();
            });

            // fungsi untuk hitung total akumulasi harga keseluruhan
            // fungsi ini akan dipanggil add product, hapus product, dan ketika fungsi setTotalPricePerProduct() dipanggil
            function setTotalPriceAccumulation() {
                let totalPrice = 0;

                // looping element total price per product, lalu di sum()
                $('.input-product-total-price').each(function(i) {
                    totalPrice += unformatPrice($(this).val());
                });

                // set total price nya ke total price keseluruhan
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                $('#sub-total-accumulation').val(customToFixed(totalPrice));

                let additionalDiscount = 0;
                additionalDiscountPercentage = $('#input-additional-discount-percentage').val() ?? 0;

                additionalDiscount = customToFixed(additionalDiscountPercentage * totalPrice / 100);
                $('#input-additional-discount').val(additionalDiscount);

                if (additionalDiscount > totalPrice) {
                    totalPrice = 0;
                } else {
                    totalPrice = totalPrice - additionalDiscount;
                }
                $('#total-price-accumulation').val(customToFixed(totalPrice));

                initPriceFormat();
            }


            function getProduct(productId, supplierId = null) {
                return new Promise((resolve, reject) => {
                    $.get('{{ url('api/products/') }}/' + productId +
                        '?supplierId=' + supplierId,
                        function(product) {
                            if (product) {
                                resolve(product);
                            } else {
                                reject(new Error('product not found'))
                            }
                        });
                });
            }

            function getProductUom(productId, uomId, supplierId = null) {
                return new Promise((resolve, reject) => {
                    $.get(`{{ url('api/products/get-price') }}/${productId}/${uomId}?supplierId=` +
                        supplierId,
                        function(res) {
                            if (res) {
                                resolve(res);
                            } else {
                                reject(new Error('product uom not found'))
                            }
                        });
                });
            }
        });
    </script>
@endpush
