@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('purchase-orders.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Purchase Order</h3>
                                <div class="card-tools">
                                    <div class="ml-auto">
                                        @if ($canAddToStock && $isSkipRo == true && $correctBook)
                                            <button class="btn btn-success" id="btn-add-to-stock" title="Back"><i
                                                    class="fas fa-plus"></i> Add To Stock </button>
                                        @endif
                                        @if (!$canAddToStock && $isSkipRo == true && $correctBook)
                                        <button class="btn btn-danger" id="btn-retrieve-stock" title="Back"><i
                                                class="fas fa-minus"></i> Retrieve Stock </button>
                                    @endif
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>ID</th>
                                        <td>{{ $purchaseOrder->id }}</td>
                                    </tr>
                                    <tr>
                                        <th>User</th>
                                        <td>{{ $purchaseOrder->user?->name ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Supplier</th>
                                        <td>{{ $purchaseOrder->supplier?->name ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Code</th>
                                        <td>{{ $purchaseOrder->po_number }}</td>
                                    </tr>
                                    <tr>
                                        <th>Terms</th>
                                        <td>{{ $purchaseOrder->terms ?? 'New Terms'}}</td>
                                    </tr>
                                    <tr>
                                        <th>Total Price</th>
                                        <td>{{ rupiah($purchaseOrder->total_price, true) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td>{{ $purchaseOrder->description }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Purchase Order Details</h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>Code</th>
                                                <th>Product Name</th>
                                                <th>Qty Received</th>
                                                <th>Total Qty</th>
                                                <th>Uom</th>
                                                <th>Unit Price</th>
                                                <th>Discount</th>
                                                <th>Total Price</th>
                                            </tr>
                                        </thead>
                                        <tbody id="table-body">
                                            @foreach ($purchaseOrder->details as $detail)
                                                <tr>
                                                    <td>{{ $detail->product?->id ?? '' }}</td>
                                                    <td>{{ $detail->product?->name ?? '' }}</td>
                                                    <td>{{ $detail->qtyReceived }}</td>
                                                    <td>{{ $detail->qty }}</td>
                                                    <td>{{ $detail->uom?->name ?? '' }}</td>
                                                    <td>{{ rupiah($detail->unit_price, true) }}</td>
                                                    <td>{{ $detail->discount }}%</td>
                                                    <td>{{ rupiah($detail->total_price, true) }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="7">Sub Total</th>
                                                <th>{{ rupiah($purchaseOrder->details->sum('total_price'), true) }}</th>
                                            </tr>
                                            <tr>
                                                <th colspan="6">Additional Discount</th>
                                                <th>{{ $purchaseOrder->additional_discount }}%</th>
                                                <th>{{ rupiah($purchaseOrder->details->sum('total_price') * $purchaseOrder->additional_discount / 100, true)}}</th>
                                            </tr>
                                            <tr>
                                                <th colspan="7">Grand Total</th>
                                                <th>{{ rupiah($purchaseOrder->total_price, true) }}</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('#btn-add-to-stock').click(function() {
                Swal.fire({
                    title: 'Add to Stock?',
                    text: "Are you sure you want to add to stock?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                                method: "POST",
                                url: "{{ route('purchase-orders.store-to-stock', $purchaseOrder) }}",
                                headers: {
                                    'Accept': "application/json"
                                }
                            })
                            .done(function(res) {
                                if (res.success) {
                                    Swal.fire(
                                        'Success!',
                                        res.message || 'Success add to stock.',
                                        'success'
                                    );

                                    window.location.reload();
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        res.message || 'Your file has been deleted.',
                                        'error'
                                    )
                                }
                            });
                    }
                });
            });
            $('#btn-retrieve-stock').click(function() {
                Swal.fire({
                    title: 'Retrieve Stock?',
                    text: "Are you sure you want to retrieve stock?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                                method: "POST",
                                url: "{{ route('purchase-orders.retrieve-stock', $purchaseOrder) }}",
                                headers: {
                                    'Accept': "application/json"
                                }
                            })
                            .done(function(res) {
                                if (res.success) {
                                    Swal.fire(
                                        'Success!',
                                        res.message || 'Success retrieve stock.',
                                        'success'
                                    );

                                    window.location.reload();
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        res.message || 'Stock insufficient',
                                        'error'
                                    )
                                }
                            });
                    }
                });
            });
        });
    </script>
@endpush
