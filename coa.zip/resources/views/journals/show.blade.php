@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('journals.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>ID</th>
                                        <td>{{ $journal->id }}</td>
                                    </tr>
                                    <tr>
                                        <th>User</th>
                                        <td>{{ $journal->user?->name ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Code</th>
                                        <td>{{ $journal->code }}</td>
                                    </tr>
                                    <tr>
                                        <th>Total Amount</th>
                                        <td>{{ rupiah($journal->total_amount) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Transaction Date</th>
                                        <td>{{ $journal->transaction_date }}</td>
                                    </tr>
                                    <tr>
                                        <th>Created At</th>
                                        <td>{{ $journal->created_at }}</td>
                                    </tr>
                                    <tr>
                                        <th>Updated At</th>
                                        <td>{{ $journal->updated_at }}</td>
                                    </tr>
                                </table>
                                <hr>
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>COA</th>
                                            <th>Debit</th>
                                            <th>Credit</th>
                                            <th>Memo</th>
                                            <th>Subsidiary Ledger</th>
                                            <th>Dept</th>
                                            <th>Event</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($journal->details as $detail)
                                            <tr>
                                                <td>{{ $detail->coa?->name ?? '' }}</td>
                                                <td>{{ rupiah($detail->debit) }}</td>
                                                <td>{{ rupiah($detail->credit) }}</td>
                                                <td>{{ $detail->memo }}</td>
                                                <td>{{ $detail->subsidiary_ledger }}</td>
                                                <td>{{ $detail->dept }}</td>
                                                <td>{{ $detail->event }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
