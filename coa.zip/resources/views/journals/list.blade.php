@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('journals_create')
                            <a href="{{ route('journals.create') }}" class="btn btn-success" title="Create"><i
                                    class="fa fa-plus"></i> Add Data</a>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Journals</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Transaction Date range:</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right" id="date-range">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <table id="journals-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>User</th>
                                            <th>Code</th>
                                            <th>Transaction Date</th>
                                            <th>COA</th>
                                            <th>Debit</th>
                                            <th>Credit</th>
                                            <th>Memo</th>
                                            <th>Dept</th>
                                            <th>Created At</th>
                                            <th>Updated At</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script>
        let date = new Date();
        let startDate = moment().startOf('month').format('YYYY-MM-DD');
        let endDate = moment().endOf('month').format('YYYY-MM-DD');

        $('#date-range').daterangepicker().on('apply.daterangepicker', function(ev, picker) {
            startDate = picker.startDate.format('YYYY-MM-DD');
            endDate = picker.endDate.format('YYYY-MM-DD');
            table.ajax.reload();
        });

        var table = $('#journals-datatable').DataTable({
            processing: true,
            serverSide: true,
            searching: true,
            responsive: true,
            ajax: {
                url: '{{ route('list-journals') }}',
                data: function(params) {
                    params.start_date = startDate;
                    params.end_date = endDate;
                },
            },
            columns: [{
                    data: 'id',
                    name: 'id',
                },
                {
                    data: 'user_name',
                    name: 'user.name'
                },
                {
                    data: 'code',
                    name: 'journal.code'
                },
                {
                    data: 'transaction_date',
                    name: 'transaction_date'
                },
                {
                    data: 'account_number',
                    name: 'coa.account_number'
                },
                {
                    data: 'debit',
                    name: 'debit'
                },
                {
                    data: 'credit',
                    name: 'credit'
                },
                {
                    data: 'memo',
                    name: 'memo'
                },
                {
                    data: 'dept',
                    name: 'dept'
                },
                {
                    data: 'created_at',
                    name: 'created_at'
                },
                {
                    data: 'updated_at',
                    name: 'updated_at'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            orderCellsTop: true,
            order: [
                [0, 'desc']
            ],
            pageLength: 25,
        });

        function deleteData(id) {
            if (confirm('Delete data?')) {
                $.post(`{{ url('journals') }}/` + id, {
                    _method: 'delete'
                }, function(res) {
                    if (res.success) {
                        table.ajax.reload();
                        toastr.success(res.message);
                    } else {
                        toastr.error(res.message);
                    }
                }, 'json');
            }
        }
    </script>
@endpush
