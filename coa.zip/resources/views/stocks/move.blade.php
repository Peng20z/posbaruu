@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('stocks.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">{{ $stock1->product?->name }}</h3>
                            </div>
                            <form method="post" action="{{ route('stocks.update-move', $stock1->id) }}" class="form-loading">
                                @csrf
                                @method('PUT')
                                <div class="card-body">
                                    <table class="table table-bordered table-hover">
                                        <tr>
                                            <th colspan="2">Book 1</th>
                                            <th colspan="2">Book 2</th>
                                        </tr>
                                        <tr>
                                            <td>Current Stock</td>
                                            <td id="current-stock-1">{{ $stock1->qty }}</td>
                                            <td>Current Stock</td>
                                            <td id="current-stock-2">{{ $stock2->qty }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Changes</td>
                                            <td><input name="stock1" type="number" value="0" id="input-stock-1"
                                                    class="form-control @error('stock1') is-invalid @enderror">
                                                @error('stock1')
                                                    <span class="error invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </td>
                                            <td>Changes</td>
                                            <td><input name="stock2" type="number" value="0" id="input-stock-2"
                                                    class="form-control @error('stock2') is-invalid @enderror">
                                                @error('stock2')
                                                    <span class="error invalid-feedback">{{ $message }}</span>
                                                @enderror
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Final Stock</td>
                                            <td id="stock1">{{ $stock1->qty }}</td>
                                            <td>Final Stock</td>
                                            <td id="stock2">{{ $stock2->qty }}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script>
        $(document).ready(function() {

            $('body').on('change', '#input-stock-1', function() {
                let cval1 = parseInt($(this).parent().parent().parent().find('#current-stock-1').text())
                let cval2 = parseInt($(this).parent().parent().parent().find('#current-stock-2').text())

                let val1 = parseInt($(this).val())
                $(this).parent().parent().find('#input-stock-2').val(- val1)

                let fval1 = cval1 + val1;
                let fval2 = cval2 - val1;

                $(this).parent().parent().parent().find('#stock1').text(fval1)
                $(this).parent().parent().parent().find('#stock2').text(fval2)
            });

            $('body').on('change', '#input-stock-2', function() {
                let cval1 = parseInt($(this).parent().parent().parent().find('#current-stock-1').text())
                let cval2 = parseInt($(this).parent().parent().parent().find('#current-stock-2').text())

                let val2 = parseInt($(this).val())
                $(this).parent().parent().find('#input-stock-1').val(- val2)

                let fval1 = cval1 - val2
                let fval2 = cval2 + val2

                $(this).parent().parent().parent().find('#stock1').text(fval1)
                $(this).parent().parent().parent().find('#stock2').text(fval2)
            });
        });
    </script>
@endpush
