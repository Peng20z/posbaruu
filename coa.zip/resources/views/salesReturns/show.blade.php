@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('sales-returns.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Sales Return</h3>
                                <div class="card-tools">
                                    <div class="ml-auto">
                                        {{-- <a href="{{ route('sales-returns.add-to-stock', $salesReturn) }}" class="btn btn-success"
                                        title="Back"><i class="fas fa-plus"></i> Add To Stock  </a> --}}
                                        @if ($canAddToStock)
                                            <button class="btn btn-success" id="btn-add-to-stock" title="Back"><i
                                                    class="fas fa-plus"></i> Return To Stock </button>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>ID</th>
                                        <td>{{ $salesReturn->id }}</td>
                                    </tr>
                                    <tr>
                                        <th>User</th>
                                        <td>{{ $salesReturn->user?->name ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Sales Order</th>
                                        <td>{{ $salesReturn->salesOrder?->code ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Total Price</th>
                                        <td>{{ rupiah($salesReturn->total_price, true)  }}</td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td>{{ $salesReturn->description }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Sales Order Details</h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Qty</th>
                                                <th>Uom</th>
                                                <th>Unit Price</th>
                                                <th>Total Price</th>
                                            </tr>
                                        </thead>
                                        <tbody id="table-body">
                                            @foreach ($salesReturn->details as $detail)
                                                <tr>
                                                    <td>{{ $detail->product?->name ?? '' }}</td>
                                                    <td>{{ $detail->qty }}</td>
                                                    <td>{{ $detail->uom_name ?? '' }}</td>
                                                    <td>{{ rupiah($detail->unit_price, true) }}</td>
                                                    <td>{{ rupiah($detail->total_price, true) }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="4">Total Price</th>
                                                <th>{{ rupiah($salesReturn->total_price, true) }}</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('#btn-add-to-stock').click(function() {
                Swal.fire({
                    title: 'Return to Stock?',
                    text: "Are you sure you want to return these item to stock?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                                method: "POST",
                                url: "{{ route('sales-returns.store-to-stock', $salesReturn) }}",
                                headers: {
                                    'Accept': "application/json"
                                }
                            })
                            .done(function(res) {
                                if (res.success) {
                                    Swal.fire(
                                        'Success!',
                                        res.message || 'Success return to stock.',
                                        'success'
                                    );

                                    // window.location.reload();
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        res.message || 'Your file has been deleted.',
                                        'error'
                                    )
                                }
                            });
                    }
                });
            });
        });
    </script>
@endpush
