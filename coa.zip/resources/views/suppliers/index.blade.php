@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('suppliers_create')
                            <a href="{{ route('suppliers.create') }}" class="btn btn-success" title="Create"><i
                                    class="fa fa-plus"></i>
                                Add
                                Data</a>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#mdlImportExcel"><i
                                    class="fa fa-plus"></i> Import Data</button>
                            <div class="modal inmodal fade" id="mdlImportExcel" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <form action="{{ route('suppliers.import-excel') }}" method="post"
                                            enctype="multipart/form-data" class="form-loading">
                                            @csrf
                                            @method('post')
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="file">Add File</label> <br>
                                                    <input type="file" name="file">
                                                </div>
                                                <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane"></i>
                                                    Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Suppliers List</h3>
                            </div>
                            <div class="card-body">
                                <table id="suppliers-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Description</th>
                                            <th>Address</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script>
        var table = $('#suppliers-datatable').DataTable({
            processing: true,
            serverSide: true,
            searching: true,
            responsive: true,
            ajax: '{{ route('suppliers.index') }}',
            columns: [{
                    data: 'id',
                    name: 'id',
                },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'email',
                    name: 'email'
                },
                {
                    data: 'phone',
                    name: 'phone'
                },
                {
                    data: 'description',
                    name: 'description'
                },
                {
                    data: 'address',
                    name: 'address'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            orderCellsTop: true,
            order: [
                [0, 'desc']
            ],
            pageLength: 25,
        });

        function deleteData(id) {
            if (confirm('Delete data?')) {
                $.post(`{{ url('suppliers') }}/` + id, {
                    _method: 'delete'
                }, function(res) {
                    if (res.success) {
                        table.ajax.reload();
                        toastr.success(res.message);
                    } else {
                        toastr.error(res.message);
                    }
                }, 'json');
            }
        }
    </script>
@endpush
