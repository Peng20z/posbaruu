@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('products.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('products.store') }}" class="form-loading">
                                @csrf
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Code</label>
                                        <input name="id" type="text" value="{{ old('id') }}"
                                            class="form-control @error('id') is-invalid @enderror" placeholder="code"
                                            required>
                                        @error('id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Product Brand</label>
                                        <select name="product_brand_id" id="product_brand_id"
                                            class="form-control select2 @error('product_brand_id') is-invalid @enderror"
                                            required>
                                            @foreach ($productBrands as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('product_brand_id') == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('product_brand_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Product Category</label>
                                        <select name="product_category_id" id="product_category_id"
                                            class="form-control select2 @error('product_category_id') is-invalid @enderror"
                                            required>
                                            @foreach ($productCategories as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('product_category_id') == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('product_category_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Name</label>
                                        <input name="name" type="text" value="{{ old('name') }}"
                                            class="form-control @error('name') is-invalid @enderror" placeholder="Name"
                                            required>
                                        @error('name')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Buy Price</label>
                                        <input name="buy_price" id="buy_price" type="text"
                                            value="{{ old('buy_price', 0) }}"
                                            class="form-control @error('buy_price') is-invalid @enderror"
                                            placeholder="Buy Price" data-type="currency" required>
                                        @error('buy_price')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Sell Price</label>
                                        <input name="sell_price" id="sell_price" type="text"
                                            value="{{ old('sell_price', 0) }}"
                                            class="form-control @error('sell_price') is-invalid @enderror"
                                            placeholder="Sell Price" data-type="currency" required>
                                        <span class="error warning-feedback">Harga jual di bawah modal</span>
                                        @error('sell_price')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Minimum Stock Reminder</label>
                                        <input name="min_stock_reminder" type="number"
                                            value="{{ old('min_stock_reminder') }}"
                                            class="form-control @error('min_stock_reminder') is-invalid @enderror"
                                            placeholder="Minimum Stock Reminder">
                                        @error('min_stock_reminder')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Base Uom</label>
                                        <select name="base_uom_id" id="base_uom_id"
                                            class="form-control select2 @error('base_uom_id') is-invalid @enderror"
                                            required>
                                            @foreach ($uoms as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('base_uom_id') == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('base_uom_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Default Uom</label>
                                        <select name="default_uom_id" id="default_uom_id"
                                            class="form-control select2 @error('default_uom_id') is-invalid @enderror"
                                            required>
                                            @foreach ($uoms as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('default_uom_id') == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('default_uom_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group @error('description') has-error @enderror">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control" rows="5" placeholder="Description"></textarea>
                                        @error('description')
                                            <span class="form-text m-b-none text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label> <input type="checkbox" name="update_db" value="1"> Update only on this
                                            db
                                        </label> <br>
                                        <label> <input type="checkbox" name="is_active" value="1" checked> Is Active
                                        </label>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            initPriceFormat();

            let buyPrice = 0;
            let sellPrice = 0;
            $("#buy_price").on("keyup", function() {
                buyPrice = unformatPrice($(this).val());
                sellPrice = unformatPrice($("#sell_price").val());

                if (sellPrice < buyPrice) {
                    // $("form").find(":submit").attr("disabled", true);
                    $("#sell_price").addClass('is-warning');
                } else {
                    // $("form").find(":submit").attr("disabled", false);
                    $("#sell_price").removeClass('is-warning');
                }
            });

            $("#sell_price").on("keyup", function() {
                buyPrice = unformatPrice($("#buy_price").val());
                sellPrice = unformatPrice($(this).val());

                if (sellPrice < buyPrice) {
                    // $("form").find(":submit").attr("disabled", true);
                    $(this).addClass('is-warning');
                } else {
                    // $("form").find(":submit").attr("disabled", false);
                    $(this).removeClass('is-warning');
                }
            });
        });
    </script>
@endpush
