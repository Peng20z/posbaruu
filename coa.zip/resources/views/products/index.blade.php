@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('products_create')
                            <a href="{{ route('products.create') }}" class="btn btn-success" title="Create"><i
                                    class="fa fa-plus"></i> Add Data</a>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#mdlImportExcel"><i
                                    class="fa fa-plus"></i> Import Data</button>
                            <div class="modal inmodal fade" id="mdlImportExcel" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <form action="{{ route('products.import-excel') }}" method="post"
                                            enctype="multipart/form-data" class="form-loading">
                                            @csrf
                                            @method('post')
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="file">Add File</label> <br>
                                                    <input type="file" name="file">
                                                </div>
                                                <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane"></i>
                                                    Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Product List</h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="products-datatable" class="datatable table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>Code</th>
                                                <th>Name</th>
                                                <th>Category</th>
                                                <th>Brand</th>
                                                <th>Description</th>
                                                <th>Created At</th>
                                                <th>Updated At</th>
                                                <th></th>
                                            </tr>
                                            <tr>
                                                <x-forms.filter-text />
                                                <x-forms.filter-text />
                                                <x-forms.filter-text />
                                                <x-forms.filter-text />
                                                <x-forms.filter-text />
                                                <x-forms.filter-text />
                                                <x-forms.filter-text />
                                                <td></td>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script>

            var table = $('#products-datatable').DataTable({
                processing: true,
                serverSide: true,
                searching: true,
                responsive: true,
                ajax: '{{ route('products.index') }}',
                columns: [{
                        data: 'id',
                        name: 'id'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'product_category_name',
                        name: 'productCategory.name'
                    },
                    {
                        data: 'product_brand_name',
                        name: 'productBrand.name'
                    },
                    {
                        data: 'description',
                        name: 'description'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'updated_at',
                        name: 'updated_at'
                    },
                    {
                        data: 'actions',
                        name: 'actions',
                        orderable: false,
                        searchable: false
                    }
                ],
                orderCellsTop: true,
                order: [
                    [0, 'desc']
                ],
                pageLength: 25,
            });

            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                alert('tab clicked')
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

            let visibleColumnsIndexes = null;
            $('.datatable thead').on('input', '.search', function() {
                let strict = $(this).attr('strict') || false
                let value = strict && this.value ? "^" + this.value + "$" : this.value

                let index = $(this).parent().index()
                if (visibleColumnsIndexes !== null) {
                    index = visibleColumnsIndexes[index]
                }

                table
                    .column(index)
                    .search(value, strict)
                    .draw()
            });
            table.on('column-visibility.dt', function(e, settings, column, state) {
                visibleColumnsIndexes = []
                table.columns(":visible").every(function(colIdx) {
                    visibleColumnsIndexes.push(colIdx);
                });
            })

            function deleteData(id) {
                if (confirm('Delete data?')) {
                    $.post(`{{ url('products') }}/` + id, {
                            _method: 'delete'
                    }, function(res) {
                        if (res.success) {
                            table.ajax.reload();
                            toastr.success(res.message);
                        } else {
                            toastr.error(res.message);
                        }
                    }, 'json');
                }
            }

    </script>
@endpush
