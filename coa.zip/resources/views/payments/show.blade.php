@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Payment Detail</h3>
                                <a href="{{ route('payments.index') }}" class="btn btn-primary btn-sm float-right"><i
                                        class="fa fa-arrow-left"></i> Back</a>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>Code</th>
                                        <td>{{ $payment->salesOrder->code }}</td>
                                    </tr>
                                    <tr>
                                        <th>Customer</th>
                                        <td>{{ $payment->salesOrder->customer->name }}</td>
                                    </tr>
                                    <tr>
                                        <th>Payment Time</th>
                                        <td>{{ $payment->created_at }}</td>
                                    </tr>
                                    <tr>
                                        <th>Amount</th>
                                        <td>{{ rupiah($payment->amount, true) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>{{ $payment->status }}</td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td>{{ $payment->description }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
