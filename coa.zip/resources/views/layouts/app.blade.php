<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>{{ env('APP_NAME', 'Anon') }}</title>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet" href="{{ asset('plugins/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css') }}"
        rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css') }}"
        rel="stylesheet">
    <link href="{{ asset('plugins/toastr/toastr.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('dist/css/adminlte.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css') }}"
        rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('plugins/select2/css/select2.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css') }}">

    <link rel="stylesheet" href="{{ asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/datatables-buttons/css/buttons.bootstrap4.min.css') }}">
    <link rel="stylesheet" href="{{ asset('plugins/toastr/toastr.min.css') }}">
    @stack('css')
    <style>
        .form-control:focus {
            /* background-color: lightblue; */
            border-color: #5de4ae;
            box-shadow: 0 0 5px rgba(73, 200, 150, 8);
            outline: #5de4ae;
        }

        .btn:focus {
            border-color: #ff0000;
            box-shadow: 0 0 5px rgba(255, 0, 0, 8);
        }
    </style>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        @include('layouts.includes.header')
        @include('layouts.includes.sidebar')
        @include('sweetalert::alert')
        @yield('content')
        <footer class="main-footer">
            <strong>Copyright</strong> Albatech &copy; {{ date('Y') }}
            All rights reserved.
        </footer>
    </div>

    <script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('plugins/toastr/toastr.min.js') }}"></script>
    <script src="{{ asset('plugins/jquery-ui/jquery-ui.min.js') }}"></script>
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('plugins/moment/moment.min.js') }}"></script>
    <script src="{{ asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js') }}"></script>
    <script src="{{ asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js') }}"></script>
    <script src="{{ asset('plugins/select2/js/select2.full.min.js') }}"></script>
    <script src="{{ asset('dist/js/adminlte.js') }}"></script>
    <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('plugins/toastr/toastr.min.js') }}"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        });

        let focus = $('.content-wrapper section.content-header').find('a:first');
        if (focus.length > 0) {
            focus.focus();
        } else {
            $('.content-wrapper section.content').find("input").not("[name*='_token'], [name*='_method']").first().focus();

        }

        $('.form-loading').on('submit', function() {
            $(this).find(':submit').attr('disabled', true).text('Loading...')
        });
        $('label.required').append('<span class="text-danger"> *</span>');
        $('.select2').select2({
            theme: 'bootstrap4'
        });

        $(document).on('select2:open', () => {
            let el = document.querySelector('.select2-search__field');
            el.focus();
            el.placeholder = 'search'
        });

        function initPriceFormat() {
            $('.price-format').priceFormat({
                prefix: '',
                centsLimit: 2,
                thousandsSeparator: ','
            });
        }

        $(document).keydown(
            function(e) {
                if (e.keyCode == 39) {
                    focusNext();
                }
                if (e.keyCode == 37) {
                    $(".form-control:focus").closest("td").prev().find(".form-control").focus();
                }
                if (e.keyCode == 40) {
                    $(".form-control:focus").closest("tr").next().find(".form-control").focus();

                }
            }
        );

        function focusNext(focus) {
            let next = $(".form-control:focus").closest("td").next().find(".form-control");
            // console.log('next', next);
            // console.log('next', next.length);
            // if (next.length < 1) {
            //     focusNext(next.parent)
            // }else{
            //     next.focus();
            // }
        }

        // fungsi untuk merubah format price(ex: 10.000) menjadi int(ex: 10000)
        function unformatPrice(value = 0) {
            let resultValue = parseFloat(value.replaceAll(',', '') || 0).toFixed(2);
            resultValue = parseFloat(resultValue);
            return resultValue;
            // let resultValue = parseInt(value.replaceAll(',', '') || 0);
            // return resultValue
        }

        function formatNumber(n) {
            // format number 1000000 to 1,234,567
            return n.replace(/\D/g, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        }

        function formatCurrency(input, blur) {
            // appends $ to value, validates decimal side
            // and puts cursor back in right position.

            // get input value
            var input_val = input.val();

            // don't validate empty input
            if (input_val === "") {
                return;
            }

            // original length
            var original_len = input_val.length;

            // initial caret position
            var caret_pos = input.prop("selectionStart");

            // check for decimal
            if (input_val.indexOf(".") >= 0) {

                // get position of first decimal
                // this prevents multiple decimals from
                // being entered
                var decimal_pos = input_val.indexOf(".");

                // split number by decimal point
                var left_side = input_val.substring(0, decimal_pos);
                var right_side = input_val.substring(decimal_pos);

                // add commas to left side of number
                left_side = formatNumber(left_side);

                // validate right side
                right_side = formatNumber(right_side);

                // On blur make sure 2 numbers after decimal
                if (blur === "blur") {
                    right_side += "00";
                }

                // Limit decimal to only 2 digits
                right_side = right_side.substring(0, 2);

                // join number by .
                input_val = left_side + "." + right_side;

            } else {
                // no decimal entered
                // add commas to number
                // remove all non-digits
                input_val = formatNumber(input_val);

                // final formatting
                if (blur === "blur") {
                    input_val += ".00";
                }
            }

            // send updated string to input
            input.val(input_val);

            // put caret back in the right position
            var updated_len = input_val.length;
            caret_pos = updated_len - original_len + caret_pos;
            input[0].setSelectionRange(caret_pos, caret_pos);
        }

        $(document).ready(function() {
            $(document).on('focus', "input[data-type='currency']", function() {
                if ($(this).val() <= 0) {
                    $(this).val('');
                } else {
                    $(this).val(unformatPrice($(this).val()))
                    formatCurrency($(this));
                }
            });
            $(document).on('keyup', "input[data-type='currency']", function(e) {
                if (!e.metaKey && (!e.ctrlKey && (e.keyCode != 65 || e.keyCode != 97)) && e.keyCode != 17) {
                    formatCurrency($(this));
                }
            });
            $(document).on('blur', "input[data-type='currency']", function() {
                if ($(this).val() <= 0) {
                    $(this).val(0);
                }
                formatCurrency($(this), "blur");
            });
        });

        function customToFixed(value, centLimit = 2) {
            return parseFloat(value).toFixed(centLimit);
        }
    </script>
    @stack('js')
</body>

</html>
