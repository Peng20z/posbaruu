<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label>Source Account</label>
            <select name="source_coa_id" class="form-control select2 @error('source_coa_id') is-invalid @enderror">
                @foreach ($coas as $id => $name)
                    <option value="{{ $id }}" @if ($sourceCoaId == $id) selected @endif>
                        {{ $name }}</option>
                @endforeach
            </select>
            @error('source_coa_id')
                <span class="error invalid-feedback">{{ $message }}</span>
            @enderror
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label>Destination Account</label>
            <select name="destination_coa_id" class="form-control select2 @error('destination_coa_id') is-invalid @enderror">
                @foreach ($coas as $id => $name)
                    <option value="{{ $id }}" @if ($destinationCoaId == $id) selected @endif>
                        {{ $name }}</option>
                @endforeach
            </select>
            @error('destination_coa_id')
                <span class="error invalid-feedback">{{ $message }}</span>
            @enderror
        </div>
    </div>
</div>
