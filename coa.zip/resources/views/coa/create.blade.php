@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('coa.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('coa.store') }}" class="form-loading">
                                @csrf
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Parent</label>
                                        <select name="parent_id"
                                            class="form-control select2 @error('parent_id') is-invalid @enderror">
                                            @foreach ($coas as $id => $name)
                                                <option value="{{ $id }}"
                                                    {{ old('parent_id', null) == $id ? 'selected' : '' }}>
                                                    {{ $name }}</option>
                                            @endforeach
                                        </select>
                                        @error('parent_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Account Name</label>
                                        <input name="account_name" type="text" value="{{ old('account_name') }}"
                                            class="form-control @error('account_name') is-invalid @enderror"
                                            placeholder="Account Name" required>
                                        @error('account_name')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Account Number</label>
                                        <input name="account_number" type="text" value="{{ old('account_number') }}"
                                            class="form-control @error('account_number') is-invalid @enderror"
                                            placeholder="Account Number" required>
                                        @error('account_number')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Normal Balance</label>
                                        @foreach ($normalBalances as $key => $value)
                                            <div class="custom-control custom-radio">
                                                <input class="custom-control-input" type="radio" id="{{ $key }}"
                                                    value="{{ $key }}" name="normal_balance" @checked(old('normal_balance', $key) == $key)>
                                                <label for="{{ $key }}"
                                                    class="custom-control-label">{{ $value }}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
