@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('coa_create')
                            <a href="{{ route('coa.create') }}" class="btn btn-success" title="Create"><i class="fa fa-plus"></i>
                                Add
                                Data</a>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">COA List</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Transaction Date range:</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right" id="date-range">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <table id="coa-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Account Number</th>
                                            <th>Account Name</th>
                                            <th>Normal Balance</th>
                                            <th>Saldo</th>
                                            <th>Created At</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($coas as $coa)
                                            <tr>
                                                <th>{{ $coa->id }}</th>
                                                <th>{{ $coa->account_number }}</th>
                                                <th>{{ $coa->account_name }}</th>
                                                <th>
                                                    @if ($coa->normal_balance == 'debit')
                                                        <span
                                                            class="label label-primary">{{ strtoupper($coa->normal_balance) }}</span>
                                                    @else
                                                        <span
                                                            class="label label-danger">{{ strtoupper($coa->normal_balance) }}</span>
                                                    @endif
                                                </th>
                                                <th class="text-right">
                                                    @php
                                                        $saldo = $coa->getSaldo($startDate, $endDate);
                                                        echo $saldo > 0
                                                            ? '<span class="text-primary text-bold">' .
                                                                rupiah($saldo) .
                                                                '</span>'
                                                            : '<span class="text-danger text-bold">' .
                                                                rupiah($saldo) .
                                                                '</span>';
                                                    @endphp
                                                </th>
                                                <th>{{ date('d-m-Y H:i', strtotime($coa->created_at)) }}</th>
                                                <th></th>
                                            </tr>
                                            @foreach ($coa->childs as $coa)
                                                <tr>
                                                    <th>{{ $coa->id }}</th>
                                                    <td>{!! str_repeat('&nbsp;', 5) . $coa->account_number !!}</td>
                                                    <td>{!! str_repeat('&nbsp;', 5) . $coa->account_name !!}</td>
                                                    <td>
                                                        @if ($coa->normal_balance == 'debit')
                                                            <span
                                                                class="label label-primary">{{ strtoupper($coa->normal_balance) }}</span>
                                                        @else
                                                            <span
                                                                class="label label-danger">{{ strtoupper($coa->normal_balance) }}</span>
                                                        @endif
                                                    </td>
                                                    <td class="text-right">
                                                        @php
                                                            $saldo = $coa->getSaldo($startDate, $endDate);
                                                            echo $saldo > 0
                                                                ? '<span class="text-primary text-bold">' .
                                                                    rupiah($saldo) .
                                                                    '</span>'
                                                                : '<span class="text-danger text-bold">' .
                                                                    rupiah($saldo) .
                                                                    '</span>';
                                                        @endphp
                                                    </td>
                                                    <td>{{ date('d-m-Y H:i', strtotime($coa->created_at)) }}</td>
                                                    <td>
                                                        <a href="{{ route('coa.show', $coa) . '?' . $queryString }}"
                                                            class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                        <a href="{{ route('coa.edit', $coa) }}"
                                                            class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                                        <form action="{{ route('coa.destroy', $coa->id) }}" method="post"
                                                            class="d-inline" onclick="return confirm('Delete this data?')">
                                                            @csrf
                                                            @method('delete')
                                                            <button type="submit" class="btn btn-danger btn-sm"><i
                                                                    class="fa fa-trash"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('#date-range').daterangepicker({
                startDate: new Date('{{ $startDate }}'),
                endDate: new Date('{{ $endDate }}'),
            }).on('apply.daterangepicker', function(ev, picker) {
                startDate = picker.startDate.format('YYYY-MM-DD');
                endDate = picker.endDate.format('YYYY-MM-DD');
                window.location.href = "{{ url()->current() }}?start_date=" + startDate + "&end_date=" +
                    endDate;
            });
        })
    </script>
@endpush
