@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('coa.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">COA</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>ID</th>
                                        <td>{{ $coa->id }}</td>
                                    </tr>
                                    <tr>
                                        <th>Account Number</th>
                                        <td>{{ $coa->account_number }}</td>
                                    </tr>
                                    <tr>
                                        <th>Account Name</th>
                                        <td>{{ $coa->account_name }}</td>
                                    </tr>
                                    <tr>
                                        <th>Normal Balance</th>
                                        <td>{{ $coa->normal_balance }}</td>
                                    </tr>
                                    <tr>
                                        <th>Total Saldo</th>
                                        <td>
                                            @php
                                                $saldo = $coa->getSaldo($startDate, $endDate);
                                                echo $saldo > 0
                                                    ? '<span class="text-primary text-bold">' .
                                                        rupiah($saldo) .
                                                        '</span>'
                                                    : '<span class="text-danger text-bold">' .
                                                        rupiah($saldo) .
                                                        '</span>';
                                            @endphp
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Created At</th>
                                        <td>{{ $coa->created_at }}</td>
                                    </tr>
                                    <tr>
                                        <th>Updated At</th>
                                        <td>{{ $coa->updated_at }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Journal</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Transaction Date range:</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right" id="date-range">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Transaction Date</th>
                                            <th>COA / Account</th>
                                            <th>Debit</th>
                                            <th>Credit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($journals as $journal)
                                            <tr>
                                                <td rowspan="{{ $journal->details->count() }}">
                                                    <p>{{ $journal->transaction_date }}</p>
                                                    <p><a href="{{ route('journals.show', $journal) }}">{{ $journal->code }}</a></p>
                                                    <p>{{ $journal->description }}</p>
                                                </td>
                                                @for ($i = 0; $i < $journal->details->count(); $i++)
                                                @if($i > 0) <tr> @endif
                                                    <td>{{ $journal->details[$i]->coa->name }}</td>
                                                    <td>{{ rupiah($journal->details[$i]->debit) }}</td>
                                                    <td>{{ rupiah($journal->details[$i]->credit) }}</td>
                                                </tr>
                                                @endfor
                                            @empty
                                            <tr>
                                                <td colspan="4">
                                                    <div class="alert alert-warning">
                                                        No Data
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('#date-range').daterangepicker({
                startDate: new Date('{{ $startDate }}'),
                endDate: new Date('{{ $endDate }}'),
            }).on('apply.daterangepicker', function(ev, picker) {
                startDate = picker.startDate.format('YYYY-MM-DD');
                endDate = picker.endDate.format('YYYY-MM-DD');
                window.location.href = "{{ url()->current() }}?start_date=" + startDate + "&end_date=" +
                    endDate;
            });
        })
    </script>
@endpush
