@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('sales-orders.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Sales Order</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>ID</th>
                                        <td>{{ $salesOrder->id }}</td>
                                    </tr>
                                    <tr>
                                        <th>User</th>
                                        <td>{{ $salesOrder->user?->name ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Customer</th>
                                        <td>{{ $salesOrder->customer?->name ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Code</th>
                                        <td>{{ $salesOrder->code }}</td>
                                    </tr>
                                    <tr>
                                        <th>Grand Total</th>
                                        <td>{{ rupiah($salesOrder->total_price) }}</td>
                                    </tr>
                                    <tr>
                                        <th>Transaction DateTime</th>
                                        <td>{{ $salesOrder->transaction_datetime }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="card card-primary card-outline shadow">
                            <div class="card-body">
                                <ul class="nav nav-tabs" id="custom-content-below-tab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="sales-order-detail-tab" data-toggle="pill"
                                            href="#sales-order-detail" role="tab" aria-controls="sales-order-detail"
                                            aria-selected="true">Sales Order Details
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="sales-order-payments-tab" data-toggle="pill"
                                            href="#sales-order-payments" role="tab" aria-controls="sales-order-payments"
                                            aria-selected="false">Payments</a>
                                    </li>
                                </ul>
                                <div class="tab-content" id="custom-content-below-tabContent">
                                    <div class="tab-pane fade show active" id="sales-order-detail" role="tabpanel"
                                        aria-labelledby="sales-order-detail-tab">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th>Code</th>
                                                                <th>Product Name</th>
                                                                <th>Qty</th>
                                                                <th>Uom</th>
                                                                <th>Unit Price</th>
                                                                <th>Discount</th>
                                                                <th>Total Price</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="table-body">
                                                            @foreach ($salesOrder->details as $detail)
                                                                <tr>
                                                                    <td>{{ $detail->product?->id ?? '' }}</td>
                                                                    <td>{{ $detail->product?->name ?? '' }}</td>
                                                                    <td>{{ $detail->qty }}</td>
                                                                    <td>{{ $detail->uom?->name ?? '' }}</td>
                                                                    <td>{{ rupiah($detail->unit_price, true) }}</td>
                                                                    <td>{{ rupiah($detail->total_discount) }} %</td>
                                                                    <td>{{ rupiah($detail->total_price, true) }}</td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th colspan="6">SubTotal</th>
                                                                <th>{{ rupiah($salesOrder->details->sum('total_price')) }}
                                                                </th>
                                                            </tr>
                                                            <tr>
                                                                <th colspan="5">Additional Discount</th>
                                                                <th>{{ $salesOrder->additional_discount ?? 0 }}%</th>
                                                                <th>{{ rupiah(($salesOrder->additional_discount / 100) * $salesOrder->total_price ?? 0, true) }}
                                                                </th>
                                                            </tr>
                                                            <tr>
                                                                <th colspan="6">Grand Total</th>
                                                                <th>{{ rupiah($salesOrder->total_price, true) }}</th>
                                                            </tr>
                                                            <tr>
                                                                <th colspan="6">Total Paid</th>
                                                                <th>{{ rupiah($salesOrder->total_paid, true) }}</th>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="sales-order-payments" role="tabpanel"
                                        aria-labelledby="sales-order-payments-tab">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th>Code</th>
                                                                <th>User</th>
                                                                <th>Status</th>
                                                                <th>Amount</th>
                                                                <th>Created At</th>
                                                                <th>Updated At</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="table-body">
                                                            @forelse ($salesOrder->payments as $payment)
                                                                <tr>
                                                                    <td>{{ $payment->code }}</td>
                                                                    <td>{{ $payment->user?->name ?? '' }}</td>
                                                                    <td>{{ $payment->status }}</td>
                                                                    <td>{{ rupiah($payment->amount, true) }}</td>
                                                                    <td>{{ $payment->created_at }}</td>
                                                                    <td>{{ $payment->updated_at }}</td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    <td colspan="6">
                                                                        <div class="alert alert-warning">Belum ada
                                                                            pembayaran</div>
                                                                    </td>
                                                                </tr>
                                                            @endforelse
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if ($salesOrder->total_paid < $salesOrder->total_price)
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Payment</h3>
                                </div>
                                <form method="post"
                                    action="{{ route('payments.store') }}?redirect={{ url()->current() }}"
                                    class="form-loading">
                                    @csrf
                                    <input type="hidden" name="sales_order_id" value="{{ $salesOrder->code }}">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="required">Code</label>
                                                    <input name="code" id="code" type="text"
                                                        class="form-control @error('code') is-invalid @enderror"
                                                        placeholder="Code" required
                                                        value="{{ sprintf('INV/%s%s', $salesOrder->code, time()) }}">
                                                    @error('code')
                                                        <span class="error invalid-feedback">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="form-group">
                                                    <label class="required">Payment Type</label>
                                                    <select name="payment_type_id" id="payment_type_id"
                                                        class="form-control select2 @error('payment_type_id') is-invalid @enderror"
                                                        required>
                                                        @foreach ($paymentTypes as $id => $name)
                                                            <option value="{{ $id }}"
                                                                @if (old('payment_type_id') == $id) selected @endif>
                                                                {{ $name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    @error('payment_type_id')
                                                        <span class="error invalid-feedback">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="form-group">
                                                    <label class="required">Amount</label>
                                                    <input name="amount" id="amount" type="text"
                                                        value="{{ old('amount') }}" data-type="currency"
                                                        class="form-control @error('amount') is-invalid @enderror"
                                                        placeholder="Amount" required>
                                                    <span class="error invalid-feedback">Total payment lebih besar dari
                                                        total
                                                        harga</span>
                                                    @error('amount')
                                                        <span class="error invalid-feedback">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="required">Status</label>
                                                    <select name="status" id="status"
                                                        class="form-control select2 @error('status') is-invalid @enderror"
                                                        required>
                                                        @foreach ($paymentStatuses as $paymentStatus)
                                                            <option value="{{ $paymentStatus->value }}"
                                                                @if (old('status') == $paymentStatus->value) selected @endif>
                                                                {{ $paymentStatus->description }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    @error('status')
                                                        <span class="error invalid-feedback">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                                <div class="form-group">
                                                    <label>Description</label>
                                                    <textarea name="description" class="form-control @error('description') is-invalid @enderror" rows="5"
                                                        placeholder="Description">{{ old('description') }}</textarea>
                                                    @error('description')
                                                        <span
                                                            class="form-text m-b-none text-danger">{{ $message }}</span>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary" id="clickToSubmit">Save</button>
                                    </div>
                                </form>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
