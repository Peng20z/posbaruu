@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('sales-orders.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <form method="post" action="{{ route('sales-order.store-admin') }}" class="form-loading">
                            @csrf
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Sales Order</h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Code</label>
                                        <input type="text" name="code" id="code"
                                            class="form-control @error('code') is-invalid @enderror"
                                            value="{{ $code }}">
                                        @error('code')
                                            <span class="error invalid-feedback">Code has been used</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Transaction Date</label>
                                        <div class="input-group date" id="filter-date" data-target-input="nearest"
                                            data-toggle="datetimepicker">
                                            <input type="text" name="transaction_datetime"
                                                class="form-control datetimepicker-input" data-target="#filter-date"
                                                required />
                                            <div class="input-group-append" data-target="#filter-date">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Customer</label>
                                        <select name="customer_id" id="customer_id"
                                            class="form-control select2 @error('customer_id') is-invalid @enderror"
                                            required>
                                            @foreach ($customers as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('customer_id', null) == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('customer_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Description</label>
                                        <textarea name="description" id="description" rows="2"
                                            class="form-control @error('description') is-invalid @enderror">{{ old('description') }}</textarea>
                                        @error('description')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Sales Order Details</h3>
                                </div>
                                <div class="card-body">
                                    <label>Product</label>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Code</th>
                                                    <th>Product Name</th>
                                                    <th>Book</th>
                                                    <th>Qty</th>
                                                    <th>Uom</th>
                                                    <th style="background-color: #D3D3D3">Stock</th>
                                                    <th>Unit Price</th>
                                                    <th>Discount</th>
                                                    <th>Total Price</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="table-body"></tbody>
                                            <tfoot>
                                                <tr>
                                                    <td colspan="10" class="border-right-0 border-left-0 pt-5">
                                                        <div class="form-group">
                                                            <div class="d-flex">
                                                                <select name="product_id" id="product_id"
                                                                    class="form-control w-75">
                                                                </select>
                                                                <button class="btn btn-primary ml-2" id="add-product"
                                                                    type="button"><i class="fa fa-plus"></i> Add
                                                                    Product</button>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">Sub Total</th>
                                                    <th>
                                                        <input type="text" class="form-control price-format"
                                                            id="sub-total-accumulation" readonly disabled>
                                                    </th>
                                                    <th></th>
                                                </tr>
                                                <tr>
                                                    <th colspan="7">Additional Discount</th>
                                                    <th class="d-flex">
                                                        <input type="number" step="any" class="form-control"
                                                            name="additional_discount"
                                                            id="input-additional-discount-percentage" max="100">
                                                        <p class=""> %</p>
                                                    </th>
                                                    <th>
                                                        <input type="text" class="form-control" data-type="currency"
                                                            id="input-additional-discount">
                                                    </th>
                                                    <th></th>
                                                </tr>
                                                <tr>
                                                    <th colspan="8">Grand Total</th>
                                                    <th>
                                                        <input type="text" class="form-control price-format"
                                                            id="total-price-accumulation" readonly disabled>
                                                    </th>
                                                    <th></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Payment</h3>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Code</label>
                                        <input name="payment_code" id="payment_code" type="text"
                                            class="form-control @error('payment_code') is-invalid @enderror"
                                            placeholder="Code" required>
                                        @error('payment_code')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Payment Type</label>
                                        <select name="payment_type_id" id="payment_type_id"
                                            class="form-control select2 @error('payment_type_id') is-invalid @enderror"
                                            required>
                                            @foreach ($paymentTypes as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('payment_type_id') == $id) selected @endif>
                                                    {{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('payment_type_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Amount</label>
                                        <input name="payment_amount" id="payment_amount" type="text" value="{{ old('payment_amount') }}"
                                            class="form-control price-format @error('payment_amount') is-invalid @enderror"
                                            placeholder="Amount" required>
                                            <span class="error invalid-feedback">Total payment lebih besar dari total harga</span>
                                        @error('payment_amount')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Status</label>
                                        <select name="payment_status" id="payment_status"
                                            class="form-control select2 @error('payment_status') is-invalid @enderror" required>
                                            @foreach ($paymentStatuses as $paymentStatus)
                                                <option value="{{ $paymentStatus->value }}"
                                                    @if (old('status') == $paymentStatus->value) selected @endif>
                                                    {{ $paymentStatus->description }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('payment_status')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="payment_description" class="form-control @error('payment_description') is-invalid @enderror"
                                            rows="5" placeholder="Description">{{ old('payment_description') }}</textarea>
                                        @error('payment_description')
                                            <span class="form-text m-b-none text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary" id="clickToSubmit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            // set payment code
            $('#payment_code').val("INV/" + '{{$code}}' + Date.now());
            $('#code').on('change', async function() {
                $('#payment_code').val("INV/" + $(this).val() + Date.now());
            });
            // set payment code

            // validate payment amount can not less than total-price-accumulation
            $('#payment_amount').on('keyup',function(){
                initPriceFormat()
                let totalPriceAccumulation = unformatPrice($('#total-price-accumulation').val());
                let paymentAmount = unformatPrice($(this).val());
                if(paymentAmount > totalPriceAccumulation){
                    $(this).addClass('is-invalid');
                } else {
                    $(this).removeClass('is-invalid');
                }
            })

            let selectedProducts = []; // buat nampung products yg sudah terpilih
            let selectedProductIds = []; // buat nampung id product yg sudah terpilih
            let i = 0;

            if ((screen.width < 1440)) {
                $("#customer_id").val(2).change();
            }

            $("#clickToSubmit").on("keydown", function(e) {
                if (e.keyCode === 13) {
                    e.preventDefault();
                }
            });

            $('#filter-date').datetimepicker({
                defaultDate: new Date(),
                timePicker: true,
                timePicker24Hour: true,
                format: 'YYYY-MM-DD HH:mm:ss',

                icons: {
                    time: 'far fa-clock'
                }
            });

            // get products
            $('#product_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Select product',
                ajax: {
                    url: '{{ route('api.products.index') }}',
                    dataType: 'json',
                    delay: 300,
                    data: function(params) {
                        return {
                            'per_page': 30,
                            'select': 'id,name as text', // select2 only accept return data (id and text)
                            'filter[name]': params.term, // search term / search by nama product
                            'filter[ids]': selectedProductIds
                                .toString(), // search where id product not in
                            'filter[is_active]': 1,
                            page: params.page || params.current_page || 1
                        };
                    },
                    processResults: function(data, params) {
                        params.current_page = params.current_page || 1;
                        return {
                            results: data.data,
                            pagination: {
                                more: (params.current_page * 30) < data.total
                            }
                        };
                    },
                    autoWidth: true,
                    cache: true
                }
            });

            // fungsi ketika hapus product
            $('body').on('click', '.btn-delete', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let productId = parent.find('.input-product-id').val(); // get product id

                parent.remove(); // hapus element parent(<tr>) nya

                // hapus id product dari variable selectedProductIds
                selectedProductIds = $.grep(selectedProductIds, function(value) {
                    return value != productId;
                });

                selectedProducts = $.grep(selectedProducts, function(product) {
                    return product.id != productId;
                });

                setTotalPriceAccumulation();
            });

            // ajax get product discount berdasarkan uom dan qty
            function getProductDiscount(product, qty = 1, uomId = null) {
                return new Promise((resolve, reject) => {
                    let discount = 0;

                    if (product.customer_group_product_discounts) {
                        let discounts = product.customer_group_product_discounts;
                        if (discounts) {
                            let discountKey = Object.keys(discounts)
                                .filter(key => parseInt(key) <= qty)
                                .pop()

                            if (discounts[discountKey]) discount = discounts[discountKey];
                        }
                    } else {
                        let defaultProductUom = product?.uoms.find((uom) => {
                            if (uomId) return uom.id == uomId;

                            return uom.pivot.is_default === true;
                        });

                        if (defaultProductUom) {
                            let discounts = defaultProductUom.pivot?.discounts;
                            if (discounts) {
                                let discountKey = Object.keys(discounts)
                                    .filter(key => parseInt(key) <= qty)
                                    .pop()

                                if (discounts[discountKey]) discount = discounts[discountKey];
                            }
                        }
                    }

                    resolve(discount);
                });
            }

            // fungsi untuk add product
            $('#add-product').on('click', async function() {
                let productId = $('#product_id').val();
                if (productId) {
                    try {
                        let customerId = document.getElementById('customer_id').value;
                        let product = await getProduct(productId, '{{ $currentConnection }}',
                            customerId); // get product ke fungsi getProduct()
                        // create element untuk select uoms, nanti di append di table
                        let defaultUomQty = 0;

                        let uomsSelectForm =
                            `<select name="items[${i}][uom_id]" class="form-control select2 input-product-uom_id" required>`;
                        $.each(product.uoms, function(i, uom) {
                            if (uom.id == product.default_uom_id) {
                                defaultUomQty = uom.pivot.quantity;
                            }
                            uomsSelectForm +=
                                `<option value="${uom.id}" ${uom.pivot.is_default && 'selected'} data-product_id="${product.id}">${uom.name}</option>`;
                        });
                        uomsSelectForm += `</select>`;

                        let priceHistories = ``;
                        $.each(product.priceHistory, function(date, history) {
                            priceHistories +=
                                `<option>${history}  ${date}</option>`
                        });

                        let selectBooks =
                            `<select name="items[${i}][book]" id="input-book" class="form-control select2 input-book" required>`;
                        if (Object.keys(product.select_books).length > 1) {
                            selectBooks +=
                                `<option value="${product.select_books['MYSQL']}" data-product_id="${product.id}" selected >Book @if ($currentConnection == 'mysql') 1 @else 2 @endif</option>`;
                            selectBooks +=
                                `<option value="${product.select_books['MYSQL_SECONDARY']}" data-product_id="${product.id}">Book @if ($currentConnection == 'mysql') 2 @else 1 @endif</option>`;
                        } else {
                            $.each(product.select_books, function(i, book) {
                                selectBooks +=
                                    `<option value="${book}" data-product_id="${product.id}" selected >Book @if ($currentConnection == 'mysql') 1 @else 2 @endif</option>`;
                            });
                        }
                        selectBooks += `</select>`;

                        let discount = await getProductDiscount(product) * 100 / product.sell_price;


                        let html = `<tr>
                            <input type="hidden" name="items[${i}][product_id]" class="input-product-id" value="${product.id}"/>
                            <td>${product.id}</td>
                            <td>${product.name}</td>
                            <td style="width: 11%">${selectBooks}</td>
                            <td style="width: 7%">
                                <input type="number" name="items[${i}][qty]" value="1" class="form-control input-product-qty" data-price="${product.sell_price}" min="1" @if ($stockCheck == false) max="${Math.floor(product.stock.qty / defaultUomQty)}" @endif/>
                                </td>
                            <td style="width: 9%">${uomsSelectForm}</td>
                            <td class="input-product-stock" style="background-color: #D3D3D3">${Math.floor(product.stock.qty / defaultUomQty)}</td>
                            <td>
                                <input value="${customToFixed(product.sell_price)}" name="items[${i}][unit_price]" class="form-control input-product-price" min="0" data-type="currency" list="priceHistories"/>
                                <datalist id="priceHistories" class="priceHistories">
                                    ${priceHistories}
                                </datalist>
                                <span class="error invalid-feedback">Sell price lower than capital price</span>
                            </td>
                            <td class="d-flex">
                                <input type="number" step="any" name="items[${i}][discount]" class="form-control input-discount" max="100" value="${discount}"/> %
                            </td>
                            <td>
                                <input value="${customToFixed(product.sell_price)}" class="form-control price-format input-product-total-price" min="0" readonly disabled/>
                            </td>
                            <td style="width: 2%">
                                <button type="button" class="btn btn-danger btn-sm btn-delete"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>`;

                        i = i + 1;
                        // cek kalo productnya sudah di insert ke table jangan di insert lagi
                        if (!selectedProductIds.includes(product.id.toString())) {
                            selectedProducts.push(
                                product
                            ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            // selectedProductIds.push(
                            //     productId
                            // ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            $('#table-body').append(html).find('.input-book').focus();
                            $('#product_id').val('').change();
                            setTotalPriceAccumulation();

                            initPriceFormat();
                        }
                    } catch (error) {
                        // handle jika get product nya error
                        toastr.error(error.message);
                    }
                }
            });

            $('body').on('change', '.input-product-qty', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            // fungsi untuk handle ketika +/- qty
            $('body').on('change', '.input-product-qty', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            $('body').on('change', '.input-product-price', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            // fungsi untuk handle ketika ceklist ppn
            $('body').on('change', '.input-ppn', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                setTotalPricePerProduct(parent, false);
            });

            // fungsi untuk handle ketika discount diubah
            $('body').on('keyup', '.input-discount', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                setTotalPricePerProduct(parent, false);
            });

            $('body').on('change', '.input-book', async function() {
                let productId = $(this).find(':selected').data('product_id');
                let databaseConnection = $(this).val();
                let product = await getProduct(productId, databaseConnection);
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let selectedUomId = parent.find('.input-product-uom_id').val();
                // let product = selectedProducts.filter(product => product.id == productId);
                try {
                    let customerId = $('#customer_id').val();
                    let productUom = await getProductUom(productId, selectedUomId, databaseConnection,
                        customerId);
                    let stock = Math.floor(product.stock.qty / productUom.quantity);

                    if ({{ $stockCheck }} == 0) {
                        parent.find('.input-product-qty').attr({
                            "max": stock,
                        });
                    }
                    parent.find('.input-product-stock').text(stock);
                    parent.find('.input-product-price').val(productUom.sell_price);
                    parent.find('.input-product-qty').data('price', productUom.sell_price);

                    setTotalPricePerProduct(parent);
                } catch (error) {
                    // handle jika get product nya error
                    toastr.error(error.message);
                }
            });

            $('body').on('change', '.input-product-uom_id', async function() {
                let selectedUomId = $(this).val();
                let productId = $(this).find(':selected').data('product_id');
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let product = selectedProducts.filter(product => product.id == productId);
                try {
                    let customerId = $('#customer_id').val();
                    let productUom = await getProductUom(productId, selectedUomId,
                        '{{ $currentConnection }}', customerId);
                    let stock = Math.floor(product[0].stock.qty / productUom.quantity);

                    let priceHistories = ``;
                    $.each(productUom.priceHistory, function(i, history) {
                        priceHistories +=
                            `<option>${history}</option>`
                    });

                    parent.find(".priceHistories").html(priceHistories);

                    if ({{ $stockCheck }} == 0) {
                        parent.find('.input-product-qty').attr({
                            "max": stock,
                        });
                    }
                    parent.find('.input-product-stock').text(stock);
                    parent.find('.input-product-price').val(productUom.sell_price);
                    parent.find('.input-product-qty').data('price', productUom.sell_price);

                    setTotalPricePerProduct(parent);
                } catch (error) {
                    // handle jika get product nya error
                    toastr.error(error.message);
                }
            });

            // fungsi untuk hitung total akumulasi harga per product
            // fungsi ini akan dipanggil ketika +/- product, ceklist ppn, dan ganti uom
            async function setTotalPricePerProduct(parent, isCountOriginalDiscount = true) {
                let productId = parent.find('.input-product-id').val();
                let qty = parent.find('.input-product-qty').val();
                let selectedUomId = parent.find('.input-product-uom_id').val();

                let product = selectedProducts?.find(product => product.id == productId);
                if (isCountOriginalDiscount === true) {
                    if (product) {
                        let discount = await getProductDiscount(product, qty, selectedUomId) * 100 / product
                            .sell_price;
                        parent.find('.input-discount').val(discount)
                    }
                }

                let discount = parent.find('.input-discount').val();
                let price = unformatPrice(parent.find('.input-product-price').val());
                let totalPrice = (price - (discount / 100 * price)) * qty;

                if (totalPrice / qty < product.capital_price) {
                    parent.find('.input-product-price').addClass('is-invalid')
                } else {
                    parent.find('.input-product-price').removeClass('is-invalid')
                }

                // cek kalo pake ppn tambahin 11% dari harga
                if (parent.find('.input-ppn').is(':checked')) {
                    totalPrice = totalPrice + parseFloat(totalPrice * 0.11);
                }

                // set total price nya ke total price per product
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                parent.find('.input-product-total-price').val(customToFixed(totalPrice));

                setTotalPriceAccumulation();
            }

            $('body').on('keyup', '#input-additional-discount', function() {
                subTotal = unformatPrice($('#sub-total-accumulation').val());
                additionalDiscount = unformatPrice($(this).val());
                $('#input-additional-discount-percentage').val(customToFixed(additionalDiscount / subTotal *
                    100))

                setTotalPriceAccumulation();
            });

            $('body').on('change', '#input-additional-discount-percentage', function() {
                subTotal = unformatPrice($('#sub-total-accumulation').val());
                additionalDiscount = $(this).val();

                $('#input-additional-discount').val(customToFixed(additionalDiscount * subTotal / 100))
                setTotalPriceAccumulation();
            });

            // fungsi untuk hitung total akumulasi harga keseluruhan
            // fungsi ini akan dipanggil add product, hapus product, dan ketika fungsi setTotalPricePerProduct() dipanggil
            function setTotalPriceAccumulation() {
                let totalPrice = 0;

                // looping element total price per product, lalu di sum()
                $('.input-product-total-price').each(function(i) {
                    totalPrice += unformatPrice($(this).val());
                });

                // set total price nya ke total price keseluruhan
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                $('#sub-total-accumulation').val(customToFixed(totalPrice));

                let additionalDiscount = 0;
                additionalDiscountPercentage = $('#input-additional-discount-percentage').val() ?? 0;

                additionalDiscount = customToFixed(additionalDiscountPercentage * totalPrice / 100);
                $('#input-additional-discount').val(additionalDiscount);


                if (additionalDiscount > totalPrice) {
                    totalPrice = 0;
                } else {
                    totalPrice = totalPrice - additionalDiscount;
                }

                $('#total-price-accumulation').val(customToFixed(totalPrice));
                $('#payment_amount').val(customToFixed(totalPrice)).removeClass('is-invalid');;

                initPriceFormat();
            }

            // ajax get product dengan promise
            function getProduct(productId, databaseConnection = 'mysql', customerId = null) {
                return new Promise((resolve, reject) => {
                    $.get('{{ url('api/products/get-product-by-db') }}/' + productId +
                        '?databaseConnection=' + databaseConnection + '&customerId=' + customerId,
                        function(res) {
                            if (res) {
                                resolve(res);
                            } else {
                                reject(new Error('product not found'))
                            }
                        });
                });
            }

            function getProductUom(productId, uomId, databaseConnection = 'mysql', customerId = null) {
                return new Promise((resolve, reject) => {
                    $.get(`{{ url('api/products/get-price-by-db') }}/${productId}/${uomId}` +
                        '?databaseConnection=' + databaseConnection + '&customerId=' + customerId,
                        function(res) {
                            if (res) {
                                resolve(res);
                            } else {
                                reject(new Error('product uom not found'))
                            }
                        });
                });
            }
        });
    </script>
@endpush
