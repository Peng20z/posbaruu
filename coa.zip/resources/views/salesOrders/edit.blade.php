@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('sales-orders.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('sales-orders.update', $salesOrder) }}"
                                class="form-loading">
                                @csrf
                                @method('PUT')
                                <div class="card card-primary card-outline shadow">
                                    <div class="card-header">
                                        <h3 class="card-title">Sales Order</h3>
                                    </div>
                                    @csrf
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label>Code</label>
                                            <input type="text" name="code"
                                                class="form-control @error('code') is-invalid @enderror"
                                                value="{{ $salesOrder->code }}">
                                            @error('code')
                                                <span class="error invalid-feedback">Code has been used</span>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label class="required">Transaction Date</label>
                                            <div class="input-group date" id="filter-date" data-target-input="nearest"
                                                data-toggle="datetimepicker">
                                                <input type="text" name="transaction_datetime"
                                                    value="{{ $salesOrder->transaction_datetime }}"
                                                    class="form-control datetimepicker-input" data-target="#filter-date"
                                                    required />
                                                <div class="input-group-append" data-target="#filter-date">
                                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="required">Customer</label>
                                            <select name="customer_id" id="customer_id"
                                                class="form-control select2 @error('customer_id') is-invalid @enderror"
                                                required>
                                                @foreach ($customers as $id => $name)
                                                    <option value="{{ $id }}"
                                                        @if (old('customer_id', $salesOrder->customer_id) == $id) selected @endif>
                                                        {{ $name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @error('customer_id')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                        <div class="form-group">
                                            <label class="">Description</label>
                                            <textarea name="description" id="description" rows="2" class="form-control">{{ $salesOrder->description }}</textarea>
                                            @error('description')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                <div class="card card-primary card-outline shadow">
                                    <div class="card-header">
                                        <h3 class="card-title">Sales Order Details</h3>
                                    </div>
                                    <div class="card-body">
                                        <label>Product</label>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>Code</th>
                                                        <th>Product Name</th>
                                                        <th>Book</th>
                                                        <th>Qty</th>
                                                        <th>Uom</th>
                                                        <th style="background-color: #D3D3D3">Stock</th>
                                                        <th>Unit Price</th>
                                                        <th>Discount</th>
                                                        <th>Total Price</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody id="table-body">
                                                    @foreach ($salesOrder->details as $i => $detail)
                                                        <tr class="detail-row">
                                                            <input type="hidden"
                                                                name="items[{{ $i }}][product_id]"
                                                                class="input-product-id"
                                                                value="{{ $detail->product_id }}" />
                                                            <input type="hidden" name="items[{{ $i }}][code]"
                                                                class="input-code" value="{{ $detail->code }}" />
                                                            <td>{{ $detail->product_id }}</td>
                                                            <td>{{ $detail->product?->name }}</td>
                                                            <td style="width: 10%"><select
                                                                    name="items[{{ $i }}][book]" id="book"
                                                                    class="form-control input-book" required>

                                                                    @if (count($detail->product->select_books) > 1)
                                                                        <option value="{{ $databaseConnections['MYSQL'] }}"
                                                                            data-product_id="{{ $detail->product_id }}"
                                                                            @if ($detail->code_decrypt['db'] == $currentConnection) selected @endif>
                                                                            Book
                                                                            @if ($currentConnection == 'mysql')
                                                                                1
                                                                            @else
                                                                                2
                                                                            @endif
                                                                        </option>
                                                                        <option
                                                                            value="{{ $databaseConnections['MYSQL_SECONDARY'] }}"
                                                                            data-product_id="{{ $detail->product_Id }}"
                                                                            @if ($detail->code_decrypt['db'] != $currentConnection) selected @endif>
                                                                            Book
                                                                            @if ($currentConnection == 'mysql')
                                                                                2
                                                                            @else
                                                                                1
                                                                            @endif
                                                                        </option>
                                                                    @else
                                                                        <option value="{{ $databaseConnections['MYSQL'] }}"
                                                                            data-product_id="{{ $detail->product_id }}"
                                                                            @if ($detail->code_decrypt['db'] == $currentConnection) selected @endif>
                                                                            Book
                                                                            @if ($currentConnection == 'mysql')
                                                                                1
                                                                            @else
                                                                                2
                                                                            @endif
                                                                        </option>
                                                                    @endif

                                                                </select>
                                                            </td>
                                                            <td>
                                                                <input type="number"
                                                                    name="items[{{ $i }}][qty]"
                                                                    value="{{ $detail->qty }}"
                                                                    class="form-control input-product-qty" min="1"
                                                                    @if ($stockCheck == false) max="{{ floor($detail->product?->stock?->qty / $detail->selectedUom?->quantity) }}" @endif />
                                                            </td>
                                                            <td style="width: 8%"><select
                                                                    name="items[{{ $i }}][uom_id]"
                                                                    id="uom_id" class="form-control input-uom" required>
                                                                    @foreach ($detail->product->uoms as $uom)
                                                                        <option value="{{ $uom->id }}"
                                                                            @if (old('uom_id', $detail->uom_id) == $uom->id) selected @endif>
                                                                            {{ $uom->name }}</option>
                                                                    @endforeach
                                                                </select></td>
                                                            <td class="input-product-stock"
                                                                style="background-color: #D3D3D3">
                                                                {{ floor($detail->product?->stock?->qty / $detail->selectedUom?->quantity) }}
                                                            </td>
                                                            <td>
                                                                <div class="d-flex">
                                                                    <input value="{{ $detail->unit_price }}"
                                                                        name="items[{{ $i }}][unit_price]"
                                                                        class="form-control input-product-price @if (($detail->unit_price * (100 - $detail->discount)) / 100 < $detail->product->capital_price) is-invalid @endif"
                                                                        min="0" data-type="currency">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-toggle="modal"
                                                                        data-target="#mdlPriceHistory{{ $i }}"><i
                                                                            class="fa fa-history"></i></button>
                                                                    <div class="modal inmodal fade"
                                                                        id="mdlPriceHistory{{ $i }}"
                                                                        role="dialog" tabindex="-1" aria-hidden="true">
                                                                        <div class="modal-dialog modal-lg">
                                                                            <div class="modal-content">
                                                                                <div class="modal-body">
                                                                                    <label for="">History</label>
                                                                                    <br>
                                                                                    <table
                                                                                        class="table table-bordered table-hover">
                                                                                        <tr>
                                                                                            <th>Date</th>
                                                                                            <th>Unit Price</th>
                                                                                            <th>Discount</th>
                                                                                            <th>Total Price</th>
                                                                                        </tr>
                                                                                        @foreach ($detail->priceHistories as $priceHistory)
                                                                                            <tr class="price-history"
                                                                                                data-price={{ $priceHistory->unit_price }}
                                                                                                data-discount={{ $priceHistory->total_discount }}>
                                                                                                <td>{{ $priceHistory->transaction_datetime }}
                                                                                                </td>
                                                                                                <td class="price-format">
                                                                                                    {{ $priceHistory->unit_price }}
                                                                                                </td>
                                                                                                <td>{{ $priceHistory->total_discount }}%
                                                                                                </td>
                                                                                                <td class="price-format">
                                                                                                    {{ $priceHistory->unit_price * (100 - $priceHistory->total_discount) }}
                                                                                                </td>
                                                                                            </tr>
                                                                                        @endforeach
                                                                                    </table>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <span class="error invalid-feedback">Sell price lower
                                                                        than
                                                                        capital price</span>
                                                                </div>
                                                            </td>
                                                            <td class="d-flex">
                                                                <input step="any"
                                                                    name="items[{{ $i }}][discount]"
                                                                    max="100" class="form-control input-discount"
                                                                    value="{{ $detail->total_discount }}" />%
                                                            </td>
                                                            <td>
                                                                <input value="{{ $detail->total_price }}"
                                                                    class="form-control price-format input-product-total-price"
                                                                    min="0" readonly disabled />
                                                            </td>
                                                            <td>
                                                                <button type="button"
                                                                    class="btn btn-danger btn-sm btn-delete"><i
                                                                        class="fa fa-trash"></i></button>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="9" class="border-left-0 border-right-0 pt-5">
                                                            <div class="form-group">
                                                                <div class="d-flex">
                                                                    <select name="product_id" id="product_id"
                                                                        class="form-control w-75">
                                                                    </select>
                                                                    <button class="btn btn-primary ml-2" id="add-product"
                                                                        type="button"><i class="fa fa-plus"></i> Add
                                                                        Product</button>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="8">Sub Total</th>
                                                        <th>
                                                            <input type="text" class="form-control price-format"
                                                                value="{{ rupiah($salesOrder->details->sum('total_price')) }}"
                                                                id="sub-total-accumulation" readonly disabled>
                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="7">Additional Discount</th>
                                                        <th class="d-flex">
                                                            <input type="number" step="any" class="form-control"
                                                                name="additional_discount"
                                                                value="{{ rupiah($salesOrder->additional_discount) }}"
                                                                id="input-additional-discount-percentage" max="100">
                                                            <p class=""> %</p>
                                                        </th>
                                                        <th>
                                                            <input type="text" class="form-control price-format"
                                                                value="{{ number_format(($salesOrder->additional_discount / 100) * $salesOrder->total_price, 2) ?? 0 }}"
                                                                id="input-additional-discount">
                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                    <tr>
                                                        <th colspan="8">Grand Total</th>
                                                        <th>
                                                            <input type="text" class="form-control price-format"
                                                                value="{{ rupiah($salesOrder->total_price) }}"
                                                                id="total-price-accumulation" readonly disabled>
                                                        </th>
                                                        <th></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>

                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary" id="clickToSubmit">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            let selectedProducts = []; // buat nampung products yg sudah terpilih
            let selectedProductIds = []; // buat nampung id product yg sudah terpilih

            let customerId = document.getElementById('customer_id').value;
            async function initSelectedProducts() {
                @foreach ($salesOrder->details->pluck('product_id') as $productId)
                    selectedProducts.push(await getProduct('{{ $productId }}', '{{ $currentConnection }}',
                        customerId));
                @endforeach
            }
            initSelectedProducts()

            let i = {{ $salesOrder->details->count() }};

            if ((screen.width < 1440)) {
                $("#customer_id").val(2).change();
            }

            $("#clickToSubmit").on("keydown", function(e) {
                if (e.keyCode === 13) {
                    e.preventDefault();
                }
            });

            $('#filter-date').datetimepicker({
                defaultDate: new Date(),
                timePicker: true,
                timePicker24Hour: true,
                format: 'YYYY-MM-DD HH:mm:ss',

                icons: {
                    time: 'far fa-clock'
                }
            });

            // get products
            $('#product_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Select product',
                ajax: {
                    url: '{{ route('api.products.index') }}',
                    dataType: 'json',
                    delay: 300,
                    data: function(params) {
                        return {
                            'per_page': 30,
                            'select': 'id,name as text', // select2 only accept return data (id and text)
                            'filter[name]': params.term, // search term / search by nama product
                            'filter[ids]': selectedProductIds
                                .toString(), // search where id product not in
                            'filter[is_active]': 1,
                            page: params.page || params.current_page || 1
                        };
                    },
                    processResults: function(data, params) {
                        params.current_page = params.current_page || 1;
                        return {
                            results: data.data,
                            pagination: {
                                more: (params.current_page * 30) < data.total
                            }
                        };
                    },
                    autoWidth: true,
                    cache: true
                }
            });

            // fungsi ketika hapus product
            $('body').on('click', '.btn-delete', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let productId = parent.find('.input-product-id').val(); // get product id

                parent.remove(); // hapus element parent(<tr>) nya

                // hapus id product dari variable selectedProductIds
                selectedProductIds = $.grep(selectedProductIds, function(value) {
                    return value != productId;
                });

                selectedProducts = $.grep(selectedProducts, function(product) {
                    return product.id != productId;
                });

                setTotalPriceAccumulation();
            });

            // ajax get product discount berdasarkan uom dan qty
            function getProductDiscount(product, qty = 1, uomId = null) {
                return new Promise((resolve, reject) => {
                    let discount = 0;

                    if (product.customer_group_product_discounts) {
                        let discounts = product.customer_group_product_discounts;
                        if (discounts) {
                            let discountKey = Object.keys(discounts)
                                .filter(key => parseInt(key) <= qty)
                                .pop()

                            if (discounts[discountKey]) discount = discounts[discountKey];
                        }
                    } else {
                        let defaultProductUom = product?.uoms.find((uom) => {
                            if (uomId) return uom.id == uomId;

                            return uom.pivot.is_default === true;
                        });

                        if (defaultProductUom) {
                            let discounts = defaultProductUom.pivot?.discounts;
                            if (discounts) {
                                let discountKey = Object.keys(discounts)
                                    .filter(key => parseInt(key) <= qty)
                                    .pop()

                                if (discounts[discountKey]) discount = discounts[discountKey];
                            }
                        }
                    }

                    resolve(discount);
                });
            }

            // fungsi untuk add product
            $('#add-product').on('click', async function() {
                let productId = $('#product_id').val();
                if (productId) {
                    try {
                        let customerId = document.getElementById('customer_id').value;
                        let product = await getProduct(productId, '{{ $currentConnection }}',
                            customerId); // get product ke fungsi getProduct()
                        // create element untuk select uoms, nanti di append di table
                        let defaultUomQty = 0;

                        let uomsSelectForm =
                            `<select name="items[${i}][uom_id]" class="form-control select2 input-product-uom_id" required>`;
                        $.each(product.uoms, function(i, uom) {
                            if (uom.id == product.default_uom_id) {
                                defaultUomQty = uom.pivot.quantity;
                            }
                            uomsSelectForm +=
                                `<option value="${uom.id}" ${uom.pivot.is_default && 'selected'} data-product_id="${product.id}">${uom.name}</option>`;
                        });
                        uomsSelectForm += `</select>`;

                        let priceHistories = ``;
                        $.each(product.priceHistory, function(index, value) {
                            let totalPrice = value.unit_price * (100 - value.total_discount);
                            priceHistories +=
                                `<tr class="price-history" data-price=${value.unit_price} data-discount=${value.total_discount}>
                                    <td>${value.transaction_datetime}</td>
                                    <td class="price-format">${value.unit_price}</td>
                                    <td>${value.total_discount}%</td>
                                    <td class="price-format">${totalPrice}</td>
                                </tr>`
                        });

                        let discount = await getProductDiscount(product) * 100 / product.sell_price;

                        let html = `<tr class="detail-row">
                            <input type="hidden" name="items[${i}][product_id]" class="input-product-id" value="${product.id}"/>
                            <td>${product.id}</td>
                            <td>${product.name}</td>
                            <td style="width: 10%"><select name="items[${i}][book]"  id="book" class="form-control select2 input-book" required>
                                    <option value="{{ $databaseConnections['MYSQL'] }}" data-product_id="${product.id}" selected >Book @if ($currentConnection == 'mysql') 1 @else 2 @endif</option>
                                    <option value="{{ $databaseConnections['MYSQL_SECONDARY'] }}" data-product_id="${product.id}">Book @if ($currentConnection == 'mysql') 2 @else 1 @endif</option>
                                </select></td>
                            <td style="width: 7%">
                                <input type="number" name="items[${i}][qty]" value="1" class="form-control input-product-qty" data-price="${product.sell_price}" min="1" @if ($stockCheck == false) max="${Math.floor(product.stock.qty / defaultUomQty)}" @endif/>
                                </td>
                            <td style="width: 8%">${uomsSelectForm}</td>
                            <td class="input-product-stock" style="background-color: #D3D3D3">${Math.floor(product.stock.qty / defaultUomQty)}</td>
                            <td>
                                <div class="d-flex">
                                    <input value="${product.sell_price}" name="items[${i}][unit_price]" class="form-control input-product-price" data-type="currency" min="0"/>
                                    <button type="button" class="btn btn-secondary" data-toggle="modal"
                                        data-target="#mdlPriceHistory${i}"><i class="fa fa-history"></i></button>
                                        <div class="modal inmodal fade" id="mdlPriceHistory${i}" role="dialog" tabindex="-1"
                                            aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                    <div class="modal-body">
                                                        <label for="">History</label> <br>
                                                        <table class="table table-bordered table-hover">
                                                            <tr>
                                                                <th>Date</th>
                                                                <th>Unit Price</th>
                                                                <th>Discount</th>
                                                                <th>Total Price</th>
                                                            </tr>
                                                            ${priceHistories}
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <span class="error invalid-feedback">Sell price lower than capital price</span>
                                </div>
                            </td>
                            <td class="d-flex">
                                <input step="any" name="items[${i}][discount]" class="form-control input-discount" max="100" value="${discount}"/> %
                            </td>
                            <td>
                                <input value="${product.sell_price}" class="form-control price-format input-product-total-price" min="0" readonly disabled/>
                            </td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm btn-delete"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>`;

                        i = i + 1;
                        // cek kalo productnya sudah di insert ke table jangan di insert lagi
                        if (!selectedProductIds.includes(product.id.toString())) {
                            selectedProducts.push(
                                product
                            ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            // selectedProductIds.push(
                            //     productId
                            // ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            $('#table-body').append(html).find('.input-book').focus();
                            $('#product_id').val('').change();
                            setTotalPriceAccumulation();

                            initPriceFormat();
                            // $('.price-format').priceFormat({
                            //     prefix: '',
                            //     centsLimit: 0,
                            //     thousandsSeparator: '.'
                            // });
                        }
                    } catch (error) {
                        // handle jika get product nya error
                        toastr.error(error.message);
                    }
                }
            });

            $('body').on('click', '.price-history', function() {
                let price = $(this).data('price');
                let discount = $(this).data('discount');

                let parent = $(this).closest('.detail-row');
                parent.find('.input-product-price').val(price);
                parent.find('.input-discount').val(discount);
                $('.modal').modal('hide');

                setTotalPricePerProduct(parent, false);
            });

            // fungsi untuk handle ketika +/- qty
            $('body').on('change', '.input-product-qty', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            $('body').on('change', '.input-product-price', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            // fungsi untuk handle ketika ceklist ppn
            $('body').on('change', '.input-ppn', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                setTotalPricePerProduct(parent, false);
            });

            // fungsi untuk handle ketika discount diubah
            $('body').on('keyup', '.input-discount', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                setTotalPricePerProduct(parent, false);
            });

            $('body').on('change', '.input-book', async function() {
                let productId = $(this).find(':selected').data('product_id');
                let databaseConnection = $(this).val();
                let product = await getProduct(productId, databaseConnection);
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let selectedUomId = parent.find('.input-product-uom_id').val();
                // let product = selectedProducts.filter(product => product.id == productId);
                try {
                    let customerId = $('#customer_id').val();
                    let productUom = await getProductUom(productId, selectedUomId, databaseConnection,
                        customerId);
                    let stock = Math.floor(product.stock.qty / productUom.quantity);

                    if ({{ $stockCheck }} == 0) {
                        parent.find('.input-product-qty').attr({
                            "max": stock,
                        });
                    }
                    parent.find('.input-product-stock').text(stock);
                    parent.find('.input-product-price').val(productUom.sell_price);
                    parent.find('.input-product-qty').data('price', productUom.sell_price);

                    setTotalPricePerProduct(parent);
                } catch (error) {
                    // handle jika get product nya error
                    toastr.error(error.message);
                }
            });

            $('body').on('change', '.input-product-uom_id', async function() {
                let selectedUomId = $(this).val();
                let productId = $(this).find(':selected').data('product_id');
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let product = selectedProducts.filter(product => product.id == productId);
                try {
                    let customerId = $('#customer_id').val();
                    let productUom = await getProductUom(productId, selectedUomId,
                        '{{ $currentConnection }}', customerId);
                    let stock = Math.floor(product[0].stock.qty / productUom.quantity);

                    let priceHistories = ``;
                    $.each(productUom.priceHistory, function(date, history) {
                        priceHistories +=
                            `<option value="${history}">${history} ${date}</option>`
                    });

                    let discHistories = ``;
                    $.each(productUom.discHistory, function(date, history) {
                        discHistories +=
                            `<option value="${history}">${history}% ${date}</option>`
                    });

                    parent.find(".priceHistories").html(priceHistories);
                    parent.find(".discHistories").html(discHistories);

                    if ({{ $stockCheck }} == 0) {
                        parent.find('.input-product-qty').attr({
                            "max": stock,
                        });
                    }
                    parent.find('.input-product-stock').text(stock);
                    parent.find('.input-product-price').val(productUom.sell_price);
                    parent.find('.input-product-qty').data('price', productUom.sell_price);

                    setTotalPricePerProduct(parent);
                } catch (error) {
                    // handle jika get product nya error
                    toastr.error(error.message);
                }
            });

            // fungsi untuk hitung total akumulasi harga per product
            // fungsi ini akan dipanggil ketika +/- product, ceklist ppn, dan ganti uom
            async function setTotalPricePerProduct(parent, isCountOriginalDiscount = true) {
                let productId = parent.find('.input-product-id').val();
                console.log(productId);
                let qty = parent.find('.input-product-qty').val();
                let selectedUomId = parent.find('.input-product-uom_id').val();

                console.log('selectedProduct', selectedProducts)
                let product = selectedProducts?.find(product => product.id == productId);
                console.log('product', product);
                if (isCountOriginalDiscount === true) {
                    if (product) {
                        let discount = await getProductDiscount(product, qty, selectedUomId) * 100 / product
                            .sell_price;
                        parent.find('.input-discount').val(discount)
                    }
                }

                let discount = parent.find('.input-discount').val();
                let price = unformatPrice(parent.find('.input-product-price').val());
                let totalPrice = (price - (discount / 100 * price)) * qty;

                if (totalPrice / qty < product.capital_price) {
                    parent.find('.input-product-price').addClass('is-invalid')
                } else {
                    parent.find('.input-product-price').removeClass('is-invalid')
                }

                // cek kalo pake ppn tambahin 11% dari harga
                if (parent.find('.input-ppn').is(':checked')) {
                    totalPrice = totalPrice + parseInt(totalPrice * 0.11);
                }

                // set total price nya ke total price per product
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                parent.find('.input-product-total-price').val(customToFixed(totalPrice));

                setTotalPriceAccumulation();
            }

            $('body').on('change', '#input-additional-discount', function() {
                subTotal = unformatPrice($('#sub-total-accumulation').val());
                additionalDiscount = unformatPrice($(this).val());
                $('#input-additional-discount-percentage').val(customToFixed(additionalDiscount / subTotal *
                    100))

                setTotalPriceAccumulation();
            });

            $('body').on('change', '#input-additional-discount-percentage', function() {
                subTotal = unformatPrice($('#sub-total-accumulation').val());
                additionalDiscount = $(this).val();

                $('#input-additional-discount').val(customToFixed(additionalDiscount * subTotal / 100))
                setTotalPriceAccumulation();
            });

            // fungsi untuk hitung total akumulasi harga keseluruhan
            // fungsi ini akan dipanggil add product, hapus product, dan ketika fungsi setTotalPricePerProduct() dipanggil
            function setTotalPriceAccumulation() {
                let totalPrice = 0;

                // looping element total price per product, lalu di sum()
                $('.input-product-total-price').each(function(i) {
                    totalPrice += unformatPrice($(this).val());
                });

                // set total price nya ke total price keseluruhan
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                $('#sub-total-accumulation').val(customToFixed(totalPrice));

                let additionalDiscount = 0;
                additionalDiscountPercentage = $('#input-additional-discount-percentage').val() ?? 0;

                additionalDiscount = customToFixed(additionalDiscountPercentage * totalPrice / 100);
                $('#input-additional-discount').val(additionalDiscount);

                if (additionalDiscount > totalPrice) {
                    totalPrice = 0;
                } else {
                    totalPrice = totalPrice - additionalDiscount;
                }
                $('#total-price-accumulation').val(customToFixed(totalPrice));

                initPriceFormat();
            }

            // ajax get product dengan promise
            function getProduct(productId, databaseConnection = 'mysql', customerId = null) {
                return new Promise((resolve, reject) => {
                    $.get('{{ url('api/products/get-product-by-db') }}/' + productId +
                        '?databaseConnection=' + databaseConnection + '&customerId=' + customerId,
                        function(res) {
                            if (res) {
                                resolve(res);
                            } else {
                                reject(new Error('product not found'))
                            }
                        });
                });
            }

            function getProductUom(productId, uomId, databaseConnection = 'mysql', customerId = null) {
                return new Promise((resolve, reject) => {
                    $.get(`{{ url('api/products/get-price-by-db') }}/${productId}/${uomId}` +
                        '?databaseConnection=' + databaseConnection + '&customerId=' + customerId,
                        function(res) {
                            if (res) {
                                resolve(res);
                            } else {
                                reject(new Error('product uom not found'))
                            }
                        });
                });
            }
        });
    </script>
@endpush
