@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col">
                        <h1>Report Purchase Orders</h1>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="list-group">
                <a class="list-group-item list-group-item-action" href="{{ route('reports.purchase-orders.pembelianPerBarang')}}">Pembelian per Barang</a>
                <a class="list-group-item list-group-item-action" href="{{ route('reports.purchase-orders.pembelianPerBarang')}}">Pembelian per Supplier</a>
                <a class="list-group-item list-group-item-action" href="{{ route('reports.purchase-orders.pembelianPerBarang')}}">Retur Pembelian per Barang</a>
                <a class="list-group-item list-group-item-action" href="{{ route('reports.purchase-orders.pembelianPerBarang')}}">Retur Pembelian per Supplier</a>
              </div>
        </section>
    </div>
@endsection
