@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('purchase-invoices.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('purchase-invoices.store') }}" class="form-loading">
                                @csrf
                                <div class="card-body">
                                    <x-source-destination-account :sourceCoaId="$sourceCoaId" :destinationCoaId="$destinationCoaId" />
                                    <div class="form-group">
                                        <label class="required">Purchase Order</label>
                                        <select name="purchase_order_id" id="purchase_order_id"
                                            class="form-control select2 @error('purchase_order_id') is-invalid @enderror"
                                            required>
                                            <option value="null">- Select Purchase Order -</option>
                                            @foreach ($purchaseOrders as $purchaseOrder)
                                                <option value="{{ $purchaseOrder->code }}"
                                                    @if (old('purchase_order_id') == $purchaseOrder->id) selected @endif
                                                    data-price="{{ $purchaseOrder->total_price }}">{{ $purchaseOrder->code }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('purchase_order_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Code</label>
                                        <input name="code" id="code" type="text"
                                            class="form-control @error('code') is-invalid @enderror"
                                            placeholder="code" required>
                                        @error('code')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Payment Type</label>
                                        <select name="payment_type_id" id="payment_type_id"
                                            class="form-control select2 @error('payment_type_id') is-invalid @enderror"
                                            required>
                                            @foreach ($paymentTypes as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('payment_type_id') == $id) selected @endif>
                                                    {{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('payment_type_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Unpaid Payment</label>
                                        <input id=payment_left type="text" class="form-control price-format"
                                            placeholder="Payment Left" disabled readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Amount</label>
                                        <input name="amount" id="amount" type="text" value="{{ old('amount') }}"
                                            class="form-control price-format @error('amount') is-invalid @enderror"
                                            placeholder="amount" required>
                                        @error('amount')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Status</label>
                                        <select name="status" id="status"
                                            class="form-control select2 @error('status') is-invalid @enderror" required>
                                            @foreach ($paymentStatuses as $paymentStatus)
                                                <option value="{{ $paymentStatus->value }}"
                                                    @if (old('status') == $paymentStatus->value) selected @endif>
                                                    {{ $paymentStatus->description }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('status')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group @error('description') has-error @enderror">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control" rows="5" placeholder="Description">{{ old('description') }}</textarea>
                                        @error('description')
                                            <span class="form-text m-b-none text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('body').on('change', '#purchase_order_id', async function() {
                let purchaseOrder = await getUnpaid($(this).val());
                let amount = customToFixed(purchaseOrder.total_price - purchaseOrder.total_paid)

                $('#amount').val(amount);
                $('#payment_left').val(amount);
                $('#code').val("INV/" + purchaseOrder.code + Date.now());

                initPriceFormat();
            });
        });

        function getUnpaid(code) {
            return new Promise((resolve, reject) => {
                // $.get('{{ url('api/purchase-orders/get-unpaid') }}/?code=' + encodeURIComponent(id),
                $.post('{{ url('api/purchase-orders/get-unpaid') }}', {code},
                    function(res) {
                        if (res) {
                            resolve(res);
                        } else {
                            reject(new Error('Purchase Order not found'))
                        }
                    });
            });
        }
    </script>
@endpush
