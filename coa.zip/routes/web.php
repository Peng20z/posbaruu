<?php

use App\Http\Controllers\CoaController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CustomerGroupController;
use App\Http\Controllers\CustomerGroupProductController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\JournalController;
use App\Http\Controllers\JournalDetailController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\PaymentTypeController;
use App\Http\Controllers\ProductBrandController;
use App\Http\Controllers\ProductCategoryController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductUomController;
use App\Http\Controllers\PurchaseInvoiceController;
use App\Http\Controllers\PurchaseOrderController;
use App\Http\Controllers\ReceiveOrderController;
use App\Http\Controllers\SalesOrderController;
use App\Http\Controllers\SalesReturnController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\UomController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Auth::routes();

Route::get('clear-config', function () {
    \Illuminate\Support\Facades\Artisan::call('clear-compiled');
    echo "clear-compiled: complete<br>";
    \Illuminate\Support\Facades\Artisan::call('cache:clear');
    echo "cache:clear: complete<br>";
    \Illuminate\Support\Facades\Artisan::call('config:clear');
    echo "config:clear: complete<br>";
    \Illuminate\Support\Facades\Artisan::call('view:clear');
    echo "view:clear: complete<br>";
    \Illuminate\Support\Facades\Artisan::call('event:clear');
    echo "event:clear: complete<br>";
    \Illuminate\Support\Facades\Artisan::call('optimize:clear');
    echo "optimize:clear: complete<br>";

    \Illuminate\Support\Facades\Artisan::call('config:cache');
    echo "config:cache: complete<br>";
    \Illuminate\Support\Facades\Artisan::call('view:cache');
    echo "view:cache: complete<br>";
    \Illuminate\Support\Facades\Artisan::call('event:cache');
    echo "event:cache: complete<br>";
});

Route::get('migrate', function () {
    \Illuminate\Support\Facades\Artisan::call('custom-migration:fresh --seed');
    echo "migrate:fresh --seed - complete<br>";
});

// Route::group([], function ($route) {
Route::group(['middleware' => 'auth'], function ($route) {
    Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

    $route->resource('users', UserController::class);
    $route->resource('roles', RoleController::class);

    $route->post('customers/import-excel', [CustomerController::class, 'importExcel'])->name('customers.import-excel');
    $route->resource('customers', CustomerController::class);

    $route->group(['prefix' => 'customer-groups/{customer_group}/products', 'as' => 'customer-groups.products.'], function ($route) {
        $route->get('/', [CustomerGroupProductController::class, 'index'])->name('index');
        $route->get('create', [CustomerGroupProductController::class, 'create'])->name('create');
        $route->post('store', [CustomerGroupProductController::class, 'store'])->name('store');
        $route->get('{customer_group_product}/edit', [CustomerGroupProductController::class, 'edit'])->name('edit');
        $route->put('{customer_group_product}/update', [CustomerGroupProductController::class, 'update'])->name('update');
        $route->delete('{customer_group_product}/delete', [CustomerGroupProductController::class, 'destroy'])->name('delete');
    });
    $route->resource('customer-groups', CustomerGroupController::class);

    $route->resource('product-categories', ProductCategoryController::class)->except('show');
    $route->resource('product-brands', ProductBrandController::class)->except('show');
    $route->resource('uoms', UomController::class)->except('show');
    $route->post('products/import-excel', [ProductController::class, 'importExcel'])->name('products.import-excel');
    $route->get('products/price-list', [ProductController::class, 'productPriceList'])->name('product-price-list');
    $route->get('products/{product}/recalculate-capital', [ProductController::class, 'recalculateCapital'])->name('products.recalculate-capital');
    $route->resource('products', ProductController::class);
    $route->group(['prefix' => 'products/{product}/uoms', 'as' => 'products.uoms.'], function ($route) {
        $route->get('/', [ProductUomController::class, 'index'])->name('index');
        $route->get('create', [ProductUomController::class, 'create'])->name('create');
        $route->post('store', [ProductUomController::class, 'store'])->name('store');
        $route->get('{productUom}/edit', [ProductUomController::class, 'edit'])->name('edit');
        $route->put('{productUom}/update', [ProductUomController::class, 'update'])->name('update');
    });

    $route->post('suppliers/import-excel', [SupplierController::class, 'importExcel'])->name('suppliers.import-excel');
    $route->resource('suppliers', SupplierController::class);

    $route->post('purchase-orders/{purchase_order}/store-to-stock', [PurchaseOrderController::class, 'storeToStock'])->name('purchase-orders.store-to-stock');
    $route->post('purchase-orders/{purchase_order}/retrieve-stock', [PurchaseOrderController::class, 'retrieveStock'])->name('purchase-orders.retrieve-stock');
    $route->resource('purchase-orders', PurchaseOrderController::class);

    $route->get('/sales-orders/{sales_order}/generatePDF', [SalesOrderController::class, 'generatePDF'])->name('sales-orders.generate-pdf');
    $route->get('sales-orders/create-admin', [SalesOrderController::class, 'createAdmin'])->name('sales-orders.create-admin');
    $route->post('sales-orders/store-admin', [SalesOrderController::class, 'storeAdmin'])->name('sales-order.store-admin');
    $route->resource('sales-orders', SalesOrderController::class);

    $route->get('sales-returns/{sales_return}/add-to-stock', [SalesReturnController::class, 'addToStock'])->name('sales-returns.add-to-stock');
    $route->post('sales-returns/{sales_return}/store-to-stock', [SalesReturnController::class, 'storeToStock'])->name('sales-returns.store-to-stock');
    $route->resource('sales-returns', SalesReturnController::class);

    $route->get('receive-orders/{receive_order}/add-to-stock', [ReceiveOrderController::class, 'addToStock'])->name('receive-orders.add-to-stock');
    $route->post('receive-orders/{receive_order}/store-to-stock', [ReceiveOrderController::class, 'storeToStock'])->name('receive-orders.store-to-stock');
    $route->resource('receive-orders', ReceiveOrderController::class);

    $route->get('stocks/{stock}/histories', [StockController::class, 'histories'])->name('stocks.histories');
    $route->get('stocks/{stock}/move', [StockController::class, 'move'])->name('stocks.move');
    $route->put('stocks/{stock}/update-move', [StockController::class, 'updateMove'])->name('stocks.update-move');
    $route->resource('stocks', StockController::class)->except('create, delete');

    $route->resource('payments', PaymentController::class);
    $route->resource('payment-types', PaymentTypeController::class);
    $route->resource('purchase-invoices', PurchaseInvoiceController::class);

    $route->resource('settings', SettingController::class);

    $route->post('change-database-connection', [HomeController::class, 'changeDatabaseConnection'])->name('change_database_connection');

    $route->group(['prefix' => 'reports', 'as' => 'reports.'], function ($route) {
        $route->get('/', fn () => to_route('reports.sales-orders.salesOrders'));
        $route->group(['prefix' => 'sales-orders', 'as' => 'sales-orders.'], function ($route) {
            $route->get('/', [ReportController::class, 'salesOrders'])->name('salesOrders');
            $route->get('penjualan-per-barang', [ReportController::class, 'penjualanPerBarang'])->name('penjualanPerBarang');
        });

        $route->group(['prefix' => 'purchase-orders', 'as' => 'purchase-orders.'], function ($route) {
            $route->get('/', [ReportController::class, 'purchaseOrders'])->name('purchaseOrders');
            $route->get('pembelian-per-barang', [ReportController::class, 'pembelianPerBarang'])->name('pembelianPerBarang');
        });
    });

    $route->resource('coa', CoaController::class);

    $route->group(['prefix' => 'journals/{journal}', 'as' => 'journals.'], function ($route) {
        $route->resource('details', JournalDetailController::class);
    });
    $route->resource('journals', JournalController::class);
    $route->get('list-journals', [JournalController::class, 'listJournals'])->name('list-journals');
});
