<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class CustomMigration extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'custom-migration {--seed : Indicates if the seed task should be re-run}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = ' Run the database custom migrations';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $seed = $this->option('seed') ? '--seed' : '';
        $command = sprintf('migrate %s', $seed);

        try {
            Artisan::call($command);
            Artisan::call($command . ' --database=mysql_secondary');

            $this->info('The migration was successful!');
        } catch (\Throwable $th) {
            $this->error('error migration: ' . $th->getMessage());
        }
    }
}
