<?php

namespace App\Imports;

use App\Enums\DatabaseConnection;
use App\Models\CustomerGroup;
use App\Models\User;
use Maatwebsite\Excel\Concerns\ToModel;

class CustomersImport implements ToModel
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        foreach (DatabaseConnection::getInstances() as $db) {
            $custGroup1 = CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 1'
            ]);
            $custGroup2 = CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 2'
            ]);
            $custGroup3 = CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 3'
            ]);
            $custGroup4 = CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 4'
            ]);

            // $code = strval(trim($row[0]));
            // if (!empty($code) && !is_null($code) && $code != '') {
            $duplicate = User::on($db->value)->firstWhere('code', $row[0]);
            if (!$duplicate) {
                User::on($db->value)->create([
                    'code' => $row[0],
                    'name' => $row[1],
                    'type' => 'customer',
                    'customer_group_id' => is_int($row[2]) ? $row[2] : null,
                ]);
            }
        }
    }

    public function startRow(): int
    {
        return 2;
    }
}
