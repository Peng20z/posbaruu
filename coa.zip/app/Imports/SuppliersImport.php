<?php

namespace App\Imports;

use App\Enums\DatabaseConnection;
use App\Models\Supplier;
use App\Services\CoreService;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToModel;

class SuppliersImport implements ToModel
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        if (str_ends_with($row[0], 'Tax')) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $code = str_replace('Tax', '', $row[0]);
                $duplicate = Supplier::on($db->value)->firstWhere('id', $code);

                if (!$duplicate) {
                    Supplier::on($db->value)->create([
                        'id' => str_replace('Tax', '', $row[0]),
                        'name' => $row[1]
                    ]);
                }
            }
        } elseif (CoreService::getCookieDbConnection() === DatabaseConnection::MYSQL) {
            $duplicate = Supplier::on(DatabaseConnection::MYSQL_SECONDARY)->firstWhere('id', $row[0]);
            if (!$duplicate) {
                Supplier::on(DatabaseConnection::MYSQL_SECONDARY)->create([
                    'id' => str_replace('Tax', '', $row[0]),
                    'name' => $row[1]
                ]);
            }
        } else {
            $duplicate = Supplier::firstWhere('id', $row[0]);
            if (!$duplicate) {
                Supplier::create([
                    'id' => str_replace('Tax', '', $row[0]),
                    'name' => $row[1]
                ]);
            }
        }
    }
}
