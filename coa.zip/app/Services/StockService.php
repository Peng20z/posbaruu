<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Models\ReceiveOrderDetail;
use App\Models\Stock;
use App\Models\StockHistory;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StockService
{
    public static function insertStockHistoryFromRO(array $datas): void
    {
        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL();
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY();

        dump($datas);
        dump($dbConnection);
        dump($mysql);
        dd($mysqlSecondary);

        DB::transaction(function () use ($datas, $dbConnection, $mysql, $mysqlSecondary) {

            if ($dbConnection == DatabaseConnection::MYSQL) {
                $totalQty = collect($data)->sum();
                $roDetail = ReceiveOrderDetail::findOrFail($roDetailId);
                $stock = Stock::firstWhere('product_id', $roDetail->product_id);

                $stockHistory = self::createStockHistory($mysql->value, $stock, $roDetail, (int) $data[$mysql->value]);
                self::updateStockFromHistory($stockHistory);




                foreach ($datas as $roDetailId => $data) {
                    $totalQty = collect($data)->sum();
                    $roDetail = ReceiveOrderDetail::findOrFail($roDetailId);
                    $stock = Stock::firstWhere('product_id', $roDetail->product_id);

                    $stockHistory = self::createStockHistory($mysql->value, $stock, $roDetail, (int) $data[$mysql->value]);
                    self::updateStockFromHistory($stockHistory);

                    // insert to db_secondary
                    $stockDb2 = Stock::on($mysqlSecondary->value)->firstWhere('product_id', $roDetail->product_id); // make sure we get stock of product from db_secondary
                    $stockHistoryDb2 = self::createStockHistory($mysqlSecondary->value, $stockDb2, $roDetail->code, $totalQty);

                    self::updateStockFromHistory($mysqlSecondary->value, $stockHistoryDb2);
                    // insert to db_secondary
                }
            } else {
                foreach ($datas as $roDetailId => $data) {
                    $totalQty = collect($data)->sum();
                    $roDetail = ReceiveOrderDetail::findOrFail($roDetailId);
                    $stock = Stock::firstWhere('product_id', $roDetail->product_id);

                    $stockHistory = self::createStockHistory($mysql->value, $stock, $roDetail, (int) $data[$mysql->value]);
                    self::updateStockFromHistory($stockHistory);

                    // insert to db_secondary
                    $stockDb2 = Stock::on($mysqlSecondary->value)->firstWhere('product_id', $roDetail->product_id); // make sure we get stock of product from db_secondary
                    $stockHistoryDb2 = self::createStockHistory($mysqlSecondary->value, $stockDb2, $roDetail->code, $totalQty);

                    self::updateStockFromHistory($mysqlSecondary->value, $stockHistoryDb2);
                    // insert to db_secondary
                }
            }
        });
    }

    public static function createStockHistory(string $dbConnection, Stock $stock, ReceiveOrderDetail|string $roDetail, int $qty)
    {
        // $stockHistoryId = DB::connection($dbConnection)->table('stock_histories')->insertGetId([
        //     'stock_id' => $stock->id,
        //     'model_id' => $roDetail->id,
        //     'model_type' => get_class($roDetail),
        //     'is_increment' => 1,
        //     'qty' => (int) $data[$dbConnection],
        //     'created_at' => now(),
        //     'updated_at' => now(),
        // ]);

        // return $stockHistoryId;

        if (gettype($roDetail) === 'string') {
            $roDetail = ReceiveOrderDetail::on($dbConnection)->firstWhere('code', $roDetail);
            if (!$roDetail)
                return new ModelNotFoundException('Receive Order not found');
        } elseif (!($roDetail instanceof ReceiveOrderDetail)) {
            return new ModelNotFoundException('Receive Order not found');
        }

        return $roDetail->stockHistory()->create([
            'user_id' => Auth::user()->id,
            'stock_id' => $stock->id,
            'is_increment' => 1,
            'qty' => $qty,
        ]);
    }

    public static function updateStockFromHistory(StockHistory $stockHistory): void
    {
        if ($stock = $stockHistory->stock) {
            if ($stockHistory->is_increment) {
                $stock->increment('qty', $stockHistory->qty);
            } else {
                $stock->decrement('qty', $stockHistory->qty);
            }
        }
    }
}
