<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Http\Requests\SalesReturnStoreRequest;
use App\Models\SalesReturn;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SalesReturnService
{
    public static function store(Request $request)
    {
        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL;
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY;

        DB::transaction(function () use ($request, $dbConnection, $mysql, $mysqlSecondary) {

            if ($dbConnection === $mysql) {
                self::storeSr($mysql, $request);
                self::storeSr($mysqlSecondary, $request);
            } else {
                self::storeSr($mysql, $request);
            }
        });
    }

    public static function storeSr(string $dbConnection, SalesReturnStoreRequest $request, string $code = null, $salesOrderId = null): SalesReturn
    {
        $data = $request->validated();

        $salesReturn = SalesReturn::on($dbConnection)->create($data);

        self::createSalesReturnDetails($salesReturn, $data['items']);
        return $salesReturn;
    }

    public static function createSalesReturnDetails(SalesReturn $salesReturn, $data): void
    {
        $salesOrderDetails = $salesReturn->salesOrder?->details ?? collect([]);

        foreach ($salesOrderDetails as $key => $detail) {
            $salesReturn->details()->create([
                'product_id' => $detail->product_id,
                'qty' => $data[$key]['qty'],
                'unit_price' => $detail->unit_price,
                'total_price' => $data[$key]['qty'] * $detail->unit_price,
            ]);
        }

        $salesReturn->update([
            'total_price' => $salesReturn->details->sum('total_price')
        ]);
    }
}
