<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Http\Requests\Coa\StoreRequest;
use App\Models\Coa;
use Illuminate\Support\Facades\DB;

class CoaService
{
    public static function store(StoreRequest $request): void
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                Coa::on($db->value)->create($request->validated());
            }
        });
    }

    public static function update(StoreRequest $request, int $id): void
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $coa = Coa::on($db->value)->findOrFail($id);
                $coa->update($request->validated());
            }
        });
    }

    public static function destroy(int $id): void
    {
        DB::transaction(function () use ($id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $coa = Coa::on($db->value)->find($id);
                $coa->delete();
            }
        });
    }
}
