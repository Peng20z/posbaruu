<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Http\Requests\UomStoreRequest;
use App\Models\Uom;
use Illuminate\Support\Facades\DB;

class UomService
{
    public static function store(UomStoreRequest $request): void
    {
        DB::transaction(function () use ($request) {

            foreach (DatabaseConnection::getInstances() as $db) {
                Uom::on($db->value)->create($request->validated());
            }
        });
    }
}
