<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Http\Requests\ProductStoreRequest;
use App\Models\CustomerGroup;
use App\Models\CustomerGroupProduct;
use App\Models\Product;
use App\Models\ProductUom;
use Illuminate\Support\Facades\DB;

class ProductService
{
    public static function store(ProductStoreRequest $request): void
    {
        DB::transaction(function () use ($request) {
            // $uoms = Uom::all();
            foreach (DatabaseConnection::getInstances() as $db) {
                $product = Product::on($db->value)->create($request->validated());

                if ($request->base_uom_id != $request->default_uom_id) {
                    ProductUom::on($db->value)->create([
                        ...$request->validated(),
                        'product_id' => $product->id,
                        'uom_id' => $request->base_uom_id,
                        'is_default' => false,
                        'is_base' => true,
                    ]);

                    foreach (CustomerGroup::get() as $customerGroup) {
                        CustomerGroupProduct::on($db->value)->create([
                            ...$request->validated(),
                            'customer_group_id' => $customerGroup->id,
                            'product_id' => $product->id,
                            'uom_id' => $request->base_uom_id,

                        ]);
                    }
                }

                ProductUom::on($db->value)->create([
                    ...$request->validated(),
                    'uom_id' => $request->default_uom_id,
                    'product_id' => $product->id,
                    'is_default' => true,
                    'is_base' => $request->base_uom_id == $request->default_uom_id,
                ]);

                foreach (CustomerGroup::get() as $customerGroup) {
                    CustomerGroupProduct::on($db->value)->create([
                        ...$request->validated(),
                        'customer_group_id' => $customerGroup->id,
                        'product_id' => $product->id,
                        'uom_id' => $request->default_uom_id,
                    ]);
                }

                // $product->uoms()->create($request->validated());
                // foreach ($uoms as $uom) {
                //     ProductUom::on($db->value)->create([
                //         'product_id' => $product->id,
                //         'uom_id' => $uom->id,
                //         'is_default' => ($product->uom_id == $uom->id) ? true : false,
                //     ]);
                // }
            }
        });
    }

    public static function getSelectBooks(Product | int $product): array
    {
        if ($product instanceof Product) {
            $productId = $product->id;
        } else {
            $productId = $product;
        }

        $currentConnection = CoreService::getCookieDbConnection();
        if ($currentConnection == DatabaseConnection::MYSQL_SECONDARY) {
            $productDb1 = Product::on(DatabaseConnection::MYSQL_SECONDARY)->find($productId);
            if ($productDb1) {
                $selectBooks = DatabaseConnection::getInstances();
            } else {
                $selectBooks = [
                    DatabaseConnection::MYSQL()->key => DatabaseConnection::MYSQL
                ];
            }
        } else {
            $selectBooks = DatabaseConnection::getInstances();
            unset($selectBooks['MYSQL_SECONDARY']);
        }

        return $selectBooks;
    }
}
