<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Enums\NormalBalance;
use App\Enums\PaymentStatus;
use App\Http\Requests\PurchaseInvoiceStoreRequest;
use App\Models\Coa;
use App\Models\Journal;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrder;
use Illuminate\Support\Facades\DB;

class PurchaseInvoiceService
{
    public static function store(PurchaseInvoiceStoreRequest $request): void
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $po = PurchaseOrder::on($db->value)->where('code', $request->purchase_order_id)->first();
                if ($po->total_paid < $po->total_price) {
                    $purchaseInvoice = PurchaseInvoice::on($db->value)->create($request->validated());

                    $journal = Journal::on($db->value)->create($request->validated());

                    $sourceCoa = Coa::on($db->value)->where('id', $request->source_coa_id)->firstOrFail(['id', 'normal_balance']);
                    $journal->details()->create([
                        'coa_id' => $sourceCoa->id,
                        // 'debit' => $sourceCoa->normal_balance->is(NormalBalance::DEBIT) ? $purchaseInvoice->amount : 0,
                        // 'credit' => $sourceCoa->normal_balance->is(NormalBalance::CREDIT) ? $purchaseInvoice->amount : 0,
                        'debit' => $purchaseInvoice->amount,
                        'credit' => 0,
                        'memo' => sprintf('Sales Invoice %s', $purchaseInvoice->code),
                    ]);

                    $destinationCoa = Coa::on($db->value)->where('id', $request->destination_coa_id)->firstOrFail(['id', 'normal_balance']);
                    $journal->details()->create([
                        'coa_id' => $destinationCoa->id,
                        // 'debit' => $destinationCoa->normal_balance->is(NormalBalance::DEBIT) ? $purchaseInvoice->amount : 0,
                        // 'credit' => $destinationCoa->normal_balance->is(NormalBalance::CREDIT) ? $purchaseInvoice->amount : 0,
                        'debit' => 0,
                        'credit' => $purchaseInvoice->amount,
                        'memo' => sprintf('Sales Invoice %s', $purchaseInvoice->code),
                    ]);
                }
            }
        });
    }

    public static function refreshPayment(PurchaseInvoice $purchaseInvoice): void
    {
        $purchaseOrder = $purchaseInvoice->purchaseOrder;
        if ($purchaseOrder) {
            if ($purchaseInvoice->wasChanged('status')) {
                if ($purchaseInvoice->getOriginal('status')->in([PaymentStatus::PENDING(), PaymentStatus::REJECTED()]) && $purchaseInvoice->status->is(PaymentStatus::APPROVED())) {
                    $purchaseInvoice->purchaseOrder->increment('total_paid', $purchaseInvoice->amount);
                } elseif ($purchaseInvoice->getOriginal('status')->is(PaymentStatus::APPROVED())) {
                    // $purchaseOrder->update(['total_paid' => $purchaseOrder->payments()->whereAproved()->sum('amount') ?? 0]);
                    $purchaseOrder->total_paid = $purchaseOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    $purchaseOrder->save();
                }

                return;
            } elseif ($purchaseInvoice->wasChanged('amount')) {
                if ($purchaseInvoice->status->is(PaymentStatus::APPROVED())) {

                    // if ($purchaseOrder->total_paid == $purchaseOrder->total_price) {
                    //     return;
                    // }

                    $totalPayment = $purchaseOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    if ($purchaseOrder->total_paid == $purchaseOrder->total_price && $totalPayment >= $purchaseOrder->total_price) {
                        $purchaseInvoice->amount = $purchaseInvoice->getOriginal('amount') - ($totalPayment - $purchaseOrder->total_paid);
                        // $payment->amount = 6000;
                        $purchaseInvoice->saveQuietly();
                        // $payment->update(['amount' =>  $payment->amount]);
                        return;
                    }
                    elseif ($totalPayment > $purchaseOrder->total_price) {
                        $purchaseInvoice->amount = $purchaseInvoice->amount - ($totalPayment - $purchaseOrder->total_price);
                        $purchaseInvoice->saveQuietly();

                        $purchaseOrder->total_paid = $purchaseOrder->total_price;
                        $purchaseOrder->saveQuietly();
                    } else {
                        $purchaseOrder->total_paid = $totalPayment;
                        $purchaseOrder->save();
                    }
                }
            } else {
                if ($purchaseInvoice->status->is(PaymentStatus::APPROVED()) && $purchaseOrder->total_paid <= $purchaseOrder->total_price) {
                    if ($purchaseInvoice->amount + $purchaseOrder->total_paid > $purchaseOrder->total_price) {
                        $purchaseInvoice->amount = $purchaseOrder->total_price - $purchaseOrder->total_paid;
                        $purchaseInvoice->saveQuietly();

                        $purchaseInvoice->purchaseOrder->increment('total_paid', $purchaseOrder->total_price - $purchaseOrder->total_paid);
                    } else {
                        $purchaseInvoice->purchaseOrder->increment('total_paid', $purchaseInvoice->amount);
                    }
                } else {
                    // $payment->delete();
                }

                return;
            }
        }
    }
}
