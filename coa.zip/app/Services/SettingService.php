<?php

namespace App\Services;

use App\Enums\SettingKey;
use App\Models\Setting;

class SettingService
{
    /**
     * @param SettingKey|string $key
     * @return mixed
     */
    public static function getCurrentValue(SettingKey|string $key) : mixed
    {
        if ($key instanceof SettingKey) {
            $key = $key->value;
        }

        return Setting::firstWhere('key', $key)?->value ?? "";
    }
}
