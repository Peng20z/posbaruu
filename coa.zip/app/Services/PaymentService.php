<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Enums\NormalBalance;
use App\Enums\PaymentStatus;
use App\Http\Requests\PaymentStoreRequest;
use App\Models\Coa;
use App\Models\Journal;
use App\Models\Payment;
use App\Models\SalesOrder;
use Illuminate\Support\Facades\DB;

class PaymentService
{
    public static function store(PaymentStoreRequest $request): void
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $so = SalesOrder::on($db->value)->where('code', $request->sales_order_id)->first();
                if ($so->total_paid < $so->total_price) {
                    $payment = Payment::on($db->value)->create($request->validated());

                    $journal = Journal::on($db->value)->create($request->validated());

                    $sourceCoa = Coa::on($db->value)->where('id', $request->source_coa_id)->firstOrFail(['id', 'normal_balance']);
                    $journal->details()->create([
                        'coa_id' => $sourceCoa->id,
                        // 'debit' => $sourceCoa->normal_balance->is(NormalBalance::DEBIT) ? $payment->amount : 0,
                        // 'credit' => $sourceCoa->normal_balance->is(NormalBalance::CREDIT) ? $payment->amount : 0,
                        'debit' => 0,
                        'credit' => $payment->amount,
                        'memo' => sprintf('Sales Invoice %s', $payment->code),
                    ]);

                    $destinationCoa = Coa::on($db->value)->where('id', $request->destination_coa_id)->firstOrFail(['id', 'normal_balance']);
                    $journal->details()->create([
                        'coa_id' => $destinationCoa->id,
                        // 'debit' => $destinationCoa->normal_balance->is(NormalBalance::DEBIT) ? $payment->amount : 0,
                        // 'credit' => $destinationCoa->normal_balance->is(NormalBalance::CREDIT) ? $payment->amount : 0,
                        'debit' => $payment->amount,
                        'credit' => 0,
                        'memo' => sprintf('Sales Invoice %s', $payment->code),
                    ]);
                }
            }
        });
    }

    public static function update(PaymentStoreRequest $request, int $id): void
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $coa = Payment::on($db->value)->findOrFail($id);
                $coa->update($request->validated());
            }
        });
    }

    public static function destroy(int $id): void
    {
        DB::transaction(function () use ($id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $coa = Payment::on($db->value)->find($id);
                $coa->delete();
            }
        });
    }

    public static function refreshPayment(Payment $payment): void
    {
        $salesOrder = $payment->salesOrder;
        if ($salesOrder) {
            if ($payment->wasChanged('status')) {
                if ($payment->getOriginal('status')->in([PaymentStatus::PENDING(), PaymentStatus::REJECTED()]) && $payment->status->is(PaymentStatus::APPROVED())) {
                    $payment->salesOrder->increment('total_paid', $payment->amount);
                } elseif ($payment->getOriginal('status')->is(PaymentStatus::APPROVED())) {
                    // $salesOrder->update(['total_paid' => $salesOrder->payments()->whereAproved()->sum('amount') ?? 0]);
                    $salesOrder->total_paid = $salesOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    $salesOrder->save();
                }

                return;
            } elseif ($payment->wasChanged('amount')) {
                if ($payment->status->is(PaymentStatus::APPROVED())) {

                    // if ($salesOrder->total_paid == $salesOrder->total_price) {
                    //     return;
                    // }

                    $totalPayment = $salesOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    if ($salesOrder->total_paid == $salesOrder->total_price && $totalPayment >= $salesOrder->total_price) {
                        $payment->amount = $payment->getOriginal('amount') - ($totalPayment - $salesOrder->total_paid);
                        // $payment->amount = 6000;
                        $payment->saveQuietly();
                        // $payment->update(['amount' =>  $payment->amount]);
                        return;
                    } elseif ($totalPayment > $salesOrder->total_price) {
                        $payment->amount = $payment->amount - ($totalPayment - $salesOrder->total_price);
                        $payment->saveQuietly();

                        $salesOrder->total_paid = $salesOrder->total_price;
                        $salesOrder->saveQuietly();
                    } else {
                        $salesOrder->total_paid = $totalPayment;
                        $salesOrder->save();
                    }
                }
            } else {
                if ($payment->status->is(PaymentStatus::APPROVED()) && $salesOrder->total_paid <= $salesOrder->total_price) {
                    if ($payment->amount + $salesOrder->total_paid > $salesOrder->total_price) {
                        $payment->amount = $salesOrder->total_price - $salesOrder->total_paid;
                        $payment->saveQuietly();

                        $payment->salesOrder->increment('total_paid', $salesOrder->total_price - $salesOrder->total_paid);
                    } else {
                        $payment->salesOrder->increment('total_paid', $payment->amount);
                    }
                } else {
                    // $payment->delete();
                }

                return;
            }
        }
    }
}
