<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static PO_NUMBER()
 * @method static static RO_NUMBER()
 * @method static static SO_NUMBER()
 * @method static static TAX_VALUE()
 * @method static static IS_SKIP_RO()
 * @method static static STOCK_LESS_THAN_0()
 * @method static static AKUN_PENJUALAN()
 * @method static static AKUN_PENJUALAN_REVERSE()
 * @method static static AKUN_PEMBELIAN()
 * @method static static AKUN_PEMBELIAN_REVERSE()
 */
final class SettingKey extends Enum
{
    const PO_NUMBER = 'po_number';
    const RO_NUMBER = 'ro_number';
    const SO_NUMBER = 'so_number';
    const TAX_VALUE = 'tax_value';
    const IS_SKIP_RO = 'is_skip_ro';
    const STOCK_LESS_THAN_0 = 'stock_less_than_0';
    const AKUN_PERSEDIAAN = 'akun_persediaan';
    const AKUN_PERSEDIAAN_REVERSE = 'akun_persediaan_reverse';
    const AKUN_PENJUALAN = 'akun_penjualan';
    const AKUN_PENJUALAN_REVERSE = 'akun_penjualan_reverse';
    const AKUN_RETUR_PENJUALAN = 'akun_retur_penjualan';
    const AKUN_RETUR_PENJUALAN_REVERSE = 'akun_retur_penjualan_reverse';
    const AKUN_DISKON_BARANG = 'akun_diskon_barang';
    const AKUN_DISKON_BARANG_REVERSE = 'akun_diskon_barang_reverse';
    const AKUN_BARANG_TERKIRIM = 'akun_barang_terkirim';
    const AKUN_BARANG_TERKIRIM_REVERSE = 'akun_barang_terkirim_reverse';
    const AKUN_HPP = 'akun_hpp';
    const AKUN_HPP_REVERSE = 'akun_hpp_reverse';
    const AKUN_RETUR_PEMBELIAN = 'akun_retur_pembelian';
    const AKUN_RETUR_PEMBELIAN_REVERSE = 'akun_retur_pembelian_reverse';
    const AKUN_BEBAN = 'akun_beban';
    const AKUN_BEBAN_REVERSE = 'akun_beban_reverse';
    const AKUN_BELUM_TERTAGIH = 'akun_beLUM_tertagih';
    const AKUN_BELUM_TERTAGIH_REVERSE = 'akun_beLUM_tertagih_reverse';
    const AKUN_PEMBELIAN = 'akun_pembelian';
    const AKUN_PEMBELIAN_REVERSE = 'akun_pembelian_reverse';

    public function getSourceData()
    {
        return match ($this->value) {
            self::PO_NUMBER,
            self::RO_NUMBER,
            self::SO_NUMBER,
            self::TAX_VALUE,
            self::IS_SKIP_RO,
            self::STOCK_LESS_THAN_0 => 'string',
            self::AKUN_PERSEDIAAN,
            self::AKUN_PERSEDIAAN_REVERSE,
            self::AKUN_PENJUALAN,
            self::AKUN_PENJUALAN_REVERSE,
            self::AKUN_RETUR_PENJUALAN,
            self::AKUN_RETUR_PENJUALAN_REVERSE,
            self::AKUN_DISKON_BARANG,
            self::AKUN_DISKON_BARANG_REVERSE,
            self::AKUN_BARANG_TERKIRIM,
            self::AKUN_BARANG_TERKIRIM_REVERSE,
            self::AKUN_HPP,
            self::AKUN_HPP_REVERSE,
            self::AKUN_RETUR_PEMBELIAN,
            self::AKUN_RETUR_PEMBELIAN_REVERSE,
            self::AKUN_BEBAN,
            self::AKUN_BEBAN_REVERSE,
            self::AKUN_BELUM_TERTAGIH,
            self::AKUN_BELUM_TERTAGIH_REVERSE,
            self::AKUN_PEMBELIAN,
            self::AKUN_PEMBELIAN_REVERSE => \App\Models\Coa::class,
        };
    }

    public static function getValueType(string $key, string|int $value)
    {
        return match ($key) {
            self::PO_NUMBER,
            self::RO_NUMBER,
            self::SO_NUMBER,
            self::AKUN_PENJUALAN,
            self::AKUN_PENJUALAN_REVERSE,
            self::AKUN_PEMBELIAN,
            self::AKUN_PEMBELIAN_REVERSE => (string) $value,
            self::TAX_VALUE,
            self::IS_SKIP_RO,
            self::STOCK_LESS_THAN_0 => (int) $value,
            default => $value
        };
    }
}
