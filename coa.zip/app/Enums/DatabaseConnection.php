<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static MYSQL()
 * @method static static MYSQL_SECONDARY()
 */
final class DatabaseConnection extends Enum
{
    const MYSQL = 'mysql';
    const MYSQL_SECONDARY = 'mysql_secondary';

    public static function getDescription(mixed $value): string
    {
        return match ($value) {
            self::MYSQL => 'Book 1',
            self::MYSQL_SECONDARY => 'Book 2',
            default => 'Book 1',
        };
    }
    public static function getConnection(string|self $connection)
    {
        if (gettype($connection) === 'string') {
            $config = config('database.connections.' . $connection);
        } elseif ($connection instanceof self) {
            $config = config('database.connections.' . $connection->value);
        } else {
            $config = config('database.connections.mysql');
        }

        return $config;
    }

    public function getPoCodeFormat(): string
    {
        if ($this->value === self::MYSQL)
            return 'PO/%s/%s/%s/AA/';
        return 'PO/%s/%s/%s/BB/';
    }

    public function getRoCodeFormat(): string
    {
        if ($this->value === self::MYSQL)
            return 'RO/%s/%s/%s/AA/';
        return 'RO/%s/%s/%s/BB/';
    }

    public function getSoCodeFormat(): string
    {
        if ($this->value === self::MYSQL)
            return 'SO/%s/%s/%s/AA/';
        return 'SO/%s/%s/%s/BB/';
    }

    public static function getBook($cookieDbConnection, $dbBook)
    {
        if ($cookieDbConnection == self::MYSQL) {
            return $dbBook;
        }else{
            if ($dbBook == self::MYSQL) {
                return self::MYSQL_SECONDARY;
            }else{
                return self::MYSQL;
            }
        }
    }
}
