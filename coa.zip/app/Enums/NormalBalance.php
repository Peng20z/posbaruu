<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static DEBIT()
 * @method static static CREDIT()
 */
final class NormalBalance extends Enum
{
    const DEBIT = 'debit';
    const CREDIT = 'credit';
}
