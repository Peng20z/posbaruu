<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static USER()
 * @method static static CUSTOMER()
 */
final class UserType extends Enum
{
    const USER = 'user';
    const CUSTOMER = 'customer';

}
