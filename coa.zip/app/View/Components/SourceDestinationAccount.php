<?php

namespace App\View\Components;

use App\Models\Coa;
use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Collection;
use Illuminate\View\Component;

class SourceDestinationAccount extends Component
{
    public Collection|array $coas;
    /**
     * Create a new component instance.
     */
    public function __construct(
        public string|int $sourceCoaId,
        public string|int $destinationCoaId,
        Collection|array $coas = null
    ) {
        if ($coas) {
            $this->coas = $coas;
        } else {
            $this->coas = Coa::getChildsSelections()->prepend('- Select -', null);
        }
    }

    /**
     * Get the view / contents that represent the component.
     */
    public function render(): View|Closure|string
    {
        return view('components.source-destination-account');
    }
}
