<?php

namespace App\Helpers;

use App\Models\Permission;

class PermissionsHelper
{
    public static function getAllPermissions()
    {
        return collect(static::permissions());
    }

    public static function getPermissionsData(): array
    {
        $persmissions = self::permissions();

        $data = [];
        foreach ($persmissions as $key => $persmission) {
            if (is_array($persmission)) {
                $data[] = $key;
                foreach ($persmission as $key => $persmission) {
                    if (is_array($persmission)) {
                        $data[] = $key;

                        foreach ($persmission as $p) {
                            $data[] = $p;
                        }
                    } else {
                        $data[] = $persmission;
                    }
                }
            } else {
                $data[] = $persmission;
            }
        }
        return $data;
    }

    public static function permissions(): array
    {
        return [
            'dashboard_access',

            'user_management_access' => [
                'roles_access' => [
                    'roles_create',
                    'roles_edit',
                    'roles_delete',
                ],

                'users_access' => [
                    'users_create',
                    'users_edit',
                    'users_delete',
                ],
            ],

            'customer_management_access' => [
                'customer_access' => [
                    'customer_create',
                    'customer_edit',
                    'customer_delete',
                ],

                'customer_groups_access' => [
                    'customer_groups_create',
                    'customer_groups_edit',
                    'customer_groups_delete',
                ],
            ],

            'suppliers_access' => [
                'suppliers_view',
                'suppliers_create',
                'suppliers_edit',
                'suppliers_delete',
            ],

            'product_management_access' => [
                'products_access' => [
                    'products_create',
                    'products_edit',
                    'products_delete',
                ],

                'product_brands_access' => [
                    'product_brands_create',
                    'product_brands_edit',
                    'product_brands_delete',
                ],

                'product_categories_access' => [
                    'product_categories_create',
                    'product_categories_edit',
                    'product_categories_delete',
                ],

                'uoms_access' => [
                    'uoms_create',
                    'uoms_edit',
                    'uoms_delete',
                ],

                'product_price_list_access',
            ],

            'purchase_orders_access' => [
                'purchase_orders_create',
                'purchase_orders_edit',
                'purchase_orders_delete',
            ],

            'receive_orders_access' => [
                'receive_orders_create',
                'receive_orders_edit',
                'receive_orders_delete',
            ],

            'sales_orders_access' => [
                'sales_orders_create',
                'sales_orders_edit',
                'sales_orders_delete',
            ],

            'sales_returns_access' => [
                'sales_returns_create',
                'sales_returns_edit',
                'sales_returns_delete',
            ],

            'stocks_access' => [
                'stocks_create',
                'stocks_edit',
                'stocks_delete',
            ],

            'reports_access',
            'payment_management_access' => [
                'purchase_invoices_access' => [
                    'purchase_invoices_create',
                    'purchase_invoices_edit',
                    'purchase_invoices_delete',
                ],

                'sales_invoices_access' => [
                    'sales_invoices_create',
                    'sales_invoices_edit',
                    'sales_invoices_delete',
                ],
            ],

            'coa_access' => [
                'coa_create',
                'coa_edit',
                'coa_delete',
            ],

            'journal_access' => [
                'journal_create',
                'journal_edit',
                'journal_delete',
            ],

            'settings_access',
        ];
    }

    public static function generateChilds(Permission $headSubPermissions, array $subPermissions)
    {
        collect($subPermissions)->each(function ($permission, $key) use ($headSubPermissions) {
            if (is_array($permission)) {
                $hsp = Permission::firstOrCreate([
                    'name' => $key,
                    // 'guard_name' => $guard,
                    'parent_id' => $headSubPermissions->id
                ]);

                self::generateChilds($hsp, $permission);
            } else {
                $hsp = Permission::firstOrCreate([
                    'name' => $permission,
                    // 'guard_name' => $guard,
                    'parent_id' => $headSubPermissions->id
                ]);
            }

            return;
        });
    }
}
