<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Enums\PaymentStatus;
use App\Enums\SettingKey;
use App\Http\Requests\PurchaseInvoiceStoreRequest;
use App\Http\Requests\PurchaseInvoiceUpdateRequest;
use App\Models\PaymentType;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrder;
use App\Models\Setting;
use App\Services\PurchaseInvoiceService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class PurchaseInvoiceController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:purchase_invoices_access', ['only' => 'index']);
        $this->middleware('permission:purchase_invoices_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:purchase_invoices_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:purchase_invoices_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = PurchaseInvoice::select(sprintf('%s.*', (new PurchaseInvoice)->table))->with(['purchaseOrder', 'user']);
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('purchase_order_code', function ($row) {
                return $row->purchaseOrder?->code ?? '';
            });
            $table->addColumn('user_name', function ($row) {
                return $row->user?->name ?? '';
            });
            $table->editColumn('status', function ($row) {
                return $row->status?->description ?? '';
            });
            $table->editColumn('amount', fn ($row) => rupiah($row->amount));
            $table->editColumn('actions', function ($row) {
                $viewGate = 'purchase_invoices_access';
                $editGate = 'purchase_invoices_edit';
                $deleteGate = 'purchase_invoices_delete';
                $crudRoutePart = 'purchase-invoices';

                return view(
                    'layouts.includes.datatablesActions',
                    compact(
                        'viewGate',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('purchaseInvoices.index');
    }

    public function show(PurchaseInvoice $purchaseInvoice)
    {
        return view('purchaseInvoices.show', ['purchaseInvoice' => $purchaseInvoice]);
    }

    public function create()
    {
        $purchaseOrders = PurchaseOrder::whereNotPaid()->get();
        $paymentStatuses = PaymentStatus::getInstances();
        $paymentTypes = PaymentType::get()->pluck('name', 'id')->prepend('- Select Payment Type -', null);
        $sourceCoaId = Setting::where('key', SettingKey::AKUN_BEBAN)->first(['value'])?->value ?? null;
        $destinationCoaId = Setting::where('key', SettingKey::AKUN_BEBAN_REVERSE)->first(['value'])?->value ?? null;

        return view('purchaseInvoices.create', [
            'purchaseOrders' => $purchaseOrders,
            'paymentStatuses' => $paymentStatuses,
            'paymentTypes' => $paymentTypes,
            'sourceCoaId' => $sourceCoaId,
            'destinationCoaId' => $destinationCoaId,
        ]);
    }

    public function store(PurchaseInvoiceStoreRequest $request)
    {
        try {
            PurchaseInvoiceService::store($request);
            alert()->success('Success', 'Data created successfully');
        } catch (Exception $e) {
            dd($e);
            alert()->error('Error', $e->getMessage());
        }

        alert()->success('Success', 'Data created successfully');
        return to_route('purchase-invoices.index');
    }

    public function edit(PurchaseInvoice $purchaseInvoice)
    {
        $purchaseInvoice->load(['purchaseOrder', 'user']);
        $paymentStatuses = PaymentStatus::getInstances();
        $paymentTypes = PaymentType::get()->pluck('name', 'id')->prepend('- Select Payment Type -', null);
        return view('purchaseInvoices.edit', ['purchaseInvoice' => $purchaseInvoice, 'paymentStatuses' => $paymentStatuses, 'paymentTypes' => $paymentTypes]);
    }

    public function update(PurchaseInvoiceUpdateRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $purchaseInvoice = PurchaseInvoice::on($db->value)->findOrFail($id);
                $purchaseInvoice->update($request->validated());
            }
        });

        alert()->success('Success', 'Data updated successfully');
        return to_route('purchase-invoices.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                $code = PurchaseInvoice::find($id)->code;
                foreach (DatabaseConnection::getInstances() as $db) {
                    $purchaseInvoice = PurchaseInvoice::on($db->value)->where('code', $code);
                    if ($purchaseInvoice) {
                        $purchaseInvoice->delete();
                    }
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
