<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\UomStoreRequest;
use App\Models\Uom;
use App\Services\UomService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class UomController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:uoms_access', ['only' => 'index']);
        $this->middleware('permission:uoms_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:uoms_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:uoms_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = Uom::query();
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $editGate      = 'uoms_edit';
                $deleteGate    = 'uoms_delete';
                $crudRoutePart = 'uoms';

                return view('layouts.includes.datatablesActions', compact(
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('uoms.index');
    }

    public function create(Request $request)
    {
        return view('uoms.create');
    }

    public function store(UomStoreRequest $request)
    {
        UomService::store($request);

        alert()->success('Success', 'Data created successfully');
        return to_route('uoms.index');
    }

    public function edit(Uom $uom)
    {
        return view('uoms.edit', ['uom' => $uom]);
    }

    public function update(UomStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $uom = Uom::on($db->value)->findOrFail($id);
                $uom->update($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('uoms.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $uom = Uom::on($db->value)->find($id);
                    $uom->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
