<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class RoleController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:roles_access', ['only' => ['index', 'show']]);
        $this->middleware('permission:roles_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:roles_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:roles_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Role::select(sprintf('%s.*', (new Role)->table));
            return DataTables::of($data)->addIndexColumn()
                ->addColumn('placeholder', '&nbsp;')
                ->addColumn('actions', function ($row) {
                    $viewGate      = 'roles_access';
                    $editGate      = 'roles_edit';
                    $deleteGate    = 'roles_delete';
                    $crudRoutePart = 'roles';
                    return view('layouts.includes.datatablesActions', compact('row', 'viewGate', 'editGate', 'deleteGate', 'crudRoutePart'));
                })
                ->rawColumns(['placeholder', 'actions'])
                ->make(true);
        }
        return view('roles.index');
    }

    public function create()
    {
        $permissions = Permission::whereNull('parent_id')->get();

        return view('roles.create', ['permissions' => $permissions]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:roles,name',
            'permission_ids' => 'nullable|array',
            'permission_ids.*' => 'exists:permissions,id',
        ]);

        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $role = Role::on($db->value)->create(['name' => $request->name]);
                $role->syncPermissions($request->permission_ids ?? []);
            }
        });

        alert()->success('Success', 'Data created successfully');
        return redirect('roles');
    }

    public function edit(Role $role)
    {
        $rolePermissions = $role->permissions->pluck('id')->all();
        $permissions = Permission::whereNull('parent_id')->get();

        return view('roles.edit', ['role' => $role, 'permissions' => $permissions, 'rolePermissions' => $rolePermissions]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|unique:roles,name,' . $id,
            'permission_ids' => 'nullable|array',
            'permission_ids.*' => 'exists:permissions,id',
        ]);

        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $role = Role::on($db->value)->findOrFail($id);
                $role->update($request->all());
                $role->syncPermissions($request->permission_ids ?? []);
            }
        });

        alert()->success('Success', 'Data updated successfully');
        return redirect('roles');
    }

    public function destroy($id)
    {
        if ($id == 1) return $this->ajaxError('This role can not deleted!');
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $role = Role::on($db->value)->find($id);
                    $role->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    // public function massDestroy(Request $request)
    // {
    //     $request->validate([
    //         'ids'   => 'required|array',
    //         'ids.*' => 'exists:companies,id',
    //     ]);

    //     Role::whereIn('id', $request->ids)->delete();
    //     alert()->success('Success', 'Data deleted successfully');
    //     return response(null, 204);
    // }
}
