<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Enums\PaymentStatus;
use App\Enums\SettingKey;
use App\Enums\UserType;
use App\Http\Requests\SalesOrderStoreAdminRequest;
use App\Http\Requests\SalesOrderStoreRequest;
use App\Models\PaymentType;
use App\Models\ProductUom;
use App\Models\SalesOrder;
use App\Models\SalesOrderDetail;
use App\Models\Setting;
use App\Models\User;
use App\Services\CoreService;
use App\Services\ProductService;
use App\Services\SalesOrderService;
use App\Services\SettingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class SalesOrderController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:sales_orders_access', ['only' => 'index']);
        $this->middleware('permission:sales_orders_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:sales_orders_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:sales_orders_delete', ['only' => ['destroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $startDate = $request->start_date ?? date('Y-m-d');
            $endDate = $request->end_date ?? date('Y-m-t');

            $query = SalesOrder::select(sprintf('%s.*', (new SalesOrder())->table))
                ->createdDateRange($startDate, $endDate)
                ->with(['user']);
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('user_name', fn ($row) => $row->user?->name ?? '');
            $table->addColumn('customer_name', fn ($row) => $row->customer?->name ?? '');
            $table->editColumn('total_price', fn ($row) => rupiah($row->total_price));
            $table->editColumn('transaction_datetime', function ($row) {
                return date('d-m-Y H:i', strtotime($row->transaction_datetime));
            });
            $table->addColumn('payment_status', function ($row) {
                if ($row->total_paid == 0) {
                    $html = '<span class="badge badge-secondary">UNPROCESSED</span>';
                } elseif ($row->total_price == $row->total_paid) {
                    $html = '<span class="badge badge-success">PAID</span>';
                } else {
                    $html = '<span class="badge badge-warning">PARTIAL</span>';
                }

                return $html;
            });
            $table->editColumn('actions', function ($row) {
                $extraActions = '';
                $extraActions .= '<a class="btn btn-sm btn-primary" href="' . route('sales-orders.generate-pdf', [$row->id]) . '">Receipt</a>&nbsp';
                if (auth()->user()->isAdmin) {
                    $extraActions .= '<a class="btn btn-sm btn-primary" href="' . route('sales-orders.generate-pdf', [$row->id, 'invoice' => true]) . '">Invoice</a>';
                }
                $viewGate = 'sales_orders_view';
                $editGate = 'sales_orders_edit';
                $deleteGate = 'sales_orders_delete';
                $crudRoutePart = 'sales-orders';

                return view('layouts.includes.datatablesActions', compact(
                    'extraActions',
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions', 'payment_status']);

            return $table->make(true);
        }
        return view('salesOrders.index');
    }

    public function show(SalesOrder $salesOrder)
    {
        $paymentTypes = PaymentType::get()->pluck('name', 'id')->prepend('- Select Payment Type -', null);
        $paymentStatuses = PaymentStatus::getInstances();
        return view('salesOrders.show', ['salesOrder' => $salesOrder, 'paymentTypes' => $paymentTypes, 'paymentStatuses' => $paymentStatuses]);
    }

    public function create()
    {
        $customers = User::where('type', UserType::CUSTOMER)->get(['id', 'name'])->pluck('name', 'id')->prepend('- Select Customer -', null);
        $stockCheck = Setting::select('value')->where('key', SettingKey::STOCK_LESS_THAN_0)->first()->value;

        return view('salesOrders.create', ['customers' => $customers, 'stockCheck' => $stockCheck]);
    }

    public function store(SalesOrderStoreRequest $request)
    {
        SalesOrderService::store($request);

        alert()->success('Success', 'Data created successfully');
        return to_route('sales-orders.index');
    }

    public function edit(SalesOrder $salesOrder)
    {
        $salesOrder->details->each(function ($detail) use ($salesOrder) {
            $detail->product->load(['productBrand', 'productCategory', 'stock', 'uoms']);
            $detail->product->select_books = ProductService::getSelectBooks($detail->product);
            $detail->selectedUom = ProductUom::where('product_id', $detail->product_id)->where('uom_id', $detail->uom_id)->first();
            $detail->priceHistories = SalesOrderDetail::selectRaw('unit_price, total_discount, sales_order_details.total_price, sales_orders.transaction_datetime, CONCAT_WS(" and ", total_discount,unit_price) as unique_key')
                ->join('sales_orders', 'sales_orders.id', '=', 'sales_order_details.sales_order_id')
                ->where('product_id', $detail->product_id)
                ->where('uom_id', $detail->uom_id)
                ->whereHas('salesOrder', fn ($q) => $q->where('customer_id', $salesOrder->customer_id))
                ->orderByDesc('sales_orders.transaction_datetime')
                ->get()
                ->makeHidden(['code_decrypt'])
                ->unique('unique_key');
        });
        $customers = User::where('type', UserType::CUSTOMER)->get(['id', 'name'])->pluck('name', 'id')->prepend('- Select Customer -', null);
        $databaseConnections = DatabaseConnection::getInstances();
        $currentConnection = CoreService::getCookieDbConnection();
        $stockCheck = Setting::select('value')->where('key', SettingKey::STOCK_LESS_THAN_0)->first()->value;

        return view('salesOrders.edit', ['salesOrder' => $salesOrder, 'customers' => $customers, 'databaseConnections' => $databaseConnections, 'currentConnection' => $currentConnection, 'stockCheck' => $stockCheck]);
    }

    public function update(SalesOrder $salesOrder, SalesOrderStoreAdminRequest $request)
    {
        SalesOrderService::updateAdmin($salesOrder, $request);

        alert()->success('Success', 'Data updated successfully');
        return to_route('sales-orders.index');
    }

    public function destroy(SalesOrder $salesOrder)
    {
        try {
            if ($salesOrder == auth()->user()) {
                return $this->ajaxError('Data failed to delete');
            } else {
                foreach ($salesOrder->details as $detail) {
                    //Stock::where('product_id', $detail->product_id)->increment('qty', $detail->stockHistory->qty ?? 0);
                    $qty = $detail->product?->uoms()->where('uom_id', $detail->uom_id)->first(['quantity'])?->quantity;
                    $detail->stockHistory()->create([
                        'user_id' => Auth::user()->id,
                        'stock_id' => $detail->product?->stock->id,
                        'is_increment' => true,
                        'qty' => $detail->qty * $qty,
                        'description' => 'Cancel Sales Order from ' . $detail->salesOrder->customer->name . ' Invoice No ' . $detail->salesOrder->code
                    ]);
                }
                $salesOrder->delete();
            }
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    public function createAdmin(SalesOrder $salesOrder)
    {
        $databaseConnections = DatabaseConnection::getInstances();
        $customers = User::where('type', UserType::CUSTOMER)->get(['name', 'id'])->pluck('name', 'id')->prepend('- Select Customer -', null);
        $currentConnection = CoreService::getCookieDbConnection();
        $stockCheck = Setting::select('value')->where('key', SettingKey::STOCK_LESS_THAN_0)->first()->value;
        $code = SettingService::getCurrentValue(SettingKey::SO_NUMBER);

        return view('salesOrders.create-admin', ['salesOrder' => $salesOrder, 'databaseConnections' => $databaseConnections, 'customers' => $customers, 'currentConnection' => $currentConnection, 'stockCheck' => $stockCheck, 'code' => $code]);
    }

    public function storeAdmin(SalesOrderStoreAdminRequest $request)
    {
        $salesOrder = SalesOrderService::storeAdmin($request);
        $salesOrderCode = $salesOrder->code;

        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL;
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY;

        $salesOrder = SalesOrder::on($dbConnection)->firstWhere('code', $salesOrderCode);
        if (!$salesOrder) {
            if ($dbConnection == $mysql) {
                $salesOrder = SalesOrder::on($mysqlSecondary)->firstWhere('code', $salesOrderCode);
            } else {
                $salesOrder = SalesOrder::on($mysql)->firstWhere('code', $salesOrderCode);
            }
        }

        alert()->success('Success', 'Data created successfully');

        if ($request->redirect) return redirect($request->redirect);

        return to_route('sales-orders.show', $salesOrder);
    }

    public function generatePDF(SalesOrder $salesOrder, Request $request)
    {
        $data['salesOrder'] = $salesOrder::with('details', 'customer')->where('id', $salesOrder->id)->first();
        $data['salesOrder']->sub_total = $salesOrder->details->sum('total_price');

        if ($request->invoice) {
            $pdf = \Pdf::loadView('pdf.salesOrderReceipts', ['data' => $data])->setPaper('a4', 'potrait');
            return $pdf->stream('Sales Order ' . $data['salesOrder']->code . '.pdf', array("Attachment" => false));
        } else {
            $pdf = \Pdf::loadView('pdf.salesOrderThermalReceipts', ['data' => $data])->setPaper('a4', 'potrait');
            return $pdf->stream('Sales Order ' . $data['salesOrder']->code . '.pdf', array("Attachment" => false));
        }
    }
}
