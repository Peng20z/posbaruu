<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\CustomerGroupProductStoreRequest;
use App\Http\Requests\CustomerGroupProductUpdateRequest;
use App\Models\CustomerGroup;
use App\Models\CustomerGroupProduct;
use App\Models\Product;
use App\Services\ProductUomService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class CustomerGroupProductController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:customer_group_products_access', ['only' => 'index']);
        $this->middleware('permission:customer_group_products_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:customer_group_products_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:customer_group_products_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(CustomerGroup $customerGroup, Request $request)
    {
        if ($request->ajax()) {
            $query = CustomerGroupProduct::select(sprintf('%s.*', (new CustomerGroupProduct())->table))->where('customer_group_id', $customerGroup->id)->with(['uom', 'product']);
            $table = DataTables::eloquent($query);

            $table->addColumn('uom_name', fn($row) => $row->uom?->name ?? '');
            $table->addColumn('product_id', fn($row) => $row->product?->id ?? '');
            $table->addColumn('product_name', fn($row) => $row->product?->name ?? '');
            $table->editColumn('sell_price', fn($row) => rupiah($row->sell_price));
            $table->editColumn('actions', function ($row) {
                $editGate = 'customer_group_products_edit';
                $deleteGate = 'customer_group_products_delete';
                $crudRoutePart = 'customer-groups.products';
                $prefixRoute = $row->customer_group_id;
                return view(
                    'layouts.includes.nestedDatatablesActions',
                    compact(
                        'prefixRoute',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('customerGroupProducts.index', ['customerGroup' => $customerGroup]);
    }

    public function create(CustomerGroup $customerGroup, Request $request)
    {
        $products = Product::whereNotIn('id', $customerGroup->customerGroupProducts->pluck('product_id') ?? [])->get(['id', 'name'])->pluck('name', 'id')->prepend('- Select Product -', null);
        return view('customerGroupProducts.create', ['customerGroup' => $customerGroup, 'products' => $products]);
    }

    public function store(CustomerGroup $customerGroup, CustomerGroupProductStoreRequest $request)
    {

        $discounts = ProductUomService::generateDiscountsData($request->sell_price, $request->discounts);
        $data = $request->validated();
        $data['customer_group_id'] = $customerGroup->id;

        DB::transaction(function () use ($data, $discounts) {
            foreach (DatabaseConnection::getInstances() as $db) {

                if (isset($data['discounts'])) unset($data['discounts']);

                CustomerGroupProduct::on($db->value)->create([
                    ...$data,
                    'discounts' => $discounts,
                ]);
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('customer-groups.products.index', [$customerGroup]);
    }

    public function edit(CustomerGroup $customerGroup, CustomerGroupProduct $customerGroupProduct)
    {
        return view('customerGroupProducts.edit', ['customerGroup' => $customerGroup, 'customerGroupProduct' => $customerGroupProduct]);
    }

    public function update(CustomerGroup $customerGroup, CustomerGroupProductUpdateRequest $request, $id)
    {
        $discounts = ProductUomService::generateDiscountsData($request->sell_price, $request->discounts);
        DB::transaction(function () use ($request, $id, $discounts) {
            foreach (DatabaseConnection::getInstances() as $db) {
                if (isset($data['discounts'])) unset($data['discounts']);

                $customerGroup = CustomerGroupProduct::on($db->value)->findOrFail($id);
                $customerGroup->update([$request->validated(), 'discounts' => $discounts]);
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('customer-groups.products.index', [$customerGroup]);
    }

    public function destroy(CustomerGroup $customerGroup, $id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $customerGroupProduct = CustomerGroupProduct::on($db->value)->find($id);
                    $customerGroupProduct->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
