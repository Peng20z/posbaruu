<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\ProductBrandStoreRequest;
use App\Models\ProductBrand;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class ProductBrandController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:product_brands_access', ['only' => 'index']);
        $this->middleware('permission:product_brands_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:product_brands_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:product_brands_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = ProductBrand::query();
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $editGate      = 'product_brands_edit';
                $deleteGate    = 'product_brands_delete';
                $crudRoutePart = 'product-brands';

                return view('layouts.includes.datatablesActions', compact(
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('productBrands.index');
    }

    public function create(Request $request)
    {
        return view('productBrands.create');
    }

    public function store(ProductBrandStoreRequest $request)
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                ProductBrand::on($db->value)->create($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('product-brands.index');
    }

    public function edit(ProductBrand $productBrand)
    {
        return view('productBrands.edit', ['productBrand' => $productBrand]);
    }

    public function update(ProductBrandStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $productBrand = ProductBrand::on($db->value)->findOrFail($id);
                $productBrand->update($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('product-brands.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $productBrand = ProductBrand::on($db->value)->find($id);
                    $productBrand->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
