<?php

namespace App\Http\Controllers;

use App\Enums\NormalBalance;
use App\Http\Requests\Journal\StoreRequest;
use App\Models\Coa;
use App\Models\Journal;
use App\Models\JournalDetail;
use App\Services\JournalService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class JournalController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:journal_access', ['only' => 'index']);
        $this->middleware('permission:journal_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:journal_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:journal_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function listJournals(Request $request)
    {
        if ($request->ajax()) {
            $startDate = $request->start_date ?? date('Y-m-d');
            $endDate = $request->end_date ?? date('Y-m-t');

            $query = JournalDetail::select(sprintf('%s.*', (new JournalDetail())->getTable()))
                ->whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))
                ->with([
                    'coa' => fn ($q) => $q->select('id', 'account_name', 'account_number'),
                    'journal' => fn ($q) => $q->select('id', 'user_id', 'code', 'transaction_date')
                        ->with('user', fn ($q) => $q->select('id', 'name')),
                ]);

            $table = DataTables::eloquent($query);

            $table->addColumn('code', fn ($q) => $q->journal?->code ?? '');
            $table->addColumn('user_name', fn ($q) => $q->journal?->user?->name ?? '');
            $table->addColumn('transaction_date', fn ($q) => $q->journal?->transaction_date ?? '');
            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $html = '';
                if (auth()->user()->can('journal_view')) {
                    $html .= '<a class="btn btn-sm btn-primary" href="' . route('journals.show', $row->journal?->id) . '" title="Detail"><i class="fa fa-eye"></i></a>';
                }
                if (auth()->user()->can('journal_edit')) {
                    // @can($editGate)
                    $html .= '<a class="btn btn-sm btn-info" href="' . route('journals.edit', $row->journal?->id) . '" title="Edit"><i class="fa fa-edit"></i></a>';
                    // @endcan
                }
                return $html;
                // $viewGate      = 'journal_view';
                // $editGate      = 'journal_edit';
                // // $deleteGate    = 'journal_delete';
                // $crudRoutePart = 'journals';

                // return view('layouts.includes.datatablesActions', compact(
                //     'viewGate',
                //     'editGate',
                //     // 'deleteGate',
                //     'crudRoutePart',
                //     'row'
                // ));
            });

            $search = $request->search['value'] ?? null;
            $table->filterColumn('user.name', function ($query) use ($search) {
                $query->whereHas('journal.user', fn ($q) => $q->where('name', 'like', "%{$search}%"));
            });

            $table->filterColumn('coa.account_number', function ($query) use ($search) {
                $query->whereHas('coa', fn ($q) => $q->where(fn ($q) => $q->whereLike('account_name', "%{$search}%")->orWhereLike('account_number', "%{$search}%")));
            });

            $table->addColumn('account_number', fn ($q) => $q->coa->account_number . ' : ' . $q->coa->account_name);
            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('journals.list');
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $startDate = $request->start_date ?? date('Y-m-d');
            $endDate = $request->end_date ?? date('Y-m-t');

            $query = Journal::select(sprintf('%s.*', (new Journal())->getTable()))
                ->transactionDateRange($startDate, $endDate)
                ->with([
                    'user' => fn ($q) => $q->select('id', 'name'),
                    'details' => fn ($q) => $q->select('journal_id', 'debit'),
                ]);
            $table = DataTables::eloquent($query);

            $table->addColumn('user_name', fn ($q) => $q->user?->name ?? '');
            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $viewGate      = 'journal_view';
                $editGate      = 'journal_edit';
                $deleteGate    = 'journal_delete';
                $crudRoutePart = 'journals';

                return view('layouts.includes.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->orderColumn('total_amount', function ($query, $order) use ($request) {
                $query->selectRaw('SUM(journal_details.debit) as total_amount')
                    ->join('journal_details', 'journals.id', '=', 'journal_details.journal_id')
                    ->groupBy('journals.id')
                    ->orderBy('total_amount', $order);
            });
            $table->addColumn('total_amount', fn ($q) => number_format($q->total_amount));

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('journals.index');
    }

    public function show(Journal $journal)
    {
        $journal->load('details');
        return view('journals.show', ['journal' => $journal]);
    }

    public function create(Request $request)
    {
        $coas = Coa::getChildsSelections();
        return view('journals.create', ['coas' => $coas]);
    }

    public function store(StoreRequest $request)
    {
        $details = collect($request->details);
        $debit = $details->sum('debit');
        $credit = $details->sum('credit');
        if ($debit != $credit) {
            return redirect()->back()->withErrors([
                'balance_not_match' => 'Balance does not match.'
            ])->withInput($request->validated());
        }

        try {
            JournalService::store($request);
            alert()->success('Success', 'Data created successfully');
        } catch (Exception $e) {
            dd($e);
            alert()->error('Error', $e->getMessage());
        }

        return to_route('journals.index');
    }

    public function edit(Journal $journal)
    {
        $normalBalances = NormalBalance::asSelectArray();
        $coas = Coa::getChildsSelections();

        $journal->load('details');
        return view('journals.edit', ['journal' => $journal, 'coas' => $coas, 'normalBalances' => $normalBalances]);
    }

    public function update(StoreRequest $request, int $id)
    {
        $details = collect($request->details);
        $debit = $details->sum('debit');
        $credit = $details->sum('credit');
        if ($debit != $credit) {
            return redirect()->back()->withErrors([
                'balance_not_match' => 'Balance does not match.'
            ])->withInput($request->validated());
        }

        try {
            JournalService::update($request, $id);
            alert()->success('Success', 'Data created successfully');
        } catch (Exception $e) {
            alert()->error('Error', $e->getMessage());
        }

        return to_route('journals.index');
    }

    public function destroy(int $id)
    {
        try {
            JournalService::destroy($id);
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
