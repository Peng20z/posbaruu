<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\PaymentTypeStoreRequest;
use App\Models\PaymentType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class PaymentTypeController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:payment_types_access', ['only' => 'index']);
        $this->middleware('permission:payment_types_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:payment_types_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:payment_types_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = PaymentType::query();
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $editGate      = 'payment_types_edit';
                $deleteGate    = 'payment_types_delete';
                $crudRoutePart = 'payment-types';

                return view('layouts.includes.datatablesActions', compact(
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('paymentTypes.index');
    }

    public function create(Request $request)
    {
        return view('paymentTypes.create');
    }

    public function store(PaymentTypeStoreRequest $request)
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                PaymentType::on($db->value)->create($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('payment-types.index');
    }

    public function edit(PaymentType $paymentType)
    {
        return view('paymentTypes.edit', ['paymentType' => $paymentType]);
    }

    public function update(PaymentTypeStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $paymentType = PaymentType::on($db->value)->findOrFail($id);
                $paymentType->update($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('payment-types.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $paymentType = PaymentType::on($db->value)->find($id);
                    $paymentType->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
