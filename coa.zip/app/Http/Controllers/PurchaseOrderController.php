<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Enums\POStatus;
use App\Enums\POTerms;
use App\Enums\SettingKey;
use App\Http\Requests\PurchaseOrderStoreRequest;
use App\Http\Requests\PurchaseOrderUpdateRequest;
use App\Models\ProductUom;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderDetail;
use App\Models\ReceiveOrderDetail;
use App\Models\Setting;
use App\Models\Stock;
use App\Models\Supplier;
use App\Services\CoreService;
use App\Services\PurchaseOrderService;
use App\Services\SettingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class PurchaseOrderController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:purchase_orders_access', ['only' => 'index']);
        $this->middleware('permission:purchase_orders_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:purchase_orders_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:purchase_orders_delete', ['only' => ['destroy']]);
    }

    public function index(Request $request)
    {

        if ($request->ajax()) {
            $startDate = $request->start_date ?? date('Y-m-d');
            $endDate = $request->end_date ?? date('Y-m-t');

            $query = PurchaseOrder::select(sprintf('%s.*', (new PurchaseOrder())->table))
                ->createdDateRange($startDate, $endDate)
                ->with(['user', 'supplier']);

            $table = Datatables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('user_name', fn ($row) => $row->user?->name ?? '');
            $table->addColumn('supplier_name', fn ($row) => $row->supplier?->name ?? '');
            $table->editColumn('total_price', fn ($row) => rupiah($row->total_price, true));
            $table->editColumn('status', fn ($row) => $row->status->getColored());
            $table->addColumn('payment_status', function ($row) {
                if ($row->total_paid == 0) {
                    $html = '<span class="badge badge-secondary">UNPROCESSED</span>';
                } elseif ($row->total_price == $row->total_paid) {
                    $html = '<span class="badge badge-success">PAID</span>';
                } else {
                    $html = '<span class="badge badge-warning">PARTIAL</span>';
                }

                return $html;
            });
            $table->editColumn('actions', function ($row) {
                $viewGate = 'purchase_orders_view';
                $editGate = ($row->status == POStatus::COMPLETED || CoreService::getCookieDbConnection() == DatabaseConnection::MYSQL ? true : (str_contains($row->code, 'BB') ? true : false)) ? 'purchase_orders_edit' : '';
                $deleteGate = 'purchase_orders_delete';
                $crudRoutePart = 'purchase-orders';

                return view(
                    'layouts.includes.datatablesActions',
                    compact(
                        'viewGate',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });

            $table->rawColumns(['placeholder', 'actions', 'status', 'payment_status']);

            return $table->make(true);
        }
        return view('purchaseOrders.index');
    }

    public function show(PurchaseOrder $purchaseOrder)
    {
        if ($purchaseOrder->status == POStatus::COMPLETED) {
            foreach ($purchaseOrder->details as $detail) {
                $detail->qtyReceived = $detail->qty;
            }
        } else {
            foreach ($purchaseOrder->details as $detail) {
                $roDetailsPerProduct = ReceiveOrderDetail::query()
                    ->whereHas('receiveOrder', fn ($query) => $query->where('purchase_order_id', $purchaseOrder->id))
                    ->where('product_id', $detail->product_id)
                    ->get();

                $detail->qtyReceived = $roDetailsPerProduct->sum('qty') ?? 0;;
            }
        }

        $dbConnection = CoreService::getCookieDbConnection();
        $canAddToStock = $purchaseOrder->details?->every(fn ($detail) => !$detail->stockHistory) ?? true;
        $correctBook = $dbConnection == DatabaseConnection::MYSQL ? true : (str_contains($purchaseOrder->code, 'BB') ? true : false);
        $isSkipRo = Setting::select('value')->where('key', SettingKey::IS_SKIP_RO)->first()->value;

        return view('purchaseOrders.show', ['purchaseOrder' => $purchaseOrder, 'canAddToStock' => $canAddToStock, 'isSkipRo' => $isSkipRo, 'correctBook' => $correctBook]);
    }

    public function create()
    {
        $suppliers = Supplier::get(['name', 'id'])->pluck('name', 'id')->prepend('- Select Supplier -', null);
        $poTerms = POTerms::getInstances();
        $code = SettingService::getCurrentValue(SettingKey::PO_NUMBER);
        return view('purchaseOrders.create', ['suppliers' => $suppliers, 'poTerms' => $poTerms, 'code' => $code]);
    }

    public function store(PurchaseOrderStoreRequest $request)
    {
        PurchaseOrderService::store($request);

        alert()->success('Success', 'Data created successfully');
        return to_route('purchase-orders.index');
    }

    public function edit(PurchaseOrder $purchaseOrder)
    {
        $purchaseOrder->load('details');
        $purchaseOrder->details->each(function ($detail) use ($purchaseOrder) {
            $detail->priceHistories = PurchaseOrderDetail::selectRaw('unit_price, discount, purchase_order_details.total_price, purchase_orders.created_at, CONCAT_WS(" and ", discount,unit_price) as unique_key')
                ->join('purchase_orders', 'purchase_orders.id', '=', 'purchase_order_details.purchase_order_id')
                ->where('product_id', $detail->product_id)
                ->where('uom_id', $detail->uom_id)
                ->whereHas('purchaseOrder', fn ($q) => $q->where('supplier_id', $purchaseOrder->supplier_id))
                ->orderByDesc('purchase_orders.created_at')
                ->get()
                ->makeHidden(['code_decrypt'])
                ->unique('unique_key');
        });
        $suppliers = Supplier::get(['name', 'id'])->pluck('name', 'id')->prepend('- Select Supplier -', null);
        $poTerms = POTerms::getInstances();
        return view('purchaseOrders.edit', ['purchaseOrder' => $purchaseOrder, 'suppliers' => $suppliers, 'poTerms' => $poTerms]);
    }

    public function update(PurchaseOrder $purchaseOrder, PurchaseOrderUpdateRequest $request)
    {
        PurchaseOrderService::update($request, $purchaseOrder);

        alert()->success('Success', 'Data updated successfully');
        return to_route('purchase-orders.index');
    }

    public function destroy(PurchaseOrder $purchaseOrder)
    {
        try {
            if ($purchaseOrder == auth()->user()) {
                return $this->ajaxError('Data failed to delete');
            } else {
                DB::transaction(function () use ($purchaseOrder) {
                    $code = PurchaseOrder::find($purchaseOrder->id)->code;
                    foreach (DatabaseConnection::getInstances() as $db) {
                        $purchaseOrder = PurchaseOrder::on($db->value)->where('code', $code)->first();
                        if ($purchaseOrder) {
                            foreach ($purchaseOrder->details as $detail) {
                                //Stock::where('product_id', $detail->product_id)->increment('qty', $detail->stockHistory->qty ?? 0);
                                $qty = $detail->product?->uoms()->where('uom_id', $detail->uom_id)->first(['quantity'])?->quantity;
                                $detail->stockHistory()->create([
                                    'user_id' => Auth::user()->id,
                                    'stock_id' => $detail->product?->stock->id,
                                    'is_increment' => false,
                                    'qty' => $detail->qty * $qty,
                                    'description' => 'Cancel Purchase Order from ' . $detail->purchaseOrder->supplier->name . ' PO No ' . $detail->purchaseOrder->po_number
                                ]);
                            }
                            $purchaseOrder->delete();
                        }
                    }
                });
            }
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    public function storeToStock(PurchaseOrder $purchaseOrder, Request $request)
    {
        DB::beginTransaction();
        try {
            foreach ($purchaseOrder->details as $detail) {
                $stock = Stock::firstWhere('product_id', $detail->product_id);

                // // $poDetailperProduct = PurchaseOrderDetail::query()
                // //     ->whereHas('purchaseOrder', fn ($query) => $query->where('receive_order_id', $receiveOrder->id))
                // //     ->where('product_id', $detail->product_id)
                // //     ->first();
                $poDetailperProduct = $purchaseOrder->details()->where('product_id', $detail->product_id)->first(['product_id', 'uom_id']);
                $productUomQty = ProductUom::where('product_id', $poDetailperProduct->product_id)->where('uom_id', $poDetailperProduct->uom_id)->first(['quantity']);

                if ($stock) {
                    $detail->stockHistory()->create([
                        'user_id' => Auth::user()->id,
                        'stock_id' => $stock->id,
                        'is_increment' => 1,
                        'qty' => $detail->qty * $productUomQty->quantity,
                        'description' => 'Purchase from ' . $purchaseOrder->supplier->name . ' PO No ' . $detail->purchaseOrder->po_number
                    ]);
                }
            }

            $purchaseOrder->status = POStatus::COMPLETED;
            $purchaseOrder->save();
            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            return $request->wantsJson()
                ? new JsonResponse(['success' => false, 'message' => $th->getMessage()], 400)
                : to_route('purchase-orders.show', $purchaseOrder);
        }

        return $request->wantsJson()
            ? new JsonResponse(['success' => true, 'message' => 'Success add to stock'], 201)
            : to_route('purchase-orders.show', $purchaseOrder);
    }

    public function retrieveStock(PurchaseOrder $purchaseOrder, Request $request)
    {
        DB::beginTransaction();
        try {
            foreach ($purchaseOrder->details as $detail) {
                $stock = Stock::firstWhere('product_id', $detail->product_id);

                if ($stock->qty < $detail->stockHistory->qty) {
                    return false;
                };
            }

            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            return $request->wantsJson()
                ? new JsonResponse(['success' => false, 'message' => $th->getMessage()], 400)
                : to_route('purchase-orders.show', $purchaseOrder);
        }

        foreach ($purchaseOrder->details as $detail) {
            Stock::where('product_id', $detail->product_id)->decrement('qty', $detail->stockHistory->qty ?? 0);
            $detail->stockHistory?->delete();
        }

        $purchaseOrder->status = POStatus::PROCESS;
        $purchaseOrder->save();

        return $request->wantsJson()
            ? new JsonResponse(['success' => true, 'message' => 'Success retrieve stock'], 201)
            : to_route('purchase-orders.show', $purchaseOrder);
    }
}
