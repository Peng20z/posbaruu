<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\ProductStoreRequest;
use App\Imports\ProductsImport;
use App\Models\Product;
use App\Models\ProductBrand;
use App\Models\ProductCategory;
use App\Models\ProductUom;
use App\Models\PurchaseOrderDetail;
use App\Models\Uom;
use App\Services\CoreService;
use App\Services\ProductService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Yajra\DataTables\Facades\DataTables;

class ProductController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:products_access', ['only' => 'index']);
        $this->middleware('permission:products_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:products_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:products_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = Product::select(sprintf('%s.*', (new Product())->table))->with(['productCategory', 'productBrand']);
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('product_brand_name', function ($row) {
                return $row->productBrand?->name ?? '';
            });
            $table->addColumn('product_category_name', function ($row) {
                return $row->productCategory?->name ?? '';
            });
            $table->editColumn('actions', function ($row) {
                $extraActions  = '';
                $extraActions .= '<a class="btn btn-sm btn-primary" href="' . route('products.uoms.index', $row->id) . '">Product Uom</a>';
                $editGate      = 'products_edit';
                $deleteGate    = 'products_delete';
                $crudRoutePart = 'products';

                return view('layouts.includes.datatablesActions', compact(
                    'extraActions',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('products.index');
    }

    public function show(Product $product)
    {
        return view('products/show', ['product' => $product]);
    }

    public function create(Request $request)
    {
        $productBrands = ProductBrand::all()->pluck('name', 'id')->prepend('-- Select Product Brand --', null);
        $productCategories = ProductCategory::all()->pluck('name', 'id')->prepend('-- Select Product Category --', null);
        $uoms = Uom::all()->pluck('name', 'id')->prepend('-- Select Uom --', null);

        return view('products/create', ['productBrands' => $productBrands, 'productCategories' => $productCategories, 'uoms' => $uoms]);
    }

    public function store(ProductStoreRequest $request)
    {
        ProductService::store($request);
        alert()->success('Success', 'Data created successfully');
        return to_route('products.index');
    }

    public function edit(Product $product)
    {
        $productBrands = ProductBrand::all()->pluck('name', 'id');
        $productCategories = ProductCategory::all()->pluck('name', 'id');

        return view('products/edit', ['product' => $product, 'productBrands' => $productBrands, 'productCategories' => $productCategories]);
    }

    public function update(ProductStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $product = Product::on($db->value)->find($id);
                if ($product) {
                    $product->update($request->validated());
                }
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('products.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $product = Product::on($db->value)->find($id);
                    $product->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    public function productPriceList(Request $request)
    {
        if ($request->ajax()) {
            $products = Product::with('uoms')->whereNameLike($request->search)->get();
            return response()->json($products);
        }

        $products = Product::limit(50)->get();
        return view('products.products-price-list', ['products' => $products]);
    }

    public function importExcel(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:csv,xls,xlsx'
        ]);

        Excel::import(new ProductsImport, request()->file('file'));

        return to_route('products.index');
    }

    public static function recalculateCapital(Product $product)
    {
        if (CoreService::getCookieDbConnection() == 'mysql') {
            $purchaseOrderDetails = PurchaseOrderDetail::where('product_id', $product->id)->get();
        } else {
            $purchaseOrderDetails = PurchaseOrderDetail::where('product_id', $product->id)->whereHas('purchaseOrder', fn ($q) => $q->where('code', 'like', '%BB%'))->get();
        }
        if (count($purchaseOrderDetails) > 0) {
            $totalQty = 0;
            foreach ($purchaseOrderDetails as $detail) {
                $totalQty += $detail->qty * ProductUom::where('product_id', $detail->product_id)->where('uom_id', $detail->uom_id)->first('quantity')->quantity;
            }
            $product->capital_price = $purchaseOrderDetails->sum('total_price') / $totalQty;
            $product->save();
        } else {
            $product->capital_price = 0;
            $product->save();
        }

        return back()->withInput();
    }
}
