<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\ProductUomStoreRequest;
use App\Http\Requests\ProductUomUpdateRequest;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\Uom;
use App\Services\ProductUomService;

class ProductUomController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:product_uoms_access', ['only' => 'index']);
        $this->middleware('permission:product_uoms_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:product_uoms_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:product_uoms_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Product $product)
    {
        $product->load('uoms');

        return view('productUoms.index', ['product' => $product]);
    }

    public function create(Product $product)
    {
        $uoms = Uom::whereNotIn('id', $product->uoms?->pluck('id') ?? [])->get(['id', 'name'])->pluck('name', 'id')->prepend('- Select Uom -', null);
        return view('productUoms.create', ['product' => $product, 'uoms' => $uoms]);
    }

    public function store(Product $product, ProductUomStoreRequest $request)
    {
        ProductUomService::store($request, $product);

        alert()->success('Success', 'Data created successfully');
        return to_route('products.uoms.index', $product);
    }

    public function edit(Product $product, ProductUom $productUom)
    {
        $uoms = Uom::whereNotIn('id', $product->uoms?->pluck('id') ?? [])->get(['id', 'name'])->pluck('name', 'id')->prepend('- Select Uom -', null);
        return view('productUoms.edit', ['product' => $product, 'productUom' => $productUom, 'uoms' => $uoms]);
    }

    public function update(ProductUomUpdateRequest $request, Product $product, $id)
    {
        $discounts = ProductUomService::generateDiscountsData($request->sell_price, $request->discounts ?? []);

        $request->merge(['discounts' => $discounts]);
        ProductUomService::update($request, $product, $id);

        alert()->success('Success', 'Data created successfully');
        return to_route('products.uoms.index', $product);
    }
}
