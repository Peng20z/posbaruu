<?php

namespace App\Http\Controllers;

use App\Enums\NormalBalance;
use App\Http\Requests\Coa\StoreRequest;
use App\Models\Coa;
use App\Models\Journal;
use App\Services\CoaService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CoaController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:coa_access', ['only' => 'index']);
        $this->middleware('permission:coa_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:coa_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:coa_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        $startDate = $request->query('start_date', date('Y-m-01'));
        $endDate = $request->query('end_date', date('Y-m-t'));

        $coas = Coa::with('childs')->whereNull('parent_id')->get();
        return view('coa.index', [
            'coas' => $coas,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'queryString' => $request->getQueryString(),
        ]);
        // if ($request->ajax()) {
        //     $query = Coa::select(sprintf('%s.*', (new Coa())->getTable()));
        //     $table = DataTables::eloquent($query);

        //     $table->addColumn('saldo', fn ($q) => $q->journalDetails->sum('debit') ?? '');

        //     $table->addColumn('parent_name', fn ($q) => $q->parent?->account_name ?? '');
        //     $table->editColumn('normal_balance', fn ($q) => $q->normal_balance->is(NormalBalance::DEBIT) ? '<span class="badge badge-primary">' . $q->normal_balance->key . '</span>' : '<span class="badge badge-danger">' . $q->normal_balance->key . '</span>');
        //     $table->addColumn('placeholder', '&nbsp;');
        //     $table->editColumn('actions', function ($row) {
        //         // $viewGate      = 'coa_view';
        //         $editGate      = 'coa_edit';
        //         $deleteGate    = 'coa_delete';
        //         $crudRoutePart = 'coa';

        //         return view('layouts.includes.datatablesActions', compact(
        //             // 'viewGate',
        //             'editGate',
        //             'deleteGate',
        //             'crudRoutePart',
        //             'row'
        //         ));
        //     });

        //     $table->rawColumns(['placeholder', 'actions', 'normal_balance']);

        //     return $table->make(true);
        // }
    }

    public function show(Coa $coa, Request $request)
    {
        $startDate = $request->query('start_date', date('Y-m-01'));
        $endDate = $request->query('end_date', date('Y-m-t'));

        $journals = Journal::with('details')->whereHas('details', fn ($q) => $q->where('coa_id', $coa->id))->transactionDateRange($startDate, $endDate)->get();

        return view('coa.show', [
            'coa' => $coa,
            'journals' => $journals,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'queryString' => $request->getQueryString(),
        ]);
    }

    public function create()
    {
        $normalBalances = NormalBalance::asSelectArray();
        $coas = Coa::whereNull('parent_id')->select(DB::raw('id, CONCAT(account_name, " (",account_number,")") as account_name'))->get()->pluck('account_name', 'id')->prepend('- Select -', null);
        return view('coa.create', ['coas' => $coas, 'normalBalances' => $normalBalances]);
    }

    public function store(StoreRequest $request)
    {
        try {
            CoaService::store($request);
            alert()->success('Success', 'Data created successfully');
        } catch (Exception $e) {
            alert()->error('Error', $e->getMessage());
        }

        return to_route('coa.index');
    }

    public function edit(Coa $coa)
    {
        $normalBalances = NormalBalance::asSelectArray();
        $coas = Coa::whereNull('parent_id')->select(DB::raw('id, CONCAT(account_name, " (",account_number,")") as account_name'))->get()->pluck('account_name', 'id')->prepend('- Select -', null);
        return view('coa.edit', ['coa' => $coa, 'coas' => $coas, 'normalBalances' => $normalBalances]);
    }

    public function update(StoreRequest $request, int $id)
    {
        try {
            CoaService::update($request, $id);
            alert()->success('Success', 'Data created successfully');
        } catch (Exception $e) {
            alert()->error('Error', $e->getMessage());
        }

        return to_route('coa.index');
    }

    public function destroy(int $id)
    {
        try {
            CoaService::destroy($id);
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
