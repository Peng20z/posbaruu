<?php

namespace App\Http\Controllers\Api;

use App\Enums\DatabaseConnection;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderDetail;
use App\Models\ReceiveOrder;
use Illuminate\Http\Request;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class PurchaseOrderController extends Controller
{
    public function index(Request $request)
    {
        $paginate = 15;
        if ($request->per_page && is_numeric($request->per_page))
            $paginate = $request->per_page ?? 15;

        $query = Product::class;
        if ($request->select)
            $query = Product::select('id', 'name as text');

        $products = QueryBuilder::for($query)
            ->allowedFilters(['product_category_id', 'product_brand_id', 'name', AllowedFilter::scope('ids', 'where_id_not_in'),])
            ->allowedSorts(['id', 'product_category_id', 'product_brand_id', 'name'])
            ->paginate($paginate);

        return response()->json($products);
    }

    public function show($id)
    {
        if (request()->multidatabase == 1) {
            $purchaseOrder = PurchaseOrder::on(DatabaseConnection::MYSQL)->with(['details'])->find($id);
            $purchaseOrder2 = PurchaseOrder::on(DatabaseConnection::MYSQL_SECONDARY)->with(['details'])->find($id);

            return response()->json([
                'products' => [$purchaseOrder, $purchaseOrder2]
            ]);
        }

        $purchaseOrder = PurchaseOrderDetail::with(['product', 'uom'])->where('purchase_order_id', $id)->get();
        return response()->json($purchaseOrder);
    }

    public function getPrice(int $productId, int $uomId)
    {
        $productUom = ProductUom::where('product_id', $productId)->where('uom_id', $uomId)->first();
        return response()->json($productUom);
    }

    public function getUnpaid(Request $request)
    {
        $purchaseOrder = PurchaseOrder::where('code', $request->code)->first();
        return response()->json($purchaseOrder);
    }
}
