<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class SupplierController extends Controller
{
    public function index(Request $request)
    {
        $paginate = 15;
        if ($request->per_page && is_numeric($request->per_page))
            $paginate = $request->per_page ?? 15;

        $query = Supplier::class;
        if ($request->select)
            $query = Supplier::select('id', DB::raw('CONCAT(code," - ",name) as text'));

        $suppliers = QueryBuilder::for($query)
            ->allowedFilters([
                AllowedFilter::scope('name', 'where_name_like'),
                AllowedFilter::scope('ids', 'where_id_not_in')
            ])
            ->allowedSorts(['id', 'code', 'name', 'email', 'phone', 'description', 'address'])
            ->paginate($paginate);

        return response()->json($suppliers);
    }
}
