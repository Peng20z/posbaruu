<?php

namespace App\Http\Controllers\Api;

use App\Enums\DatabaseConnection;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderDetail;
use App\Models\ReceiveOrder;
use App\Models\ReceiveOrderDetail;
use Illuminate\Http\Request;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class ReceiveOrderController extends Controller
{
    public function index(Request $request)
    {
        $paginate = 15;
        if ($request->per_page && is_numeric($request->per_page))
            $paginate = $request->per_page ?? 15;

        $query = Product::class;
        if ($request->select)
            $query = Product::select('id', 'name as text');

        $products = QueryBuilder::for($query)
            ->allowedFilters(['product_category_id', 'product_brand_id', 'name', AllowedFilter::scope('ids', 'where_id_not_in'),])
            ->allowedSorts(['id', 'product_category_id', 'product_brand_id', 'name'])
            ->paginate($paginate);

        return response()->json($products);
    }

    public function show($id)
    {
        // if (request()->multidatabase == 1) {
        //     $purchaseOrder = PurchaseOrder::on(DatabaseConnection::MYSQL)->with(['details'])->find($id);
        //     $purchaseOrder2 = PurchaseOrder::on(DatabaseConnection::MYSQL_SECONDARY)->with(['details'])->find($id);

        //     return response()->json([
        //         'products' => [$purchaseOrder, $purchaseOrder2]
        //     ]);
        // }

        $purchaseOrder = PurchaseOrder::find($id);
        foreach ($purchaseOrder->details as $key => $detail) {
            $roDetailsPerProduct = ReceiveOrderDetail::query()
                ->whereHas('receiveOrder', fn ($query) => $query->where('purchase_order_id', $detail->purchase_order_id))
                ->where('product_id', $detail->product_id)
                ->get();

            $roDetailQty[$key] = $roDetailsPerProduct->sum('qty') ?? 0;
        }

        return response()->json($roDetailQty);
    }

    public function getPrice(int $productId, int $uomId)
    {
        $productUom = ProductUom::where('product_id', $productId)->where('uom_id', $uomId)->first();
        return response()->json($productUom);
    }
}
