<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\CustomerGroupStoreRequest;
use App\Models\CustomerGroup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class CustomerGroupController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:customer_groups_access', ['only' => 'index']);
        $this->middleware('permission:customer_groups_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:customer_groups_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:customer_groups_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = CustomerGroup::query();
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $editGate      = 'customer_groups_edit';
                $deleteGate    = 'customer_groups_delete';
                $crudRoutePart = 'customer-groups';

                $extraActions  = '';
                $extraActions .= '<a class="btn btn-sm btn-primary" href="' . route('customer-groups.products.index', $row->id) . '">Products</a>';

                return view('layouts.includes.datatablesActions', compact(
                    'extraActions',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('customerGroups.index');
    }

    public function create(Request $request)
    {
        return view('customerGroups.create');
    }

    public function store(CustomerGroupStoreRequest $request)
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                CustomerGroup::on($db->value)->create($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('customer-groups.index');
    }

    public function edit(CustomerGroup $customerGroup)
    {
        return view('customerGroups.edit', ['customerGroup' => $customerGroup]);
    }

    public function update(CustomerGroupStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $customerGroup = CustomerGroup::on($db->value)->findOrFail($id);
                $customerGroup->update($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('customer-groups.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $customerGroup = CustomerGroup::on($db->value)->find($id);
                    $customerGroup->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
