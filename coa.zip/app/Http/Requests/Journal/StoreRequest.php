<?php

namespace App\Http\Requests\Journal;

use Illuminate\Foundation\Http\FormRequest;

class StoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $details = collect($this->details)->map(function ($detail) {
            return [
                ...$detail,
                'debit' => filterPriceFloat($detail['debit'] ?? 0),
                'credit' => filterPriceFloat($detail['credit'] ?? 0),
            ];
        });

        $this->merge([
            'details' => $details->toArray(),
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $journalId = $this->journal;

        if ($journalId) {
            $additionalValidation = [
                'code' => 'required|unique:journals,code,' . $journalId,
            ];
        } else {
            $additionalValidation = [
                'code' => 'required|unique:journals,code',
            ];
        }
        return [
            ...$additionalValidation,
            'transaction_date' => 'required|date',
            'description' => 'nullable|string',
            'details' => 'required|array',
            'details.*.coa_id' => 'required|exists:coas,id',
            'details.*.debit' => 'nullable|numeric',
            'details.*.credit' => 'nullable|numeric',
            'details.*.memo' => 'nullable|string',
            'details.*.subsidiary_ledger' => 'nullable|string',
            'details.*.dept' => 'nullable|string',
            'details.*.event' => 'nullable|string',
        ];
    }

    public function messages(): array
    {
        return [
            'required' => 'field is required',
        ];
    }
}
