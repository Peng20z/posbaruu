<?php

namespace App\Http\Requests;

use App\Models\Product;
use Closure;
use Illuminate\Foundation\Http\FormRequest;

class ProductStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $isActive = 1;
        if ($this->is_active == null) {
            $isActive = 0;
        }

        $this->merge([
            'is_active' => $isActive,
            'sell_price' => filterPriceFloat($this->sell_price ?? 0),
            'buy_price' => filterPriceFloat($this->buy_price ?? 0),
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $product = $this->route('product');
        return [
            'product_brand_id' => 'required|exists:product_brands,id',
            'product_category_id' => 'required|exists:product_categories,id',
            'default_uom_id' => 'nullable|exists:uoms,id',
            'base_uom_id' => 'nullable|exists:uoms,id',

            'buy_price' => 'nullable|numeric',
            'sell_price' => 'nullable|numeric',
            'min_stock_reminder' => 'nullable|integer',
            'is_active' => 'required|boolean',
            'id' => 'required|unique:products,id,' . $product,
            'name' => [
                'required',
                function (string $attribute, mixed $value, Closure $fail) use ($product) {
                    // $similarProduct = Product::where('name', $this->name)->where('product_brand_id', $this->product_brand_id)->where('product_category_id', $this->product_category_id)->where('id', '!=', $product?->id)->first();
                    // if ($similarProduct) {
                    //     $fail("The product {$value} already exists.");
                    // }

                    $productIds = Product::where('name', $this->name)->where('product_brand_id', $this->product_brand_id)->where('product_category_id', $this->product_category_id)->get(['id'])?->pluck('id') ?? collect([]);
                    if (($productIds->count() > 0 && !$productIds->contains($product))) {
                        $fail("The product {$value} already exists.");
                    }

                    // foreach ($products as $product) {
                    //     if($product->name == $this->name){
                    //         if($this->product_brand_id == $product->product_brand_id && $this->product_category_id == $product->product_category_id){
                    //             $fail("The product {$value} already exists.");
                    //         }
                    //     }
                    // }
                },
            ],
            'description' => 'nullable',
            'update_db' => 'nullable|boolean',
        ];
    }
}
