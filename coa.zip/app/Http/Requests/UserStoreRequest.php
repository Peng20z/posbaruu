<?php

namespace App\Http\Requests;

use App\Enums\UserType;
use Illuminate\Foundation\Http\FormRequest;
use BenSampo\Enum\Rules\EnumKey;

class UserStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $user = $this->route('user');
        return [
            'name' => 'required',
            'code' => 'required|unique:users,code,' . $user,
            'email' => 'required|email|unique:users,email,' . $user,
            'password' => 'required',
            'phone' => 'nullable',
            'address' => 'nullable',
            'role_id' => 'required|integer|exists:roles,id',
            'type' => ['nullable', new EnumKey(UserType::class)],
        ];
    }
}
