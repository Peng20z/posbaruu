<?php

namespace App\Http\Requests;

use App\Enums\PaymentStatus;
use App\Models\Product;
use BenSampo\Enum\Rules\EnumValue;
use Closure;
use Illuminate\Foundation\Http\FormRequest;

class SalesOrderStoreAdminRequestBackup extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $items = [];
        // $discount = 0;
        if ($this->items) {
            foreach ($this->items as $productId => $data) {
                $discount = isset($data['discount']) && $data['discount'] != '' ? floatval($data['discount']) : 0;
                $data['discount'] = $discount;

                $unitPrice = str_replace(",", "", $data['unit_price']);
                $data['unit_price'] = round($unitPrice, 2);
                $items[$productId] = $data;
            }
        }

        $paymentAmount = filterPriceFloat($this->payment_amount);

        $this->merge([
            'items' => $items,
            'payment_amount' => $paymentAmount,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $codeValidation = 'nullable|unique:sales_orders,code';
        if ($salesOrder = $this->sales_order) {
            $codeValidation = 'nullable|unique:sales_orders,code,' . $salesOrder->id;
        }

        return [
            'code' => $codeValidation,
            'transaction_datetime' => 'required|date',
            'customer_id' => 'required|exists:users,id',
            'description' => 'nullable',

            // 'items' => 'required|array|min:1',
            'items.*' => [
                'required',
                'array',
                function ($attribute, $items, Closure $fail) {
                    $product = Product::find($items['product_id']);
                    if (!$product)
                        $fail('Product not found');

                    $product->load('stock');

                    if ($product->stock->qty <= 0 || $product->stock->qty < $items['qty'])
                        $fail('Insufficient product stock');
                }
            ],
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.book' => 'required',
            'items.*.qty' => 'required|integer',
            'items.*.uom_id' => 'required|exists:uoms,id',
            'items.*.unit_price' => 'required|numeric',
            'items.*.discount' => 'nullable|numeric',
            'items.*.ppn' => 'nullable',
            'additional_discount' => 'nullable|numeric',

            // payment
            'payment_code' => 'required|unique:payments,code',
            'payment_type_id' => 'required|exists:payment_types,id',
            'payment_amount' => 'required|numeric',
            // 'payment_amount' => 'required|numeric|max:' . $max_payment,
            'payment_status' => ['nullable', new EnumValue(PaymentStatus::class)],
            'payment_description' => 'nullable',
        ];
    }
}
