<?php

namespace App\Http\Requests;

use App\Enums\UserType;
use BenSampo\Enum\Rules\EnumKey;
use Illuminate\Foundation\Http\FormRequest;

class CustomerStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $customer = $this->route('customer');

        return [
            'name' => 'required',
            'customer_group_id' => 'nullable|integer|exists:customer_groups,id',
            'email' => 'nullable|email|unique:users,email,' . $customer,
            'password' => 'nullable',
            'phone' => 'nullable',
            'address' => 'nullable',
            'role_id' => 'required|integer|exists:roles,id',
            'type' => ['nullable', new EnumKey(UserType::class)],
            'tax_address' => 'nullable',
            'city' => 'nullable',
            'province' => 'nullable',
            'zip_code' => 'nullable',
            'country' => 'nullable',
            'phone' => 'nullable',
            'contact_person' => 'nullable',
        ];
    }
}
