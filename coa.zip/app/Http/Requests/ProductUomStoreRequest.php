<?php

namespace App\Http\Requests;

use Closure;
use Illuminate\Foundation\Http\FormRequest;

class ProductUomStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        $items = [];
        if($this->discounts['qty'][0] != '0'){
            $isPercentage = 0;
            $items['qty'] = $this->discounts['qty'];
            for ($i=0; $i < count($this->discounts['qty']) ; $i++) {
                $items['price'][$i] = filterPriceFloat($this->discounts['price'][$i] ?? 0);
                $isPercentage = isset($this->discounts['is_percentage'][$i]) && (bool) $this->discounts['is_percentage'][$i] == true ? 1 : 0;
                $items['is_percentage'][$i] = $isPercentage;
            }
        }

        $this->merge([
            'buy_price' => filterPriceFloat($this->buy_price ?? 0),
            'sell_price' => filterPriceFloat($this->sell_price ?? 0),
            'discounts' => $items,
        ]);

        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'uom_id' => 'required|exists:uoms,id',
            'buy_price' => 'required|numeric',
            'sell_price' => 'required|numeric',
            'quantity' => 'required|integer',
            'is_default' => 'nullable|boolean',
            'discounts' => 'nullable|array',
            'discounts.is_percentage' => 'array',
            'discounts.is_percentage.*' => 'boolean',
            'discounts.price' => 'array',
            'discounts.price.*' => 'numeric',
            'discounts.qty.*' => 'numeric',
            'discounts.qty' => [
                'array',
                function ($attribute, $value, Closure $fail) {
                    $sumQty = 0;
                    foreach ($value as $qty) {
                        if ($qty < $sumQty) {
                            $fail('qty order must be sequential');
                        }
                        $sumQty += $qty;
                    }
                }
            ],
        ];
    }
}
