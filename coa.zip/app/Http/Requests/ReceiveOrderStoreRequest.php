<?php

namespace App\Http\Requests;

use App\Models\PurchaseOrder;
use Closure;
use Illuminate\Foundation\Http\FormRequest;

class ReceiveOrderStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            // 'purchase_order_id' => ['required', function (string $attribute, mixed $value, Closure $fail) {
            //     $po = PurchaseOrder::find($value);
            //     if (!$po) $fail('Purchase order not found');

            //     if ($po->receiveOrder) $fail('Purchase order already has Receive Order');
            // }],\
            'code' => 'nullable|unique:receive_orders,code',
            'purchase_order_id' => 'required|exists:purchase_orders,id',
            'received_at' => 'required|date_format:Y-m-d H:i:s',
            'description' => 'nullable',
            'items.*.qty' => 'required|integer',
        ];
    }
}
