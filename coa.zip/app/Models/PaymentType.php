<?php

namespace App\Models;

class PaymentType extends BaseModel
{
    public $table = 'payment_types';

    protected $guarded = [];
}
