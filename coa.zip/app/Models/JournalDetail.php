<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class JournalDetail extends BaseModel
{
    protected $fillable = [
        'journal_id',
        'coa_id',
        'debit',
        'credit',
        'memo',
        'subsidiary_ledger',
        'dept',
        'event',
    ];

    protected $casts = [
        'debit' => 'float',
        'credit' => 'float',
    ];

    public static function booted(): void
    {
        static::saving(function (self $model) {
            if (empty($model->debit)) $model->debit = 0;
            if (empty($model->credit)) $model->credit = 0;
        });
    }

    public function journal(): BelongsTo
    {
        return $this->belongsTo(Journal::class);
    }
    public function coa(): BelongsTo
    {
        return $this->belongsTo(Coa::class);
    }
}
