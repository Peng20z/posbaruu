<?php

namespace App\Models;

use App\Enums\SettingKey;

class Setting extends BaseModel
{
    protected $fillable = ['key', 'value'];
    protected $casts = ['key' => SettingKey::class];
}
