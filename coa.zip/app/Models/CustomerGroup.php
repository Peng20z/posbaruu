<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\HasMany;

class CustomerGroup extends BaseModel
{
    public $table = 'customer_groups';

    protected $guarded = [];

    public function customers(): HasMany
    {
        return $this->hasMany(User::class);
    }

    public function customerGroupProducts(): HasMany
    {
        return $this->hasMany(CustomerGroupProduct::class);
    }
}
