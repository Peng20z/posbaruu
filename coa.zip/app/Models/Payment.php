<?php

namespace App\Models;

use App\Enums\PaymentStatus;
use App\Services\PaymentService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Payment extends BaseModel
{
    use SoftDeletes;

    public $table = 'payments';

    protected $fillable = [
        'user_id',
        'sales_order_id',
        'payment_type_id',
        'code',
        'amount',
        'status',
        'description',
    ];

    protected $casts = [
        'amount' => 'float',
        'status' => PaymentStatus::class,
    ];

    public static function booted(): void
    {
        // parent::boot();
        static::saving(function ($model) {
            if (empty($model->user_id))
                $model->user_id = auth()->user()?->id;
        });

        static::saved(function ($model) {
            PaymentService::refreshPayment($model);
        });

        static::deleting(function ($model) {
            if ($model->status->is(PaymentStatus::APPROVED)) {
                $salesOrder = $model->salesOrder;
                $salesOrder->total_paid -= $model->amount;
                $salesOrder->save();
            }
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function salesOrder(): BelongsTo
    {
        return $this->belongsTo(SalesOrder::class, 'sales_order_id', 'code');
    }

    public function paymentType(): BelongsTo
    {
        return $this->belongsTo(PaymentType::class);
    }

    public function scopeWhereAproved(Builder $query)
    {
        $query->where('status', PaymentStatus::APPROVED);
    }
}
