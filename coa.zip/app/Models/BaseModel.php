<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class BaseModel extends Model
{
    public static function boot()
    {
        parent::boot();
    }

    protected function serializeDate(DateTimeInterface $date): string
    {
        return $date->format('Y-m-d H:i');
    }

    public function scopeWhereLike(Builder $query, $column, $value)
    {
        $query->where($column, 'LIKE', '%'.$value.'%');
    }

    public function scopeOrWhereLike(Builder $query, $column, $value)
    {
        $query->orWhere($column, 'LIKE', '%'.$value.'%');
    }
}
