<?php

namespace App\Models;

class ProductBrand extends BaseModel
{
    public $table = 'product_brands';

    protected $guarded = [];
}
