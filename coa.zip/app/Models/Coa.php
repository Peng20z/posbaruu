<?php

namespace App\Models;

use App\Enums\NormalBalance;
use App\Traits\CustomSoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Coa extends BaseModel
{
    use CustomSoftDeletes;

    protected $fillable = [
        'parent_id',
        'account_number',
        'account_name',
        'normal_balance',
    ];

    protected $append = [
        'name',
    ];

    protected $casts = [
        'normal_balance' => NormalBalance::class
    ];

    public static function booted(): void
    {
        static::saving(function (self $model) {
            if (empty($model->normal_balance) && $model->parent) {
                $model->normal_balance = $model->parent->normal_balance;
            }
        });
    }

    public function getNameAttribute(): string
    {
        return $this->account_number . ' : ' . $this->account_name;
    }

    public function getSaldo($startDate = null, $endDate = null): int|float
    {
        $startDate = $startDate ? date('Y-m-d', strtotime($startDate)) : date('Y-m-d');
        $endDate = $endDate ? date('Y-m-d', strtotime($endDate)) : date('Y-m-d');

        if (empty($this->parent_id)) {
            $childIds = $this->childs()->get(['id'])->pluck('id');
            if ($this->normal_balance->is(NormalBalance::DEBIT)) {
                return JournalDetail::whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))
                    ->whereIn('coa_id', $childIds)->selectRaw('SUM(debit) - SUM(credit) as total_amount')->first()->total_amount ?? 0;
            } else {
                return JournalDetail::whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))
                    ->whereIn('coa_id', $childIds)->selectRaw('SUM(credit) - SUM(debit) as total_amount')->first()->total_amount ?? 0;
            }
        }

        if ($this->normal_balance->is(NormalBalance::DEBIT)) {
            return $this->journalDetails()->whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))->selectRaw('SUM(debit) - SUM(credit) as total_amount')->first()?->total_amount ?? 0;
            // return $this->journalDetails()->whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))->sum('debit') - $this->journalDetails()->whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))->sum('credit');
        } else {
            return $this->journalDetails()->whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))->selectRaw('SUM(credit) - SUM(debit) as total_amount')->first()?->total_amount ?? 0;
            // return $this->journalDetails()->whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))->sum('credit') - $this->journalDetails()->whereHas('journal', fn ($q) => $q->transactionDateRange($startDate, $endDate))->sum('debit');
        }
    }

    public static function getChildsSelections(array $parentIds = [], callable $closure = null)
    {
        $query = self::selectRaw('id, CONCAT(account_number," : ",account_name) as account_name')->whereNotNull('parent_id');

        if (!is_null($closure)) {
            $query = $closure($query);
        }

        if (count($parentIds) > 0) {
            $query->whereIn('parent_id', $parentIds);
        }

        // if ($tenantId) {
        //     $query->orWhere('tenant_id', $tenantId);
        // }

        return $query->pluck('account_name', 'id');
    }

    public function journalDetails(): HasMany
    {
        return $this->hasMany(JournalDetail::class);
    }

    public function childs(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id', 'id');
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id', 'id');
    }
}
