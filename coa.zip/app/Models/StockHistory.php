<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class StockHistory extends BaseModel
{
    public $table = 'stock_histories';

    protected $guarded = [];

    protected $casts = [
        'is_increment' => 'boolean'
    ];

    protected static function booted()
    {
        static::created(function (self $model) {
            if ($stock = $model->stock) {
                if ($model->is_increment) {
                    $stock->increment('qty', $model->qty);
                } else {
                    $stock->decrement('qty', $model->qty);
                }
            }
        });
    }

    public function model(): MorphTo
    {
        return $this->morphTo();
    }

    public function stock(): BelongsTo
    {
        return $this->belongsTo(Stock::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
