<?php

namespace App\Models;

class Uom extends BaseModel
{
    public $table = 'uoms';

    protected $guarded = [];

    public static function booted(): void
    {
        // static::created(function ($model) {

        //     $products = Product::get(['id']);
        //     foreach ($products as $product) {
        //         ProductUom::create([
        //             'product_id' => $product->id,
        //             'uom_id' => $model->id,
        //             'is_default' => false,
        //         ]);
        //     }
        // });
    }

    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_uoms')->withPivot('id', 'is_default', 'buy_price', 'sell_price', 'quantity');;
    }
}
