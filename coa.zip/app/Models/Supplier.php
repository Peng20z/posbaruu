<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Supplier extends BaseModel
{
    public $incrementing = false;
    protected $keyType = 'string';

    public $table = 'suppliers';
    protected $guarded = [];

    public function purchaseOrders(): HasMany
    {
        return $this->hasMany(PurchaseOrder::class);
    }

    public function scopeWhereIdNotIn(Builder $query, ...$ids)
    {
        if (gettype($ids) === 'string') {
            $ids = explode(',', $ids);
        }

        $query->whereNotIn('id', $ids);
    }

    public function scopeWhereNameLike(Builder $query, $search)
    {
        $query->where('code', 'like', '%' . $search . '%')
            ->orWhere('name', 'like', '%' . $search . '%')
            ->orWhere('email', 'like', '%' . $search . '%')
            ->orWhere('phone', 'like', '%' . $search . '%')
            ->orWhere('description', 'like', '%' . $search . '%')
            ->orWhere('address', 'like', '%' . $search . '%');
    }
}
