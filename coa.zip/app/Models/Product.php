<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Product extends BaseModel
{
    public $incrementing = false;
    protected $keyType = 'string';

    public $table = 'products';
    protected $guarded = [];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public static function booted(): void
    {
        // static::creating(function ($model) {
        //     if (empty($model->id))
        //         $model->id = now();
        // });

        static::created(function ($model) {
            //     $uoms = Uom::all();
            //     foreach ($uoms as $uom) {
            //         ProductUom::create([
            //             'product_id' => $model->id,
            //             'uom_id' => $uom->id,
            //             'is_default' => ($model->uom_id == $uom->id) ? true : false,
            //         ]);
            //     }
            $model->stock()->create();
        });
    }

    protected function buyPrice(): Attribute
    {
        return Attribute::make(
            set: fn (string $value) => filterPrice($value),
        );
    }

    protected function sellPrice(): Attribute
    {
        return Attribute::make(
            set: fn (string $value) => filterPrice($value),
        );
    }

    public function productBrand()
    {
        return $this->belongsTo(ProductBrand::class);
    }

    public function productCategory()
    {
        return $this->belongsTo(ProductCategory::class);
    }

    public function uoms()
    {
        return $this->belongsToMany(Uom::class, 'product_uoms')->using(ProductUom::class)->withPivot('id', 'is_base', 'is_default', 'buy_price', 'sell_price', 'quantity', 'discounts');
    }

    public function baseUom()
    {
        return $this->belongsTo(Uom::class, 'base_uom_id');
    }

    public function defaultUom()
    {
        return $this->belongsTo(Uom::class, 'default_uom_id');
    }

    public function stock(): HasOne
    {
        return $this->hasOne(Stock::class);
    }

    public function salesOrderDetails(): HasMany
    {
        return $this->hasMany(SalesOrderDetail::class);
    }

    public function purchaseOrderDetails(): HasMany
    {
        return $this->hasMany(PurchaseOrderDetail::class);
    }

    public function scopeIsActive(Builder $query)
    {
        return $query->where('is_active', 1);
    }

    public function scopeWhereIdNotIn(Builder $query, ...$ids)
    {
        if (gettype($ids) === 'string') {
            $ids = explode(',', $ids);
        }

        $query->whereNotIn('id', $ids);
    }

    public function scopeWhereNameLike(Builder $query, $search)
    {
        $query->where('id', 'like', '%' . $search . '%')
            ->orWhere('name', 'like', '%' . $search . '%')
            ->orWhere('description', 'like', '%' . $search . '%');
    }

    /**
     * Find a model by its id.
     *
     * @param  mixed  $id
     * @param  array|string  $columns
     * @return \Illuminate\Database\Eloquent\Model|\Illuminate\Database\Eloquent\Collection|static[]|static|null
     */
    public static function findByid($id, $columns = ['*'])
    {
        return self::where('id', $id)->first($columns);
    }
}
