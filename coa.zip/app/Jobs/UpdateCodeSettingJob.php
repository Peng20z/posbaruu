<?php

namespace App\Jobs;

use App\Enums\DatabaseConnection;
use App\Enums\SettingKey;
use App\Models\Setting;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class UpdateCodeSettingJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
            $databaseConnection = DatabaseConnection::coerce('mysql');
            $so = sprintf($databaseConnection->getSoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $ro = sprintf($databaseConnection->getRoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $po = sprintf($databaseConnection->getPoCodeFormat() . '001', date('d'), date('m'), date('y'));

            $key = SettingKey::PO_NUMBER();
            DB::connection('mysql')->table('settings')
            ->where('key', $key)
            ->update(['value' => $po]);

            $key = SettingKey::SO_NUMBER();
            DB::connection('mysql')->table('settings')
            ->where('key', $key)
            ->update(['value' => $so]);

            $key = SettingKey::RO_NUMBER();
            DB::connection('mysql')->table('settings')
            ->where('key', $key)
            ->update(['value' => $ro]);

            $databaseConnection = DatabaseConnection::coerce('mysql_secondary');
            $so = sprintf($databaseConnection->getSoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $ro = sprintf($databaseConnection->getRoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $po = sprintf($databaseConnection->getPoCodeFormat() . '001', date('d'), date('m'), date('y'));

            $key = SettingKey::PO_NUMBER();
            DB::connection('mysql_secondary')->table('settings')
            ->where('key', $key)
            ->update(['value' => $po]);

            $key = SettingKey::SO_NUMBER();
            DB::connection('mysql_secondary')->table('settings')
            ->where('key', $key)
            ->update(['value' => $so]);

            $key = SettingKey::RO_NUMBER();
            DB::connection('mysql_secondary')->table('settings')
            ->where('key', $key)
            ->update(['value' => $ro]);
    }
}
