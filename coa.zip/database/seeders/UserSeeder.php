<?php

namespace Database\Seeders;

use App\Enums\UserType;
use App\Models\CustomerGroup;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $adminRole = Role::create([
            'id' => 1,
            'name' => 'admin',
        ]);

        // $customerRole = Role::create([
        //     'id' => 2,
        //     'name' => 'customer',
        // ]);

        $admin = User::create([
            'code' => 'ADM000',
            'name' => 'Admin',
            'email' => 'admin@gmail.com',
            'password' => bcrypt('12345678'),
            'type' => UserType::USER,
        ]);

        $admin->assignRole($adminRole);
        // $customer->assignRole($customerRole);
    }
}
