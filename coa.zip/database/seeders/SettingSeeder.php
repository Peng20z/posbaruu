<?php

namespace Database\Seeders;

use App\Enums\DatabaseConnection;
use App\Enums\SettingKey;
use App\Models\Coa;
use App\Models\Setting;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $databaseConnection = DatabaseConnection::MYSQL();
        $poFormat = sprintf($databaseConnection->getPoCodeFormat() . '001', date('d'), date('m'), date('y'));
        $roFormat = sprintf($databaseConnection->getRoCodeFormat() . '001', date('d'), date('m'), date('y'));
        $soFormat = sprintf($databaseConnection->getSoCodeFormat() . '001', date('d'), date('m'), date('y'));

        if (DB::getDefaultConnection() === DatabaseConnection::MYSQL_SECONDARY) {
            $databaseConnection = DatabaseConnection::MYSQL_SECONDARY();
            $poFormat = sprintf($databaseConnection->getPoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $roFormat = sprintf($databaseConnection->getRoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $soFormat = sprintf($databaseConnection->getSoCodeFormat() . '001', date('d'), date('m'), date('y'));
        }

        Setting::create([
            'key' => SettingKey::PO_NUMBER,
            'value' => $poFormat
        ]);

        Setting::create([
            'key' => SettingKey::RO_NUMBER,
            'value' => $roFormat
        ]);

        Setting::create([
            'key' => SettingKey::SO_NUMBER,
            'value' => $soFormat
        ]);

        Setting::create([
            'key' => SettingKey::TAX_VALUE,
            'value' => 11
        ]);

        Setting::create([
            'key' => SettingKey::IS_SKIP_RO,
            'value' => false
        ]);

        Setting::create([
            'key' => SettingKey::STOCK_LESS_THAN_0,
            'value' => false
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_PERSEDIAAN,
            'value' => Coa::where('account_number', '1200')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_PERSEDIAAN_REVERSE,
            'value' => Coa::where('account_number', '1200')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_PENJUALAN,
            'value' => Coa::where('account_number', '4000.01')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_PENJUALAN_REVERSE,
            'value' => Coa::where('account_number', '1000')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_RETUR_PENJUALAN,
            'value' => Coa::where('account_number', '4000.03')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_RETUR_PENJUALAN_REVERSE,
            'value' => Coa::where('account_number', '4000.03')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_DISKON_BARANG,
            'value' => Coa::where('account_number', '4000.04')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_DISKON_BARANG_REVERSE,
            'value' => Coa::where('account_number', '4000.04')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_BARANG_TERKIRIM,
            'value' => Coa::where('account_number', '1201')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_BARANG_TERKIRIM_REVERSE,
            'value' => Coa::where('account_number', '1201')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_HPP,
            'value' => Coa::where('account_number', '5000')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_HPP_REVERSE,
            'value' => Coa::where('account_number', '5000')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_RETUR_PEMBELIAN,
            'value' => Coa::where('account_number', '1200')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_RETUR_PEMBELIAN_REVERSE,
            'value' => Coa::where('account_number', '1200')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_BEBAN,
            'value' => Coa::where('account_number', '6203.12')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_BEBAN_REVERSE,
            'value' => Coa::where('account_number', '1000')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_BELUM_TERTAGIH,
            'value' => Coa::where('account_number', '2200')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_BELUM_TERTAGIH_REVERSE,
            'value' => Coa::where('account_number', '2200')->first(['id'])?->id ?? null
        ]);

        Setting::create([
            'key' => SettingKey::AKUN_PEMBELIAN,
            'value' => Coa::where('account_number', '1000')->first(['id'])?->id ?? null
        ]);
        Setting::create([
            'key' => SettingKey::AKUN_PEMBELIAN_REVERSE,
            'value' => Coa::where('account_number', '1000')->first(['id'])?->id ?? null
        ]);
    }
}
