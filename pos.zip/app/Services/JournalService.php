<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Http\Requests\Journal\StoreRequest;
use App\Models\Journal;
use Illuminate\Support\Facades\DB;

class JournalService
{
    public static function store(StoreRequest $request): void
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $journal = Journal::on($db->value)->create($request->validated());
                $journal->details()->createMany($request->details);
            }
        });
    }

    public static function update(StoreRequest $request, int $id): void
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $journal = Journal::on($db->value)->findOrFail($id);
                $journal->details()->delete();
                $journal->details()->createMany($request->details);
            }
        });
    }

    public static function destroy(int $id): void
    {
        DB::transaction(function () use ($id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $journal = Journal::on($db->value)->find($id);
                $journal->delete();
            }
        });
    }
}
