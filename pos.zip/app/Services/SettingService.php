<?php

namespace App\Services;

use App\Enums\SettingEnum;
use App\Models\Setting;

class SettingService
{
    /**
     * @param SettingEnum|string $key
     * @return mixed
     */
    public static function getCurrentValue(SettingEnum|string $key) : mixed
    {
        if ($key instanceof SettingEnum) {
            $key = $key->value;
        }

        return Setting::firstWhere('key', $key)?->value ?? "";
    }
}
