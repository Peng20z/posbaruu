<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Http\Requests\ProductUomStoreRequest;
use App\Http\Requests\ProductUomUpdateRequest;
use App\Models\CustomerGroup;
use App\Models\CustomerGroupProduct;
use App\Models\Product;
use App\Models\ProductUom;
use Illuminate\Support\Facades\DB;

class ProductUomService
{
    public static function update(ProductUomUpdateRequest $request, Product $product, $id): void
    {
        DB::transaction(function () use ($request, $id, $product) {
            if ($request->update_db == false) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    if ($request->is_default == true) {
                        ProductUom::on($db->value)
                            ->where('product_id', $product->id)
                            ->update(['is_default' => false]);
                    }
                    $productUom = ProductUom::on($db->value)->where('product_id', $product->id)->where('uom_id', $request->old_uom_id)->first();
                    if ($productUom) {
                        $productUom->update([
                            'uom_id' => $request->uom_id,
                            'buy_price' => $request->buy_price,
                            'sell_price' => $request->sell_price,
                            'quantity' => $request->quantity,
                            'discounts' => $request->discounts,
                            'is_default' => $request->is_default ? 1 : 0,
                        ]);

                        if ($productUom->is_default) {
                            Product::on($db->value)->where('id', $product->id)->update(['default_uom_id' => $productUom->uom_id,'buy_price' => $productUom->buy_price ?? 0, 'sell_price' => $productUom->sell_price ?? 0]);
                        }
                        if ($productUom->is_base) {
                            Product::on($db->value)->where('id', $product->id)->update(['base_uom_id' => $productUom->uom_id]);
                        }
                    }
                }
            } else {
                if ($request->is_default == true) {
                    ProductUom::where('product_id', $product->id)->update(['is_default' => false]);
                }
                $productUom = ProductUom::where('product_id', $product->id)->where('uom_id', $request->uom)->first();
                $productUom->update($request->all());

                if ($productUom->is_default == true) {
                    Product::where('id', $productUom->product_id)->update(['buy_price' => $productUom->buy_price ?? 0, 'sell_price' => $productUom->sell_price ?? 0]);
                }
            }
        });
    }

    public static function generateDiscountsData(float $price, array $discounts = []): array|null
    {
        if (count($discounts) <= 0)
            return null;
        $data = [];

        if ($discounts['qty']['0'] != '0') {
            foreach ($discounts['is_percentage'] as $key => $value) {
                if ($value == 1) {
                    $data[$discounts['qty'][$key]] = $price * (float) $discounts['price'][$key] / 100;
                } else {
                    $data[$discounts['qty'][$key]] = (float) $discounts['price'][$key];
                }
            }
        } else {
            foreach ($discounts['qty'] as $key => $value) {
                $data[$discounts['qty'][$key]] = (float) $discounts['price'][$key];
            }
        }
        return $data;
    }

    public static function store(ProductUomStoreRequest $request, Product $product): void
    {
        $discounts = self::generateDiscountsData($request->sell_price, $request->discounts);

        DB::transaction(function () use ($request, $product, $discounts) {
            $isDefault = boolval($request->is_default) ?? false;
            foreach (DatabaseConnection::getInstances() as $db) {
                if ($isDefault === true) {
                    ProductUom::on($db->value)->where('product_id', $product->id)->update(['is_default' => false]);
                    $product->update([
                        'buy_price' => $request->buy_price,
                        'sell_price' => $request->sell_price,
                        'default_uom_id' => $request->uom_id,
                    ]);
                }

                $data = $request->validated();
                if (isset($data['discounts'])) unset($data['discounts']);

                ProductUom::on($db->value)->create([
                    ...$data,
                    'product_id' => $product->id,
                    'is_default' => $isDefault,
                    'discounts' => $discounts,
                    'is_base' => $request->is_base ? 1 : 0,
                ]);

                foreach (CustomerGroup::get() as $customerGroup) {
                    CustomerGroupProduct::on($db->value)->create([
                        'customer_group_id' => $customerGroup->id,
                        'product_id' => $product->id,
                        'uom_id' => $data['uom_id'],
                        'sell_price' => $data['sell_price']
                    ]);
                }
            }
        });
    }
}
