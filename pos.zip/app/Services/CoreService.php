<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Cookie;

class CoreService
{
    public static function setConnection(): void
    {
        if (self::getCookieDbConnection() == DatabaseConnection::MYSQL_SECONDARY) {
            $mainConfig = config('database.connections.mysql_secondary');
            $secondaryConfig = config('database.connections.mysql');
        } else {
            $mainConfig = config('database.connections.mysql');
            $secondaryConfig = config('database.connections.mysql_secondary');
        }

        Config::set('database.connections.mysql', $mainConfig);
        Config::set('database.connections.mysql_secondary', $secondaryConfig);
    }

    public static function getCookieDbConnection(): string
    {
        $dbConnectionCookie = config('core.db_connection_cookie', 'db_connection');

        $dbConnection = request()->cookie($dbConnectionCookie);
        if (!empty($dbConnection) && in_array($dbConnection, [DatabaseConnection::MYSQL, DatabaseConnection::MYSQL_SECONDARY])) {
            return $dbConnection;
        }

        Cookie::queue($dbConnectionCookie, DatabaseConnection::MYSQL, 60);
        return DatabaseConnection::MYSQL;
    }

    public static function resetCookieDbConnection(): void
    {
        Cookie::queue(config('core.db_connection_cookie', 'db_connection'), DatabaseConnection::MYSQL);
    }

    public static function setCookieDbConnection(DatabaseConnection|string $databaseConnection): void
    {
        $dbConnectionCookie = config('core.db_connection_cookie', 'db_connection');
        if ($databaseConnection instanceof DatabaseConnection) {
            Cookie::queue($dbConnectionCookie, $databaseConnection->value);
        }

        if (gettype($databaseConnection) === 'string' && in_array($databaseConnection, [DatabaseConnection::MYSQL, DatabaseConnection::MYSQL_SECONDARY])) {
            Cookie::queue($dbConnectionCookie, $databaseConnection);
        }
    }

    public static function hasAdminCookie(): bool
    {
        if (isset($_COOKIE['super_admin']) && $_COOKIE['super_admin'] == 'yes')
            return true;
        return false;
    }
}
