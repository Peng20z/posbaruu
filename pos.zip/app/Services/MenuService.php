<?php

namespace App\Services;

use App\Classes\Menu;
use App\Classes\Submenu;

class MenuService
{
    public static function menu(): array
    {
        return [
            self::userMenu(),
            self::customerMenu(),
            self::masterMenu(),
            self::supplierMenu(),
            self::purchaseOrderMenu(),
            self::receiveOrderMenu(),
            self::salesOrderMenu(),
            self::salesReturnMenu(),
            self::stockMenu(),
            self::paymentMenu(),
            self::reportMenu(),
            self::journalMenu(),
            self::coaMenu(),
            self::settingMenu(),
        ];
    }

    protected static function userMenu()
    {
        $users = new Submenu('users_access', 'users', 'fa fa-users', 'Users');
        $roles = new Submenu('roles_access', 'roles', 'fa fa-users', 'Roles');
        // $permissions = new Submenu('permissions_access', 'permissions', 'fa fa-users', 'Permissions');

        return new Menu('user_management_access', 'fa fa-users', 'User', true, ...[$users, $roles]);
    }

    protected static function customerMenu()
    {
        $customers = new Submenu('customers_access', 'customers', 'fa fa-users', 'Customers');
        $customerGroups = new Submenu('customer_groups_access', 'customer-groups', 'fa fa-users', 'Customer Groups');

        return new Menu('customer_management_access', 'fa fa-users', 'Customer', true, ...[$customers, $customerGroups]);
    }

    protected static function masterMenu()
    {
        $product = new Submenu('products_access', 'products', 'fa fa-building', 'Products');
        $productBrand = new Submenu('product_brands_access', 'product-brands', 'fa fa-store', 'Product Brand');
        $productCategory = new Submenu('product_categories_access', 'product-categories', 'fa fa-store', 'Product Category');
        $uom = new Submenu('uoms_access', 'uoms', 'fa fa-store', 'Uom');
        $productPriceList = new Submenu('product_price_list_access', 'products/price-list', 'fa fa-building', 'Product Price List');

        return new Menu('product_management_access', 'fa fa-building', 'Product', true, ...[$product, $productBrand, $productCategory, $uom, $productPriceList]);
    }

    // protected static function salesInvoiceMenu()
    // {
    //     $salesInvoices = new Submenu('sales_invoices_access', 'sales-invoices', 'fa fa-file', 'List');
    //     $addSalesInvoices = new Submenu('sales_invoice_create', 'sales-invoices/create', 'fa fa-file', 'Add');

    //     return new Menu('sales_invoices_access', 'SI', 'Sales Invoices', false, ...[$salesInvoices, $addSalesInvoices]);
    // }

    protected static function purchaseOrderMenu()
    {
        $purchaseOrder = new Submenu('purchase_orders_access', 'purchase-orders', 'fa fa-book', 'Purchase Order');

        return new Menu('purchase_orders_access', 'fa fa-book', 'Purchase Order', true, ...[$purchaseOrder]);
    }

    protected static function salesOrderMenu()
    {
        $salesOrder = new Submenu('sales_orders_access', 'sales-orders', 'fa fa-book', 'Sales Order');

        return new Menu('sales_orders_access', 'fa fa-book', 'Sales Order', true, ...[$salesOrder]);
    }

    protected static function salesReturnMenu()
    {
        $salesReturn = new Submenu('sales_returns_access', 'sales-returns', 'fa fa-book', 'Sales Return');

        return new Menu('sales_returns_access', 'fa fa-book', 'Sales Return', true, ...[$salesReturn]);
    }

    protected static function receiveOrderMenu()
    {
        $receiveOrder = new Submenu('receive_orders_access', 'receive-orders', 'fa fa-book', 'Receive Order');

        return new Menu('receive_orders_access', 'fa fa-book', 'Receive Order', true, ...[$receiveOrder]);
    }

    protected static function supplierMenu()
    {
        $supplier = new Submenu('suppliers_access', 'suppliers', 'fa fa-users', 'Supplier');

        return new Menu('suppliers_access', 'fa fa-users', 'Supplier', true, ...[$supplier]);
    }

    protected static function stockMenu()
    {
        $stock = new Submenu('stocks_access', 'stocks', 'fa fa-warehouse', 'Stock & Adjustment');

        return new Menu('stocks_access', 'fa fa-warehouse', 'Stock', true, ...[$stock]);
    }

    protected static function paymentMenu()
    {
        $purchaseInvoice = new Submenu('purchase_invoices_access', 'purchase-invoices', 'fa fa-credit-card', 'Purchase Invoice');
        $salesInvoice = new Submenu('sales_invoices_access', 'payments', 'fa fa-credit-card', 'Sales Invoice');
        $paymentType = new Submenu('payment_types_access', 'payment-types', 'fa fa-credit-card', 'Payment Type');

        return new Menu('payments_managements_access', 'fa fa-credit-card', 'Invoice', true, ...[$purchaseInvoice, $salesInvoice, $paymentType]);
    }

    protected static function reportMenu()
    {
        $reportSalesOrder = new Submenu('reports_sales_order', 'reports/sales-orders', 'fa fa-file', 'Sales Order');
        $reportPurchaseOrder = new Submenu('reports_purchase_order', 'reports/purchase-orders', 'fa fa-file', 'Purchase Order');

        return new Menu('reports_access', 'fa fa-file', 'Report', true, ...[$reportSalesOrder, $reportPurchaseOrder]);
    }

    protected static function journalMenu()
    {
        $journal = new Submenu('journal_access', 'journals', 'fa fa-newspaper', 'Journal');
        $listJournal = new Submenu('journal_access', 'list-journals', 'fa fa-newspaper', 'All');

        return new Menu('journal_access', 'fa fa-newspaper', 'Journal', true, ...[$journal, $listJournal]);
    }

    protected static function coaMenu()
    {
        $coa = new Submenu('coa_access', 'coa', 'fa fa-tag', 'COA');

        return new Menu('coa_access', 'fa fa-tag', 'COA', true, ...[$coa]);
    }

    protected static function settingMenu()
    {
        $setting = new Submenu('settings_access', 'settings', 'fa fa-cog', 'Setting');

        return new Menu('settings_access', 'fa fa-cog', 'setting', true, ...[$setting]);
    }
}
