<?php

namespace App\Services;

use App\Enums\PaymentStatus;
use App\Models\PurchaseInvoice;

class PurchaseInvoiceService
{
    public static function refreshPayment(PurchaseInvoice $purchaseInvoice): void
    {
        $purchaseOrder = $purchaseInvoice->purchaseOrder;
        if ($purchaseOrder) {
            if ($purchaseInvoice->wasChanged('status')) {
                if ($purchaseInvoice->getOriginal('status')->in([PaymentStatus::PENDING(), PaymentStatus::REJECTED()]) && $purchaseInvoice->status->is(PaymentStatus::APPROVED())) {
                    $purchaseInvoice->purchaseOrder->increment('total_paid', $purchaseInvoice->amount);
                } elseif ($purchaseInvoice->getOriginal('status')->is(PaymentStatus::APPROVED())) {
                    // $purchaseOrder->update(['total_paid' => $purchaseOrder->payments()->whereAproved()->sum('amount') ?? 0]);
                    $purchaseOrder->total_paid = $purchaseOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    $purchaseOrder->save();
                }

                return;
            } elseif ($purchaseInvoice->wasChanged('amount')) {
                if ($purchaseInvoice->status->is(PaymentStatus::APPROVED())) {

                    // if ($purchaseOrder->total_paid == $purchaseOrder->total_price) {
                    //     return;
                    // }

                    $totalPayment = $purchaseOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    if ($purchaseOrder->total_paid == $purchaseOrder->total_price && $totalPayment >= $purchaseOrder->total_price) {
                        $purchaseInvoice->amount = $purchaseInvoice->getOriginal('amount') - ($totalPayment - $purchaseOrder->total_paid);
                        // $payment->amount = 6000;
                        $purchaseInvoice->saveQuietly();
                        // $payment->update(['amount' =>  $payment->amount]);
                        return;
                    }
                    elseif ($totalPayment > $purchaseOrder->total_price) {
                        $purchaseInvoice->amount = $purchaseInvoice->amount - ($totalPayment - $purchaseOrder->total_price);
                        $purchaseInvoice->saveQuietly();

                        $purchaseOrder->total_paid = $purchaseOrder->total_price;
                        $purchaseOrder->saveQuietly();
                    } else {
                        $purchaseOrder->total_paid = $totalPayment;
                        $purchaseOrder->save();
                    }
                }
            } else {
                if ($purchaseInvoice->status->is(PaymentStatus::APPROVED()) && $purchaseOrder->total_paid <= $purchaseOrder->total_price) {
                    if ($purchaseInvoice->amount + $purchaseOrder->total_paid > $purchaseOrder->total_price) {
                        $purchaseInvoice->amount = $purchaseOrder->total_price - $purchaseOrder->total_paid;
                        $purchaseInvoice->saveQuietly();

                        $purchaseInvoice->purchaseOrder->increment('total_paid', $purchaseOrder->total_price - $purchaseOrder->total_paid);
                    } else {
                        $purchaseInvoice->purchaseOrder->increment('total_paid', $purchaseInvoice->amount);
                    }
                } else {
                    // $payment->delete();
                }

                return;
            }
        }
    }
}
