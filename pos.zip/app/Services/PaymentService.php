<?php

namespace App\Services;

use App\Enums\PaymentStatus;
use App\Models\Payment;

class PaymentService
{
    public static function refreshPayment(Payment $payment): void
    {
        $salesOrder = $payment->salesOrder;
        if ($salesOrder) {
            if ($payment->wasChanged('status')) {
                if ($payment->getOriginal('status')->in([PaymentStatus::PENDING(), PaymentStatus::REJECTED()]) && $payment->status->is(PaymentStatus::APPROVED())) {
                    $payment->salesOrder->increment('total_paid', $payment->amount);
                } elseif ($payment->getOriginal('status')->is(PaymentStatus::APPROVED())) {
                    // $salesOrder->update(['total_paid' => $salesOrder->payments()->whereAproved()->sum('amount') ?? 0]);
                    $salesOrder->total_paid = $salesOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    $salesOrder->save();
                }

                return;
            } elseif ($payment->wasChanged('amount')) {
                if ($payment->status->is(PaymentStatus::APPROVED())) {

                    // if ($salesOrder->total_paid == $salesOrder->total_price) {
                    //     return;
                    // }

                    $totalPayment = $salesOrder->payments()->whereAproved()->sum('amount') ?? 0;
                    if ($salesOrder->total_paid == $salesOrder->total_price && $totalPayment >= $salesOrder->total_price) {
                        $payment->amount = $payment->getOriginal('amount') - ($totalPayment - $salesOrder->total_paid);
                        // $payment->amount = 6000;
                        $payment->saveQuietly();
                        // $payment->update(['amount' =>  $payment->amount]);
                        return;
                    }
                    elseif ($totalPayment > $salesOrder->total_price) {
                        $payment->amount = $payment->amount - ($totalPayment - $salesOrder->total_price);
                        $payment->saveQuietly();

                        $salesOrder->total_paid = $salesOrder->total_price;
                        $salesOrder->saveQuietly();
                    } else {
                        $salesOrder->total_paid = $totalPayment;
                        $salesOrder->save();
                    }
                }
            } else {
                if ($payment->status->is(PaymentStatus::APPROVED()) && $salesOrder->total_paid <= $salesOrder->total_price) {
                    if ($payment->amount + $salesOrder->total_paid > $salesOrder->total_price) {
                        $payment->amount = $salesOrder->total_price - $salesOrder->total_paid;
                        $payment->saveQuietly();

                        $payment->salesOrder->increment('total_paid', $salesOrder->total_price - $salesOrder->total_paid);
                    } else {
                        $payment->salesOrder->increment('total_paid', $payment->amount);
                    }
                } else {
                    // $payment->delete();
                }

                return;
            }
        }
    }
}
