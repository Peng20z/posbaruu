<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Enums\SettingEnum;
use App\Http\Requests\PurchaseOrderStoreRequest;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderDetail;
use App\Models\Setting;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PurchaseOrderService
{
    public static function getCode(string $dbConnection = null): string
    {
        if (empty($dbConnection)) $dbConnection = CoreService::getCookieDbConnection();

        $key = SettingEnum::PO_NUMBER;
        $databaseConnection = DatabaseConnection::coerce(CoreService::getCookieDbConnection());
        $prefix = $databaseConnection->getPoCodeFormat();
        $lastPoNumber = DB::connection($dbConnection)->transaction(function () use ($key, $prefix, $dbConnection) {
            // Get current value to use. We use lock for update
            // to prevent other thread to read this row until we update it

            $lastPoNumber = DB::connection('mysql')->table('settings')
                ->where('key', $key)
                ->lockForUpdate()
                ->first('value')?->value ?? null;
            if (isset($lastPoNumber) && !is_null($lastPoNumber) && $lastPoNumber != '') {
                $arrayLastPoNumber = explode('/', $lastPoNumber);

                if (is_array($arrayLastPoNumber) && count($arrayLastPoNumber) == 6 && date('d') == $arrayLastPoNumber[1]) {
                    $arrayLastPoNumber[5] = sprintf('%02d', (int) $arrayLastPoNumber[5] + 1);
                    $arrayLastPoNumber[5] = substr("00{$arrayLastPoNumber[5]}", -3);
                    $nextLastPoNumber = implode('/', $arrayLastPoNumber);
                } else {
                    $lastPoNumber = sprintf($prefix . '001', date('d'), date('m'), date('y'));
                    $nextLastPoNumber = sprintf($prefix . '002', date('d'), date('m'), date('y'));
                }
            } else {
                $lastPoNumber = sprintf($prefix . '001', date('d'), date('m'), date('y'));
                $nextLastPoNumber = sprintf($prefix . '002', date('d'), date('m'), date('y'));
            }

            // update the value with $nextLastPoNumber
            DB::connection($dbConnection)->table('settings')
                ->where('key', $key)
                ->update(['value' => $nextLastPoNumber]);
            return $lastPoNumber;
        });

        return $lastPoNumber;
    }

    public static function store(PurchaseOrderStoreRequest $request)
    {
        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL;
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY;

        DB::transaction(function () use ($request, $dbConnection, $mysql, $mysqlSecondary) {

            if ($dbConnection === $mysql) {
                $purchaseOrder = self::storePO($mysql, $request);
                self::storePO($mysqlSecondary, $request, $purchaseOrder->code);
            } else {
                self::storePO($mysql, $request);
            }
        });
    }

    public static function storePO(string $dbConnection, Request $request, string $code = null, ?PurchaseOrder $purchaseOrder = null): PurchaseOrder
    {
        $data = $request->validated();
        $data['additional_discount'] = $data['additional_discount'] ? $data['additional_discount'] : 0;
        if (!$purchaseOrder) {
            similar_text($request->code, SettingService::getCurrentValue(SettingEnum::PO_NUMBER), $percent);
            if ($percent == 100) {
                $request->code = PurchaseOrderService::getCode('mysql');
            }

            $data['code'] = $request->code;
            // if code null, generate code on model booted::created()
            // dd($data);
            $purchaseOrder = PurchaseOrder::on($dbConnection)->create($data);
        } else {
            $purchaseOrder->update($data);
        }

        foreach ($request->items as $item) {
            // $product = Product::with(['uoms' => fn ($q) => $q->where('uom_id', $item['uom_id'])])->findOrFail($item['product_id']);
            // $productUom = $product->uoms[0];
            $originalTotalPrice = ($item['unit_price'] - ($item['discount'] / 100 * $item['unit_price'])) * $item['qty'];
            $tax = isset($item['ppn']) ? self::getTaxPrice($originalTotalPrice) : 0;
            $totalPrice = $originalTotalPrice + $tax;

            $detail = $purchaseOrder->details()->create([
                'product_id' => $item['product_id'],
                'uom_id' => $item['uom_id'],
                'qty' => $item['qty'],
                'tax' => $tax,
                'unit_price' =>  $item['unit_price'],
                'discount' => $item['discount'] ?? 0,
                'total_price' => $totalPrice,
            ]);

            if ($dbConnection === DatabaseConnection::MYSQL) {
                self::createHistory($detail);
            }
        }

        $purchaseOrder->update([
            'total_price' => $purchaseOrder->details->sum('total_price') - ($purchaseOrder->additional_discount / 100 * $purchaseOrder->details->sum('total_price'))
        ]);

        return $purchaseOrder;
    }

    public static function update(Request $request, PurchaseOrder $purchaseOrder)
    {
        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL;
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY;

        DB::transaction(function () use ($request, $dbConnection, $mysql, $mysqlSecondary, $purchaseOrder) {

            self::deletePODetail(PurchaseOrderDetail::whereHas('purchaseOrder', fn ($q) => $q->where('code', $purchaseOrder->code))->first());
            // self::deletePODetail(PurchaseOrderDetail::on($mysqlSecondary)->whereHas('purchaseOrder', fn ($q) => $q->where('code', $purchaseOrder->code))->first());

            if ($dbConnection === $mysql) {
                $purchaseOrder = self::storePO(dbConnection: $mysql, request: $request, purchaseOrder: $purchaseOrder);

                $purchaseOrder2 = PurchaseOrder::on($mysqlSecondary)->where('code', $purchaseOrder->code)->first();
                self::storePO($mysqlSecondary, $request, $purchaseOrder->code, $purchaseOrder2);
            } else {
                self::storePO(dbConnection: $mysql, request: $request, purchaseOrder: $purchaseOrder);
            }
        });
    }

    // public static function recalculateCapital(PurchaseOrderDetail $detail)
    // {
    //     $product = Product::where('id', $detail->product_id)->first();

    //     $prevQty = $product->bought_qty ?? 0;
    //     $prevCapital = $product->capital_price ?? 0;

    //     $totalPrice = $prevQty * $prevCapital + $detail->total_price;
    //     $totalQty = $prevQty + $detail->qty;

    //     $product->bought_qty = $totalQty;
    //     $product->capital_price = $totalPrice / $totalQty;
    //     $product->save();
    // }

    public static function deletePODetail($detail)
    {
        Stock::where('product_id', $detail->product_id)->decrement('qty', $detail->stockHistory->qty ?? 0);
        $detail->stockHistory?->delete();
        $detail->delete();
    }

    public static function createHistory(PurchaseOrderDetail $detail)
    {
        $qty = $detail->product?->uoms()->where('uom_id', $detail->uom_id)->first(['quantity'])?->quantity;
        $detail->stockHistory()->create([
            'user_id' => Auth::user()->id,
            'stock_id' => $detail->product?->stock->id,
            'is_increment' => true,
            'qty' => $detail->qty * $qty,
            'description' => 'Purchase from ' . $detail->purchaseOrder->supplier->name
        ]);
    }

    public static function recalculateCapital(Product $product)
    {
        if (CoreService::getCookieDbConnection() == 'mysql') {
            $purchaseOrderDetails = PurchaseOrderDetail::where('product_id', $product->id)->get();
        } else {
            $purchaseOrderDetails = PurchaseOrderDetail::where('product_id', $product->id)->whereHas('purchaseOrder', fn ($q) => $q->where('code', 'like', '%BB%'))->get();
        }

        if (count($purchaseOrderDetails) > 0) {
            $totalQty = 0;
            foreach ($purchaseOrderDetails as $detail) {
                $totalQty += $detail->qty * ProductUom::where('product_id', $detail->product_id)->where('uom_id', $detail->uom_id)->first('quantity')->quantity;
            }

            $product->capital_price = $purchaseOrderDetails->sum('total_price') / $totalQty;
            $product->save();
        } else {
            $product->capital_price = 0;
            $product->save();
        }

        return back()->withInput();
    }

    public static function getTaxPrice(int|float $price): int|float
    {
        $tax = Setting::where('key', SettingEnum::TAX_VALUE)->first(['value'])?->value ?? 0;

        return $price * $tax / 100;
    }
}
