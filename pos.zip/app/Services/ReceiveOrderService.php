<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Enums\POStatus;
use App\Enums\SettingEnum;
use App\Http\Requests\ReceiveOrderStoreRequest;
use App\Models\PurchaseOrder;
use App\Models\ReceiveOrder;
use App\Models\ReceiveOrderDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReceiveOrderService
{
    public static function getCode(string $dbConnection = null): string
    {
        if (empty($dbConnection))
            $dbConnection = CoreService::getCookieDbConnection();

        $key = SettingEnum::RO_NUMBER;
        $databaseConnection = DatabaseConnection::coerce($dbConnection);
        $prefix = $databaseConnection->getRoCodeFormat();

        $lastRoNumber = DB::connection($dbConnection)->transaction(function () use ($key, $prefix, $dbConnection) {
            // Get current value to use. We use lock for update
            // to prevent other thread to read this row until we update it
            $lastRoNumber = DB::connection($dbConnection)->table('settings')
                ->where('key', $key)
                ->lockForUpdate()
                ->first('value')?->value ?? null;

            if (isset($lastRoNumber) && !is_null($lastRoNumber) && $lastRoNumber != '') {
                $arrayLastRoNumber = explode('/', $lastRoNumber);

                if (is_array($arrayLastRoNumber) && count($arrayLastRoNumber) == 6 && date('d') == $arrayLastRoNumber[1]) {
                    $arrayLastRoNumber[5] = sprintf('%02d', (int) $arrayLastRoNumber[5] + 1);
                    $arrayLastRoNumber[5] = substr("00{$arrayLastRoNumber[5]}", -3);
                    $nextLastRoNumber = implode('/', $arrayLastRoNumber);
                } else {
                    $lastRoNumber = sprintf($prefix . '001', date('d'), date('m'), date('y'));
                    $nextLastRoNumber = sprintf($prefix . '002', date('d'), date('m'), date('y'));
                }
            } else {
                $lastRoNumber = sprintf($prefix . '001', date('d'), date('m'), date('y'));
                $nextLastRoNumber = sprintf($prefix . '002', date('d'), date('m'), date('y'));
            }

            // update the value with $nextLastRoNumber
            DB::connection($dbConnection)->table('settings')
                ->where('key', $key)
                ->update(['value' => $nextLastRoNumber]);

            return $lastRoNumber;
        });

        return $lastRoNumber;
    }

    public static function store(Request $request)
    {
        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL;
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY;

        DB::transaction(function () use ($request, $dbConnection, $mysql, $mysqlSecondary) {

            if ($dbConnection === $mysql) {
                $receiveOrder = self::storeRo($mysql, $request);

                $purchaseOrderCode = $receiveOrder->purchaseOrder->code;
                $purchaseOrderId = PurchaseOrder::on($mysqlSecondary)->where('code', $purchaseOrderCode)->first(['id'])->id;
                self::storeRo($mysqlSecondary, $request, $receiveOrder->code, $purchaseOrderId);
            } else {
                self::storeRo($mysql, $request);
            }
        });
    }

    public static function storeRo(string $dbConnection, ReceiveOrderStoreRequest $request, string $code = null, $purchaseOrderId = null): ReceiveOrder
    {
        $data = $request->validated();
        $data['code'] = $code ?? $request['code'] ?? null; // if code null, generate code on model booted::created()
        if ($purchaseOrderId) $data['purchase_order_id'] = $purchaseOrderId;
        $receiveOrder = ReceiveOrder::on($dbConnection)->create($data);
        self::createReceiveOrderDetails($receiveOrder, $data['items']);
        return $receiveOrder;
    }

    public static function createReceiveOrderDetails(ReceiveOrder $receiveOrder, $data): void
    {
        $isFulfilled = true;
        $purchaseOrderDetails = $receiveOrder->purchaseOrder?->details ?? collect([]);

        foreach ($purchaseOrderDetails as $detail) {
            $poDetailQty = $detail->qty;

            $receiveOrder->details()->create([
                'product_id' => $detail->product_id,
                'qty' => $data[$detail->product_id]['qty'],
                'unit_price' => $detail->unit_price,
                'total_price' => $data[$detail->product_id]['qty'] * $detail->unit_price,
            ]);

            $roDetailsPerProduct = ReceiveOrderDetail::query()
                ->whereHas('receiveOrder', fn($query) => $query->where('purchase_order_id', $detail->purchase_order_id))
                ->where('product_id', $detail->product_id)
                ->get();

            $roDetailQty = $roDetailsPerProduct->sum('qty') ?? 0; // summary of qty
            if ($roDetailQty < $poDetailQty) {
                $isFulfilled = false;
            }
        }

        $receiveOrder->update([
            'total_price' => $receiveOrder->details->sum('total_price')
        ]);

        $receiveOrder->purchaseOrder->update([
            'status' => $isFulfilled ? POStatus::COMPLETED : POStatus::PARTIAL
        ]);
    }
}
