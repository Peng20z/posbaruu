<?php

namespace App\Services;

use App\Enums\DatabaseConnection;
use App\Enums\SettingEnum;
use App\Http\Requests\SalesOrderStoreAdminRequest;
use App\Http\Requests\SalesOrderStoreRequest;
use App\Models\Product;
use App\Models\SalesOrder;
use App\Models\SalesOrderDetail;
use App\Models\Setting;
use App\Models\Stock;
use App\Models\StockHistory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class SalesOrderServiceBackup
{
    public static function getCode(string $dbConnection = null): string
    {
        if (empty($dbConnection))
            $dbConnection = CoreService::getCookieDbConnection();

        $key = SettingEnum::SO_NUMBER;
        $databaseConnection = DatabaseConnection::coerce($dbConnection);
        $prefix = $databaseConnection->getSoCodeFormat();

        $lastSoNumber = DB::connection($dbConnection)->transaction(function () use ($key, $prefix, $dbConnection) {
            // Get current value to use. We use lock for update
            // to prevent other thread to read this row until we update it
            $lastSoNumber = DB::connection($dbConnection)->table('settings')
                ->where('key', $key)
                ->lockForUpdate()
                ->first('value')?->value ?? null;

            if (isset($lastSoNumber) && !is_null($lastSoNumber) && $lastSoNumber != '') {
                $arrayLastSoNumber = explode('/', $lastSoNumber);

                if (is_array($arrayLastSoNumber) && count($arrayLastSoNumber) == 6 && date('d') == $arrayLastSoNumber[1]) {
                    $arrayLastSoNumber[5] = sprintf('%02d', (int) $arrayLastSoNumber[5] + 1);
                    $arrayLastSoNumber[5] = substr("00{$arrayLastSoNumber[5]}", -3);
                    $nextLastSoNumber = implode('/', $arrayLastSoNumber);
                } else {
                    $lastSoNumber = sprintf($prefix . '001', date('d'), date('m'), date('y'));
                    $nextLastSoNumber = sprintf($prefix . '002', date('d'), date('m'), date('y'));
                }
            } else {
                $lastSoNumber = sprintf($prefix . '001', date('d'), date('m'), date('y'));
                $nextLastSoNumber = sprintf($prefix . '002', date('d'), date('m'), date('y'));
            }

            // update the value with $nextLastSoNumber
            DB::connection($dbConnection)->table('settings')
                ->where('key', $key)
                ->update(['value' => $nextLastSoNumber]);

            return $lastSoNumber;
        });

        return $lastSoNumber;
    }

    public static function store(SalesOrderStoreRequest $request)
    {
        $dbConnection = CoreService::getCookieDbConnection();

        DB::transaction(function () use ($request, $dbConnection) {

            if ($dbConnection == DatabaseConnection::MYSQL) {
                $salesOrder = self::storeSO(DatabaseConnection::MYSQL, $request);
                self::storeSO(DatabaseConnection::MYSQL_SECONDARY, $request, $salesOrder->code);
            } else {
                self::storeSO(DatabaseConnection::MYSQL_SECONDARY, $request);
            }
        });
    }

    public static function storeSO(string $dbConnection, SalesOrderStoreRequest $request, string $code = null): SalesOrder
    {
        $data = $request->validated();
        $data['code'] = $code; // if code null, generate code on model booted::created()
        $salesOrder = SalesOrder::on($dbConnection)->create($data);

        foreach ($request->items as $item) {
            $product = Product::with(['uoms' => fn ($q) => $q->where('uom_id', $item['uom_id'])])->findOrFail($item['product_id']);
            $productUom = $product->uoms[0];

            $totalDiscount = isset($item['discount']) && (float) $item['discount'] > 0 ? (float) $item['discount'] : 0;
            $originalTotalPrice = ($item['unit_price'] - $totalDiscount) * $item['qty'];

            $tax = isset($item['ppn']) ? self::getTaxPrice($originalTotalPrice) : 0;
            $totalPrice = $originalTotalPrice + $tax;

            $detail = $salesOrder->details()->create([
                'product_id' => $item['product_id'],
                'uom_id' => $item['uom_id'],
                'qty' => $item['qty'],
                'tax' => $tax,
                'total_discount' => $totalDiscount,
                'unit_price' => $item['unit_price'],
                'total_price' => $totalPrice,
            ]);

            self::createHistory($detail);
        }

        $salesOrder->update([
            'total_price' => $salesOrder->details->sum('total_price')
        ]);

        return $salesOrder;
    }

    public static function storeAdmin(SalesOrderStoreAdminRequest $request)
    {
        //get current db connection from cookie
        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL;
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY;

        $request->items = collect($request->items)->map(function ($item) use ($dbConnection) {
            return [
                'product_id' => $item['product_id'],
                'book' => $item['book'],
                'qty' => $item['qty'],
                'unit_price' => $item['unit_price'],
                'uom_id' => $item['uom_id'],
                'ppn' => $item['ppn'] ?? null,
                'discount' => $item['discount'],
                'code' => Crypt::encrypt(['db' => DatabaseConnection::getBook($dbConnection, $item['book']), 'code' => rand()]),
            ];
        });

        //store data
        DB::transaction(function () use ($request, $mysql, $mysqlSecondary, $dbConnection) {
            if ($dbConnection == $mysql) {
                $checkDb = collect($request->items)->contains('book', 'mysql');

                if ($checkDb == true) {
                    $salesOrder1 = new SalesOrder();
                    $salesOrder1->setConnection($mysql);
                    $salesOrder1->customer_id = $request->customer_id;
                    $salesOrder1->transaction_datetime = $request->transaction_datetime;
                    $salesOrder1->additional_discount = $request->additional_discount == "" ? 0 : $request->additional_discount;
                    $salesOrder1->description = $request->description ?? null;
                    $salesOrder1->save();

                    foreach ($request->items as $item) {
                        if ($item['book'] == 'mysql') {
                            $detail = self::createSODetail($salesOrder1, $item);

                            self::createHistory($detail);
                        }
                    }

                    $salesOrder1->update([
                        'total_price' => $salesOrder1->details->sum('total_price') - ($salesOrder1->additional_discount / 100 * $salesOrder1->details->sum('total_price'))
                    ]);
                }

                $salesOrder2 = new SalesOrder();
                $salesOrder2->setConnection($mysqlSecondary);
                $salesOrder2->customer_id = $request->customer_id;
                $salesOrder2->transaction_datetime = $request->transaction_datetime;
                $salesOrder2->additional_discount = $request->additional_discount == "" ? 0 : $request->additional_discount;
                $salesOrder2->description = $request->description ?? null;
                $salesOrder2->code = $salesOrder1?->code ?? null;
                $salesOrder2->save();

                foreach ($request->items as $item) {
                    $detail = self::createSODetail($salesOrder2, $item);

                    if ($item['book'] == 'mysql_secondary') {
                        self::createHistory($detail);
                    }
                }

                $salesOrder2->update([
                    'total_price' => $salesOrder2->details->sum('total_price') - ($salesOrder2->additional_discount / 100 * $salesOrder2->details->sum('total_price'))
                ]);
            } else {
                $checkDb = collect($request->items)->contains('book', 'mysql_secondary');

                if ($checkDb == true) {
                    $salesOrder1 = new SalesOrder();
                    $salesOrder1->setConnection($mysqlSecondary);
                    $salesOrder1->customer_id = $request->customer_id;
                    $salesOrder1->transaction_datetime = $request->transaction_datetime;
                    $salesOrder1->additional_discount = $request->additional_discount == "" ? 0 : $request->additional_discount;
                    $salesOrder1->description = $request->description ?? null;
                    $salesOrder1->save();

                    foreach ($request->items as $item) {
                        if ($item['book'] == 'mysql_secondary') {
                            $detail = self::createSODetail($salesOrder1, $item);

                            self::createHistory($detail);
                        }
                    }

                    $salesOrder1->update([
                        'total_price' => $salesOrder1->details->sum('total_price') - ($salesOrder1->additional_discount / 100 * $salesOrder1->details->sum('total_price'))
                    ]);
                }

                $salesOrder2 = new SalesOrder();
                $salesOrder2->setConnection($mysql);
                $salesOrder2->customer_id = $request->customer_id;
                $salesOrder2->transaction_datetime = $request->transaction_datetime;
                $salesOrder2->additional_discount = $request->additional_discount == "" ? 0 : $request->additional_discount;
                $salesOrder2->description = $request->description ?? null;
                $salesOrder2->code = $salesOrder1?->code ?? null;
                $salesOrder2->save();

                foreach ($request->items as $item) {
                    $detail = self::createSODetail($salesOrder2, $item);

                    if ($item['book'] == 'mysql') {
                        self::createHistory($detail);
                    }
                }

                $salesOrder2->update([
                    'total_price' => $salesOrder2->details->sum('total_price') - ($salesOrder2->additional_discount / 100 * $salesOrder2->details->sum('total_price'))
                ]);
            }
        });
    }

    public static function createHistory(SalesOrderDetail $detail)
    {
        $qty = $detail->product?->uoms()->where('uom_id', $detail->uom_id)->first(['quantity'])?->quantity;
        $detail->stockHistory()->create([
            'user_id' => Auth::user()->id,
            'stock_id' => $detail->product?->stock->id,
            'is_increment' => false,
            'qty' => $detail->qty * $qty,
        ]);
    }

    public static function createSODetail(SalesOrder $salesOrder, $item)
    {
        $totalDiscount = isset($item['discount']) && (double) $item['discount'] > 0 ? (double) $item['discount'] : 0;
        $originalTotalPrice = ($item['unit_price'] - ($totalDiscount / 100 * $item['unit_price'])) * $item['qty'];

        $tax = isset($item['ppn']) ? self::getTaxPrice($originalTotalPrice) : 0;
        $totalPrice = $originalTotalPrice + $tax;

        $detail = $salesOrder->details()->create([
            'product_id' => $item['product_id'],
            'uom_id' => $item['uom_id'],
            'code' => $item['code'],
            'qty' => $item['qty'],
            'tax' => $tax,
            'total_discount' => $totalDiscount,
            'unit_price' => $item['unit_price'],
            'total_price' => $totalPrice,
        ]);

        return $detail;
    }

    public static function getTaxPrice(int|float $price): int|float
    {
        $tax = Setting::where('key', SettingEnum::TAX_VALUE)->first(['value'])?->value ?? 0;

        return $price * $tax / 100;
    }

    public static function deleteSODetail($detail, $db)
    {
        Stock::on($db)->where('product_id', $detail->product_id)->increment('qty', $detail->stockHistory->qty ?? 0);
        $detail->stockHistory?->delete();
        $detail->delete();
    }

    public static function updateAdmin(SalesOrder $salesOrder, SalesOrderStoreAdminRequest $request)
    {
        //get current db connection from cookie
        $dbConnection = CoreService::getCookieDbConnection();
        $mysql = DatabaseConnection::MYSQL;
        $mysqlSecondary = DatabaseConnection::MYSQL_SECONDARY;

        $request->items = collect($request->items)->map(function ($item) use ($dbConnection) {
            return [
                'product_id' => $item['product_id'],
                'book' => $item['book'],
                'qty' => $item['qty'],
                'unit_price' => $item['unit_price'],
                'uom_id' => $item['uom_id'],
                'ppn' => $item['ppn'] ?? null,
                'discount' => $item['discount'],
                'code' => Crypt::encrypt(['db' => DatabaseConnection::getBook($dbConnection, $item['book']), 'code' => rand()]),
            ];
        });

        //update data
        DB::transaction(function () use ($request, $mysql, $mysqlSecondary, $dbConnection, $salesOrder) {
            $salesOrderCode = $salesOrder->code;
            if ($dbConnection == $mysql) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $SODetails = SalesOrderDetail::on($db->value)->whereHas('salesOrder', fn ($q) => $q->where('code', $salesOrderCode))->whereIn('code', $salesOrder->details->pluck('code'))->get();

                    foreach ($SODetails as $detail) {
                        self::deleteSODetail($detail, $db->value);
                        // SalesOrderDetail::on($db->value)->whereIn('code', $SODetailCode)->whereHas('salesOrder', fn ($q) => $q->where('code', $salesOrderCode))->delete();
                    }
                }

                $checkDb = collect($request->items)->contains('book', 'mysql');
                if (!$checkDb) {
                    SalesOrder::on($mysql)->where('code', $salesOrderCode)->delete();
                } else {
                    $salesOrder1 = SalesOrder::on($mysql)->where('code', $salesOrderCode)->first();

                    foreach ($request->items as $item) {
                        if ($item['book'] == 'mysql') {
                            $detail = self::createSODetail($salesOrder1, $item);

                            self::createHistory($detail);
                        }
                    }

                    $salesOrder1->update([
                        'transaction_datetime' => $request->transaction_datetime,
                        'customer_id' => $request->customer_id,
                        'description' => $request->description,
                        'additional_discount' => $request->additional_discount,
                        'total_price' => $salesOrder1->details->sum('total_price') - ($request->additional_discount / 100 * $salesOrder1->details->sum('total_price')),
                    ]);
                }

                $salesOrder2 = SalesOrder::on($mysqlSecondary)->where('code', $salesOrderCode)->first();
                foreach ($request->items as $item) {
                    $detail = self::createSODetail($salesOrder2, $item);

                    if ($item['book'] == 'mysql_secondary') {
                        self::createHistory($detail);
                    }
                }

                $salesOrder2->update([
                    'transaction_datetime' => $request->transaction_datetime,
                    'customer_id' => $request->customer_id,
                    'description' => $request->description,
                    'additional_discount' => $request->additional_discount,
                    'total_price' => $salesOrder2->details->sum('total_price') - ($request->additional_discount / 100 * $salesOrder2->details->sum('total_price')),
                ]);
            } else {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $SODetails = SalesOrderDetail::on($db->value)->whereHas('salesOrder', fn ($q) => $q->where('code', $salesOrderCode))->get();
                    foreach ($SODetails as $detail) {
                        self::deleteSODetail($detail, $db->value);
                        // SalesOrderDetail::on($db->value)->whereIn('code', $SODetailCode)->whereHas('salesOrder', fn ($q) => $q->where('code', $salesOrderCode))->delete();
                    }
                }

                $checkDb = collect($request->items)->contains('book', 'mysql_secondary');

                if (!$checkDb) {
                    SalesOrder::on($mysqlSecondary)->where('code', $salesOrderCode)->delete();
                } else {
                    $salesOrder1 = SalesOrder::on($mysqlSecondary)->where('code', $salesOrderCode)->first();

                    foreach ($request->items as $item) {
                        if ($item['book'] == 'mysql_secondary') {
                            $detail = self::createSODetail($salesOrder1, $item);

                            self::createHistory($detail);
                        }
                    }

                    $salesOrder1->update([
                        'transaction_datetime' => $request->transaction_datetime,
                        'customer_id' => $request->customer_id,
                        'description' => $request->description,
                        'additional_discount' => $request->additional_discount,
                        'total_price' => $salesOrder1->details->sum('total_price') - ($request->additional_discount / 100 * $salesOrder1->details->sum('total_price')),
                    ]);
                }
                $salesOrder2 = SalesOrder::on($mysql)->where('code', $salesOrderCode)->first();

                foreach ($request->items as $item) {
                    $detail = self::createSODetail($salesOrder2, $item);

                    if ($item['book'] == 'mysql') {
                        self::createHistory($detail);
                    }
                }

                $salesOrder2->update([
                    'transaction_datetime' => $request->transaction_datetime,
                    'customer_id' => $request->customer_id,
                    'description' => $request->description,
                    'additional_discount' => $request->additional_discount,
                    'total_price' => $salesOrder2->details->sum('total_price') - ($request->additional_discount / 100 * $salesOrder2->details->sum('total_price')),
                ]);
            }
        });
    }
}
