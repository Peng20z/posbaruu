<?php

namespace App\Imports;

use App\Enums\DatabaseConnection;
use App\Models\CustomerGroup;
use App\Models\CustomerGroupProduct;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\Uom;
use App\Services\CoreService;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithLimit;
use Maatwebsite\Excel\Concerns\WithStartRow;

class ProductsImport implements ToModel, WithStartRow
{
    /**
     * @param array $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function model(array $row)
    {
        foreach (DatabaseConnection::getInstances() as $db) {
            CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 1'
            ]);
            CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 2'
            ]);
            CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 3'
            ]);
            CustomerGroup::on($db->value)->updateOrCreate([
                'name' => 'Grosir 4'
            ]);
        }
        foreach (DatabaseConnection::getInstances() as $db) {
            $this->insertProduct($db->value, $row);
        }
        if (str_ends_with($row[0], 'T')) {
            // foreach (DatabaseConnection::getInstances() as $db) {
            //     $this->insertProduct($db->value, $row);
            // }
        } elseif (CoreService::getCookieDbConnection() === DatabaseConnection::MYSQL) {
            $this->insertProduct(DatabaseConnection::MYSQL_SECONDARY, $row);
            // $duplicate = Product::on(DatabaseConnection::MYSQL_SECONDARY)->firstWhere('id', $row[1]);
            // if (!$duplicate) {
            //     $product = Product::on(DatabaseConnection::MYSQL_SECONDARY)->create([
            //         'name'       => str_replace('*', '', $row[6]),
            //         'id'       => str_replace('T', '', $row[1]),
            //         'buy_price'  => $row[15],
            //         'sell_price' => $row[15],
            //         'product_category_id' => 1,
            //         'product_brand_id' => 1,
            //         'default_uom_id' => 1,
            //         'base_uom_id' => 1,
            //     ]);

            //     ProductUom::on(DatabaseConnection::MYSQL_SECONDARY)->create([
            //         'product_id' => $product->id,
            //         'uom_id' => 1,
            //         'is_base' => true,
            //         'is_default' => true,
            //         'buy_price' => $product->buy_price,
            //         'sell_price' => $product->sell_price,
            //     ]);
            // }
        } else {
            $this->insertProduct(DatabaseConnection::MYSQL, $row);
            // $duplicate = Product::firstWhere('id', $row[1]);
            // if (!$duplicate) {
            //     $product = Product::create([
            //         'name'       => str_replace('*', '', $row[6]),
            //         'id'       => str_replace('T', '', $row[1]),
            //         'buy_price'  => $row[15],
            //         'sell_price' => $row[15],
            //         'product_category_id' => 1,
            //         'product_brand_id' => 1,
            //         'default_uom_id' => 1,
            //         'base_uom_id' => 1,
            //     ]);

            //     ProductUom::create([
            //         'product_id' => $product->id,
            //         'uom_id' => 1,
            //         'is_base' => true,
            //         'is_default' => true,
            //         'buy_price' => $product->buy_price,
            //         'sell_price' => $product->sell_price,
            //     ]);
            // }
        }

        // $product = Product::create([
        //     'name'       => str_replace('*','',$row[6]),
        //     'id'       => str_replace('T','',$row[1]),
        //     'buy_price'  => $row[15],
        //     'sell_price' => $row[15],
        //     'product_category_id' => 1,
        //     'product_brand_id' => 1,
        //     'default_uom_id' => 1,
        //     'base_uom_id' => 1,
        // ]);

        // ProductUom::create([
        //     'product_id' => $product->id,
        //     'uom_id' => 1,
        //     'is_base' => true,
        //     'is_default' => true,
        //     'buy_price' => $product->buy_price,
        //     'sell_price' => $product->sell_price,
        // ]);
    }

    public function startRow(): int
    {
        return 2;
    }

    public function upsertUom(string $db, array $row): Uom
    {
        $uomName = strtolower(trim($row[8]));
        if (!empty($uomName)) {
            $uom = Uom::on($db)->updateOrCreate([
                'name' => $uomName
            ]);
        } else {
            $uom = Uom::on($db)->firstWhere('name', 'pcs');
        }

        return $uom;
    }

    public function createProduct(string $db, Uom $uom, array $row): Product
    {
        return Product::on($db)->create([
            'name'       => str_replace('*', '', $row[1]),
            'id'       => str_replace('T', '', $row[0]),
            'buy_price'  => (float) $row[2],
            'sell_price' => (float) $row[2],
            'product_category_id' => 1,
            'product_brand_id' => 1,
            'default_uom_id' => $uom->id,
            'base_uom_id' => $uom->id,
            'description' => $row[9],
        ]);
    }

    public function createProductUom(string $db, Product $product, Uom $uom): void
    {
        ProductUom::on($db)->create([
            'product_id' => $product->id,
            'uom_id' => $uom->id,
            'is_base' => true,
            'is_default' => true,
            'buy_price' => $product->buy_price,
            'sell_price' => $product->sell_price,
        ]);
    }

    public function createCustomerGroupProduct(string $db, CustomerGroup $customerGroup, Product $product, Uom $uom, array $row, int $index): void
    {
        $sellPrice = (float) $row[$index] ?? (float) $row[2];
        $discounts = null;
        if (!empty($row[7])) {
            $percentage = $row[7];
            $discount = $sellPrice * $percentage;
            $discounts = ['1' => (float) round($discount)];

        }
        CustomerGroupProduct::on($db)->create([
            'customer_group_id' => $customerGroup->id,
            'product_id' => $product->id,
            'uom_id' => $uom->id,
            'sell_price' => $sellPrice,
            'discounts' => $discounts,
        ]);
    }

    public function insertProduct(string $db = 'mysql', array $row): void
    {
        $grosir1 = CustomerGroup::on($db)->firstWhere('name', 'Grosir 1');
        $grosir2 = CustomerGroup::on($db)->firstWhere('name', 'Grosir 2');
        $grosir3 = CustomerGroup::on($db)->firstWhere('name', 'Grosir 3');
        $grosir4 = CustomerGroup::on($db)->firstWhere('name', 'Grosir 4');

        $code = str_replace('T', '', $row[0]);
        $duplicate = Product::on($db)->firstWhere('id', $code);

        if (!$duplicate) {
            $uom = $this->upsertUom($db, $row);

            $product = $this->createProduct($db, $uom, $row);
            $this->createProductUom($db, $product, $uom);

            $this->createCustomerGroupProduct($db, $grosir1, $product, $uom, $row, 3);
            $this->createCustomerGroupProduct($db, $grosir2, $product, $uom, $row, 4);
            $this->createCustomerGroupProduct($db, $grosir3, $product, $uom, $row, 5);
            $this->createCustomerGroupProduct($db, $grosir4, $product, $uom, $row, 6);
        }
    }
}

// $code = str_replace('T', '', $row[1]);
// $duplicate = Product::on($db->value)->firstWhere('id', $code);

// if (!$duplicate) {
//     $uom = Uom::on($db->value)->where('name', strtolower(trim($row[8])))->first();
//     if (!$uom) {
//         $uom = Uom::on($db->value)->create([
//             'name' => $row[8]
//         ]);
//     }

//     $product = Product::on($db->value)->create([
//         'name'       => str_replace('*', '', $row[1]),
//         'id'       => $code,
//         'buy_price'  => $row[2],
//         'sell_price' => $row[2],
//         'product_category_id' => 1,
//         'product_brand_id' => 1,
//         'default_uom_id' => $uom->id,
//         'base_uom_id' => $uom->id,
//         'description' => $row[9],
//     ]);

//     ProductUom::on($db->value)->create([
//         'product_id' => $product->id,
//         'uom_id' => $uom->id,
//         'is_base' => true,
//         'is_default' => true,
//         'buy_price' => $product->buy_price,
//         'sell_price' => $product->sell_price,
//     ]);

//     if (!empty($row[3]) && (float) $row[3] != 0) {
//         $sellPrice = (float) $row[3];
//         $discounts = null;
//         if (!empty($row[7])) {
//             $percentage =  (float) str_replace('%', '', $row[7]) / 100;
//             $discount = $sellPrice * $percentage;
//             $discounts = [0 => $discount];
//         }
//         CustomerGroupProduct::on($db->value)->create([
//             'customer_group_id' => $grosir1->id,
//             'product_id' => $product->id,
//             'uom_id' => $uom->id,
//             'sell_price' => $sellPrice,
//             'discounts' => $discounts,
//         ]);
//     }
// }
