<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static newterms()
 * @method static static N7()
 * @method static static COD()
 * @method static static NET14()
 * @method static static NET30()
 */
final class POTerms extends Enum
{
    const newterms = 'New Terms';
    const N7 = '1.5/7 n/7';
    const COD = 'C.O.D';
    const NET14 = 'Net 14';
    const NET30 = 'Net 30';
}
