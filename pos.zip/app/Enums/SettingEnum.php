<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static PO_NUMBER()
 * @method static static RO_NUMBER()
 */
final class SettingEnum extends Enum
{
    const PO_NUMBER = 'po_number';
    const RO_NUMBER = 'ro_number';
    const SO_NUMBER = 'so_number';
    const TAX_VALUE = 'tax_value';
    const IS_SKIP_RO = 'is_skip_ro';
    const STOCK_LESS_THAN_0 = 'stock_less_than_0';

    public static function getValueType(string $key, string|int $value)
    {
        return match ($key) {
            self::PO_NUMBER,
            self::RO_NUMBER => (string) $value,
            self::SO_NUMBER => (string) $value,
            self::TAX_VALUE => (int) $value,
            self::IS_SKIP_RO => (int) $value,
            self::STOCK_LESS_THAN_0 => (int) $value,
            default => $value
        };
    }
}
