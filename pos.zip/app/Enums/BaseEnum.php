<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

abstract class BaseEnum extends Enum
{
    public string $customDescription;

    /**
     * Construct an Enum instance.
     *
     * @param  TValue  $enumValue
     *
     * @throws \BenSampo\Enum\Exceptions\InvalidEnumMemberException
     */
    public function __construct(mixed $enumValue)
    {
        parent::__construct($enumValue);
        $this->customDescription = static::getCustomDescription($enumValue);
    }

    public static function getCustomDescription(mixed $value): string
    {
        if ($value instanceof Enum) {
            return $value->description;
        }
        return $value;
    }
}
