<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

/**
 * @method static static PROCESS()
 * @method static static PARTIAL()
 * @method static static COMPLETED()
 * @method static static CANCELED()
 */
final class POStatus extends Enum
{
    const PROCESS = 'process';
    const PARTIAL = 'partial';
    const COMPLETED = 'completed';
    const CANCELED = 'canceled';

    public function getColored()
    {
        return match ($this->value) {
            self::PARTIAL => '<span class="badge badge-warning">' . $this->key . '</span>',
            self::COMPLETED => '<span class="badge badge-success">' . $this->key . '</span>',
            self::CANCELED => '<span class="badge badge-danger">' . $this->key . '</span>',
            default => '<span class="badge badge-secondary">' . $this->key . '</span>',
        };
    }
}
