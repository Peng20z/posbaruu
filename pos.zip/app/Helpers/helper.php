<?php
if (!function_exists('arrayFilterAndReindex')) {
    /**
     * remove array where value is null and reindex from 0
     */
    function arrayFilterAndReindex(array $values = []): array
    {
        return array_values(array_filter($values)) ?? [];
    }
}

if (!function_exists('rupiah')) {
    function rupiah(int|float|string $number = null, $formatCurrency = false): string
    {
        if (is_null($number)) return 0;

        if ($formatCurrency) {
            // return "Rp " . number_format($number, 2, ',', '.');
            return "Rp " . number_format($number, 2);
        }

        return number_format($number, 2);
    }
}

if (!function_exists('filterPrice')) {
    function filterPrice($number)
    {
        $number = str_replace('Rp', '', $number);
        $number = str_replace('Rp.', '', $number);
        $number = str_replace(',', '', $number);
        $number = str_replace('.', '', $number);
        return intval($number);
    }
}

if (!function_exists('filterPriceFloat')) {
    function filterPriceFloat($number)
    {
        $number = str_replace('Rp', '', $number);
        $number = str_replace('Rp.', '', $number);
        $number = str_replace(',', '', $number);
        // $number = str_replace('.', '', $number);
        return doubleval($number);
    }
}

if (!function_exists('setTotalAmountExportedBatch')) {
    function setTotalAmountExportedBatch($value)
    {
        return $value;
        // if ($value == 0) return $value;

        // if ($value > 0) return -$value;

        // return abs($value);
    }
}

if (!function_exists('getMonthSelections')) {
    function getMonthSelections(): array
    {
        $startYear = '2023';
        $endYear = date('Y');
        $data = [];

        for ($iYear = $startYear; $iYear <= $endYear; $iYear++) {
            for ($iMonth = 1; $iMonth <= 12; $iMonth++) {
                $data[substr("0{$iMonth}", -2) . '-' . $iYear] = date("F", mktime(0, null, null, $iMonth)) . '-' . $iYear;
            }
        }

        return $data ?? [];
    }
}

if (!function_exists('filterNA')) {
    function filterNA($value)
    {
        if (is_numeric(strpos($value, 'N/A')) || is_numeric(strpos($value, 'n/a'))) return null;
        return trim($value);
    }
}

if (!function_exists('formatDistance')) {
    function formatDistance($value): int
    {
        $value = str_replace('km', '', $value);
        $value = str_replace('m', '', $value);
        $value = str_replace(' ', '', $value);

        $value = ceil((float)$value);
        return (int) $value;
    }
}
