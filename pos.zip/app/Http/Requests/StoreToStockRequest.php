<?php

namespace App\Http\Requests;

use App\Enums\DatabaseConnection;
use App\Models\ReceiveOrderDetail;
use Closure;
use Illuminate\Foundation\Http\FormRequest;

class StoreToStockRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $databaseConnections = DatabaseConnection::getInstances();
        $additionalRules = [];

        foreach ($databaseConnections as $db) {
            $additionalRules['data.*.' . $db->value] = 'required|integer';
            $additionalRules['data.*.' . $db->value] = 'required|integer';
        };

        return [
            ...$additionalRules,
            'data' => [
                'required',
                'array',
                function (string $attribute, mixed $values, Closure $fail) use ($databaseConnections) {
                    foreach ($values as $receiveOrderDetailId => $data) {
                        $roDetail = ReceiveOrderDetail::find($receiveOrderDetailId);
                        if (!$roDetail) $fail('Receive order detail not found');

                        $totalQty = 0;
                        foreach ($databaseConnections as $db) {
                            $totalQty += $data[$db->value];
                        };

                        if ($totalQty != $roDetail->qty) $fail('Total qty of each product not match');
                    }
                }
            ],
        ];
    }
}
