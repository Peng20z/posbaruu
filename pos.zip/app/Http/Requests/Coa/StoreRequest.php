<?php

namespace App\Http\Requests\Coa;

use App\Enums\NormalBalance;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Foundation\Http\FormRequest;

class StoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'parent_id' => 'required|exists:coas,id',
            'account_name' => 'required|string',
            'account_number' => 'required|string',
            'normal_balance' => ['required', new EnumValue(NormalBalance::class)],
        ];
    }
}
