<?php

namespace App\Http\Requests;

use App\Enums\PaymentStatus;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Foundation\Http\FormRequest;

class PurchaseInvoiceUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function prepareForValidation(): void
    {
        $amount = filterPriceFloat($this->amount);

        $this->merge([
            'amount' => $amount,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'amount' => 'required|numeric',
            'status' => ['nullable', new EnumValue(PaymentStatus::class)],
            'description' => 'nullable',
        ];
    }
}
