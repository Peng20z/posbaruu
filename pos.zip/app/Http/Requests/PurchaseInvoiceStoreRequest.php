<?php

namespace App\Http\Requests;

use App\Enums\PaymentStatus;
use App\Models\PurchaseOrder;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Foundation\Http\FormRequest;

class PurchaseInvoiceStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function prepareForValidation(): void
    {
        $amount = filterPriceFloat($this->amount);

        $this->merge([
            'amount' => $amount,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $po = PurchaseOrder::where('code', $this->purchase_order_id)->first();

        $max_payment = $po->total_price - $po->total_paid;
        return [
            'purchase_order_id' => 'required|exists:purchase_orders,code',
            'payment_type_id' => 'required|exists:payment_types,id',
            'code' => 'required|unique:payments,code',
            'amount' => 'required|numeric|max:' . $max_payment,
            'status' => ['nullable', new EnumValue(PaymentStatus::class)],
            'description' => 'nullable',
        ];
    }
}
