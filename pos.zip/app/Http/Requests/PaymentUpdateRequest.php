<?php

namespace App\Http\Requests;

use App\Enums\PaymentStatus;
use App\Models\SalesOrder;
use BenSampo\Enum\Rules\EnumValue;
use Illuminate\Foundation\Http\FormRequest;

class PaymentUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function prepareForValidation(): void
    {
        $amount = filterPriceFloat($this->amount);

        $this->merge([
            'amount' => $amount,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $payment = $this->route('payment');
        $so = SalesOrder::where('code', $this->sales_order_id)->first();
        $max_payment = $so->total_price - ($so->total_paid - $this->amount);
        return [
            'sales_order_id' => 'required|exists:sales_orders,code',
            'code' => 'required|unique:payments,code,' . $payment,
            'payment_type_id' => 'required|exists:payment_types,id',
            'amount' => 'required|numeric|max:' . $max_payment,
            'status' => ['nullable', new EnumValue(PaymentStatus::class)],
            'description' => 'nullable',
        ];
    }
}
