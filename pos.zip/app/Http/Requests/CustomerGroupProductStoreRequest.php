<?php

namespace App\Http\Requests;

use App\Models\Product;
use Closure;
use Illuminate\Foundation\Http\FormRequest;

class CustomerGroupProductStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $items = [];
        if($this->discounts['qty'][0] != '0'){
            $isPercentage = 0;
            $items['qty'] = $this->discounts['qty'];

            for ($i=0; $i < count($this->discounts['qty']) ; $i++) {
                $items['price'][$i] = filterPrice($this->discounts['price'][$i] ?? 0);
                $isPercentage = isset($this->discounts['is_percentage'][$i]) && (bool) $this->discounts['is_percentage'][$i] == true ? 1 : 0;
                $items['is_percentage'][$i] = $isPercentage;
            }
        }
        $this->merge([
            'sell_price' => filterPrice($this->sell_price ?? 0),
            'discounts' => $items,
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $customerGroup = $this->route('customer_group');

        return [
            'product_id' => 'required|exists:products,id',
            'uom_id' => [
                'required',
                'exists:uoms,id',
                function ($attribute, $value, Closure $fail) use ($customerGroup) {
                    $product = Product::find($this->product_id);

                    if (!$product || $product->uoms()->where('uoms.id', $value)->doesntExist()) {
                        $fail('Uom invalid');
                    }
                    if($customerGroup->customerGroupProducts()->where('product_id', $this->product_id)->where('uom_id', $this->uom_id)->exists()){
                        $fail('Uom already exist');
                    }
                }
            ],
            'sell_price' => 'required|numeric',
            'discounts' => 'nullable|array',
            'discounts.price' => 'array',
            'discounts.price.*' => 'numeric',
            'discounts.qty.*' => 'numeric',
            'discounts.qty' => [
                'array',
                function ($attribute, $value, Closure $fail) {
                    $sumQty = 0;
                    foreach ($value as $qty) {
                        if ($qty < $sumQty) {
                            $fail('qty order must be sequential');
                        }
                        $sumQty += $qty;
                    }
                }
            ],
        ];
    }
}
