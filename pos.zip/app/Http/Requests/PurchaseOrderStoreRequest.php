<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PurchaseOrderStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $items = [];
        // $discount = 0;
        if ($this->items) {
            foreach ($this->items as $key => $data) {
                // $discount = isset($data['discount']) && $data['discount'] != '' ? filterPrice($data['discount']) : 0;
                $discount = isset($data['discount']) && $data['discount'] != '' ? floatval($data['discount']) : 0;
                $data['discount'] = $discount;

                $unitPrice = str_replace(",", "", $data['unit_price']);
                $data['unit_price'] = round($unitPrice, 2);
                $items[$key] = $data;
            }

            $this->merge([
                'items' => $items,
            ]);
        }
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'code' => 'nullable|unique:purchase_orders,code',
            'po_number' => 'required|unique:purchase_orders,po_number',
            'supplier_id' => 'required|exists:suppliers,id',
            'terms' => 'nullable',
            'description' => 'nullable',

            'items' => 'required|array',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.uom_id' => 'required|exists:uoms,id',
            'items.*.qty' => 'required|integer',
            'items.*.unit_price' => 'required|numeric',
            'items.*.discount' => 'nullable|numeric',
            'items.*.ppn' => 'nullable',
            'additional_discount' => 'nullable|numeric'
        ];
    }
}
