<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Enums\PaymentStatus;
use App\Http\Requests\PaymentStoreRequest;
use App\Http\Requests\PaymentUpdateRequest;
use App\Models\Payment;
use App\Models\PaymentType;
use App\Models\SalesOrder;
use App\Services\PaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class PaymentController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:payments_access', ['only' => 'index']);
        $this->middleware('permission:payments_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:payments_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:payments_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = Payment::select(sprintf('%s.*', (new Payment)->table))->with(['salesOrder', 'user']);
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('sales_order_code', function ($row) {
                return $row->salesOrder?->code ?? '';
            });
            $table->addColumn('user_name', function ($row) {
                return $row->user?->name ?? '';
            });
            $table->editColumn('status', function ($row) {
                return $row->status?->description ?? '';
            });
            $table->editColumn('amount', fn($row) => rupiah($row->amount));
            $table->editColumn('actions', function ($row) {
                $viewGate = 'payments_access';
                $editGate = 'payments_edit';
                $deleteGate = 'payments_delete';
                $crudRoutePart = 'payments';

                return view(
                    'layouts.includes.datatablesActions',
                    compact(
                        'viewGate',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('payments.index');
    }

    public function show(Payment $payment)
    {
        return view('payments.show', ['payment' => $payment]);
    }

    public function create(Request $request)
    {
        $salesOrders = SalesOrder::whereNotPaid()->get();
        $paymentTypes = PaymentType::get()->pluck('name', 'id')->prepend('- Select Payment Type -', null);
        $paymentStatuses = PaymentStatus::getInstances();
        return view('payments.create', ['salesOrders' => $salesOrders, 'paymentStatuses' => $paymentStatuses, 'paymentTypes' => $paymentTypes]);
    }

    public function store(PaymentStoreRequest $request)
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $so = SalesOrder::on($db->value)->where('code', $request->sales_order_id)->first();
                if ($so->total_paid < $so->total_price) {
                    Payment::on($db->value)->create($request->validated());
                }
            }
        });

        alert()->success('Success', 'Data created successfully');

        if ($request->redirect) return redirect($request->redirect);

        return to_route('payments.index');
    }

    public function edit(Payment $payment)
    {
        $paymentStatuses = PaymentStatus::getInstances();
        $paymentTypes = PaymentType::get()->pluck('name', 'id')->prepend('- Select Payment Type -', null);
        return view('payments.edit', ['payment' => $payment, 'paymentTypes' => $paymentTypes ,'paymentStatuses' => $paymentStatuses]);
    }

    public function update(PaymentUpdateRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            $paymentCode = Payment::select('code')->findOrFail($id)?->code;

            foreach (DatabaseConnection::getInstances() as $db) {
                $payment = Payment::on($db->value)->where('code', $paymentCode)->first();
                if ($payment) {
                    $payment->update($request->validated());
                }
            }
        });

        alert()->success('Success', 'Data updated successfully');
        return to_route('payments.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                $code = Payment::find($id)->code;
                foreach (DatabaseConnection::getInstances() as $db) {
                    $payment = Payment::on($db->value)->where('code', $code);
                    if($payment){
                        $payment->delete();
                    }
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
