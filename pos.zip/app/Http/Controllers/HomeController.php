<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Services\CoreService;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // $products = Product::with('stock')->where('min_stock_reminder', '>', 'stock.qty')->get();
        $products = Product::select('products.id', 'products.name' ,'stocks.qty', 'products.min_stock_reminder')
            ->join('stocks', function ($join) {
                $join->on('products.id', '=', 'stocks.product_id');
                $join->on('stocks.qty', '<', 'products.min_stock_reminder');
            })
            ->get();

        return view('home', ['products' => $products]);
    }

    public function changeDatabaseConnection(Request $request)
    {
        CoreService::setCookieDbConnection($request->database_connection);
        return redirect()->back();
    }
}
