<?php

namespace App\Http\Controllers\Api;

use App\Enums\DatabaseConnection;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderDetail;
use App\Models\ReceiveOrder;
use App\Models\SalesOrder;
use App\Models\SalesOrderDetail;
use Illuminate\Http\Request;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class SalesOrderController extends Controller
{
    public function index(Request $request)
    {
        $paginate = 15;
        if ($request->per_page && is_numeric($request->per_page))
            $paginate = $request->per_page ?? 15;

        $query = Product::class;
        if ($request->select)
            $query = Product::select('id', 'name as text');

        $products = QueryBuilder::for($query)
            ->allowedFilters(['product_category_id', 'product_brand_id', 'name', AllowedFilter::scope('ids', 'where_id_not_in'),])
            ->allowedSorts(['id', 'product_category_id', 'product_brand_id', 'name'])
            ->paginate($paginate);

        return response()->json($products);
    }

    public function show($id)
    {
        if (request()->multidatabase == 1) {
            $salesOrder = SalesOrder::on(DatabaseConnection::MYSQL)->with(['details'])->find($id);
            $salesOrder2 = SalesOrder::on(DatabaseConnection::MYSQL_SECONDARY)->with(['details'])->find($id);

            return response()->json([
                'products' => [$salesOrder, $salesOrder2]
            ]);
        }

        $salesOrder = SalesOrderDetail::with(['product', 'uom'])->where('sales_order_id', $id)->get();
        return response()->json($salesOrder);
    }

    public function getPrice(int $productId, int $uomId)
    {
        $productUom = ProductUom::where('product_id', $productId)->where('uom_id', $uomId)->first();
        return response()->json($productUom);
    }

    public function getUnpaid(Request $request)
    {
        $salesOrder = SalesOrder::where('code', $request->code)->first();
        return response()->json($salesOrder);
    }
}
