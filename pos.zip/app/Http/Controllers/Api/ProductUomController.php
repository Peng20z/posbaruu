<?php

namespace App\Http\Controllers\Api;

use App\Enums\DatabaseConnection;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\Uom;
use Illuminate\Http\Request;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class ProductUomController extends Controller
{
    public function getProductUoms(Product $product)
    {
        $productUoms = ProductUom::where('product_id', $product->id)->with('uom')->get();
        return response()->json($productUoms);
    }

    public function getProductUom(Product $product, Uom $uom)
    {
        $productUom = ProductUom::where('product_id', $product->id)->where('uom_id', $uom->id)->first();
        return response()->json($productUom);
    }
}
