<?php

namespace App\Http\Controllers\Api;

use App\Enums\DatabaseConnection;
use App\Http\Controllers\Controller;
use App\Models\CustomerGroupProduct;
use App\Models\Product;
use App\Models\ProductUom;
use App\Models\PurchaseOrderDetail;
use App\Models\SalesOrderDetail;
use App\Models\Supplier;
use App\Models\User;
use App\Services\CoreService;
use App\Services\ProductService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\QueryBuilder\AllowedFilter;
use Spatie\QueryBuilder\QueryBuilder;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $paginate = 15;
        if ($request->per_page && is_numeric($request->per_page))
            $paginate = $request->per_page ?? 15;

        $query = Product::class;
        if ($request->select)
            $query = Product::select('id', DB::raw('CONCAT(id," - ",name) as text'), 'sell_price as selected');

        $products = QueryBuilder::for($query)
            ->allowedFilters([
                'product_category_id',
                'product_brand_id',
                AllowedFilter::scope('name', 'where_name_like'),
                AllowedFilter::scope('ids', 'where_id_not_in'),
                AllowedFilter::scope('is_active')
            ])
            ->allowedSorts(['id', 'product_category_id', 'product_brand_id', 'name'])
            ->paginate($paginate);

        return response()->json($products);
    }

    public function show($id, Request $request)
    {
        if (request()->multidatabase == 1) {
            $product = Product::on(DatabaseConnection::MYSQL)->with(['productBrand', 'productCategory', 'stock', 'uoms'])->find($id);
            $product2 = Product::on(DatabaseConnection::MYSQL_SECONDARY)->with(['productBrand', 'productCategory', 'stock', 'uoms'])->find($id);

            return response()->json([
                'products' => [$product, $product2]
            ]);
        }

        $product = Product::with(['productBrand', 'productCategory', 'stock', 'uoms'])->find($id);
        $supplierId = $request->supplierId;
        if ($supplierId && $supplierId != 'null') {

            $priceHistory = PurchaseOrderDetail::selectRaw('unit_price, discount, created_at, CONCAT_WS(" and ", discount,unit_price) as unique_key')
                ->where('product_id', $id)
                ->where('uom_id', $product->default_uom_id)
                ->whereHas('purchaseOrder', fn ($q) => $q->where('supplier_id', $supplierId))
                ->orderByDesc('created_at')
                ->get()
                ->makeHidden(['code_decrypt']);
            $priceHistory = $priceHistory->unique('unique_key')->toArray();

            $product->priceHistory = $priceHistory;
        }
        return response()->json($product);
    }

    public function getProductbyDB($id, Request $request)
    {
        $product = Product::with(['productBrand', 'productCategory', 'stock', 'uoms'])->find($id);

        $customerId = $request->customerId;
        if ($customerId && $customerId != 'null') {
            $customer = User::find($customerId);

            if ($customer->customerGroup) {
                $customerGroupProduct = CustomerGroupProduct::where('product_id', $id)->where('uom_id', $product->default_uom_id)->first();
                if ($customerGroupProduct) {
                    $product->sell_price = $customerGroupProduct->sell_price;
                    $product->customer_group_product_discounts = $customerGroupProduct->discounts;
                }
            }

            $priceHistory = SalesOrderDetail::selectRaw('unit_price, total_discount, sales_order_details.total_price, sales_orders.transaction_datetime, CONCAT_WS(" and ", total_discount,unit_price) as unique_key')
                ->join('sales_orders', 'sales_orders.id', '=', 'sales_order_details.sales_order_id')
                ->where('product_id', $id)
                ->where('uom_id', $product->default_uom_id)
                ->whereHas('salesOrder', fn ($q) => $q->where('customer_id', $customerId))
                ->orderByDesc('sales_orders.transaction_datetime')
                ->get()
                ->makeHidden(['code_decrypt']);
            $priceHistory = $priceHistory->unique('unique_key')->toArray();

            $product->priceHistory = $priceHistory;
        }

        $product->select_books = ProductService::getSelectBooks($product);
        return response()->json($product);
    }

    public function getPrice(string $productId, int $uomId, Request $request)
    {
        if (request()->multidatabase == 1) {
            $productUom = ProductUom::on(DatabaseConnection::MYSQL)->where('product_id', $productId)->where('uom_id', $uomId)->first();
            $productUom2 = ProductUom::on(DatabaseConnection::MYSQL_SECONDARY)->where('product_id', $productId)->where('uom_id', $uomId)->first();

            return response()->json([
                'productUoms' => [$productUom, $productUom2]
            ]);
        }

        // 1. check if customer punya group
        // 2. ambil data dari table  customer_group_products berdasrkan product_id & uom_id nya (object)

        // 3. manipulasi data uoms dari $product->uoms


        $productUom = ProductUom::where('product_id', $productId)->where('uom_id', $uomId)->first();
        $supplierId = $request->supplierId;
        if ($supplierId && $supplierId != 'null') {

            $priceHistory = PurchaseOrderDetail::selectRaw('unit_price, discount, created_at, CONCAT_WS(" and ", discount,unit_price) as unique_key')
                ->where('product_id', $productId)
                ->where('uom_id', $uomId)
                ->whereHas('purchaseOrder', fn ($q) => $q->where('supplier_id', $supplierId))
                ->orderByDesc('created_at')
                ->get()
                ->makeHidden(['code_decrypt']);
            $priceHistory = $priceHistory->unique('unique_key')->toArray();

            $productUom->priceHistory = $priceHistory;
        }

        return response()->json($productUom);
    }

    public function getPricebyDB(string $productId, int $uomId, Request $request)
    {
        $productUom = ProductUom::on($request->databaseConnection)->where('product_id', $productId)->where('uom_id', $uomId)->first();

        $customerId = $request->customerId;
        if ($customerId && $customerId != 'null') {
            $customer = User::find($customerId);
            if ($customer->customerGroup && $request->customerId != 'null') {
                $customerGroupProduct = CustomerGroupProduct::where('product_id', $productId)->where('uom_id', $uomId)->first();
                if ($customerGroupProduct) {
                    $productUom->sell_price = $customerGroupProduct->sell_price;
                    $productUom->customer_group_product_discounts = $customerGroupProduct->discounts;
                }
            }

            $priceHistory = SalesOrderDetail::selectRaw('unit_price, total_discount, sales_order_details.total_price, sales_orders.transaction_datetime, CONCAT_WS(" and ", total_discount,unit_price) as unique_key')
                ->join('sales_orders', 'sales_orders.id', '=', 'sales_order_details.sales_order_id')
                ->where('product_id', $productId)
                ->where('uom_id', $uomId)
                ->whereHas('salesOrder', fn ($q) => $q->where('customer_id', $customerId))
                ->orderByDesc('sales_orders.transaction_datetime')
                ->get()
                ->makeHidden(['code_decrypt']);
            $priceHistory = $priceHistory->unique('unique_key')->toArray();

            $productUom->priceHistory = $priceHistory;
        }
        return response()->json($productUom);
    }
}
