<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\SalesReturnStoreRequest;
use App\Models\ProductUom;
use App\Models\SalesOrder;
use App\Models\SalesReturn;
use App\Models\Stock;
use App\Models\Uom;
use App\Services\SalesReturnService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class SalesReturnController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:sales_returns_access', ['only' => 'index']);
        $this->middleware('permission:sales_returns_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:sales_returns_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:sales_returns_delete', ['only' => ['destroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = SalesReturn::select(sprintf('%s.*', (new SalesReturn())->table))->with(['user', 'salesOrder']);
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('user_name', fn ($row) => $row->user?->name ?? '');
            $table->addColumn('sales_order_code', function ($row) {
                if ($row->salesOrder) {
                    return '<a href="' . route('sales-returns.show', $row->salesOrder) . '" target="_blank">' . $row->salesOrder?->code . ' <i class="fa fa-link"></i></a>';
                }
                return '';
            });
            $table->editColumn('total_price', function ($row){
                return rupiah($row->total_price, true);
            });
            $table->editColumn('actions', function ($row) {
                $viewGate = 'sales_returns_access';
                $editGate = 'sales_returns_edit';
                $deleteGate = 'sales_returns_delete';
                $crudRoutePart = 'sales-returns';

                return view(
                    'layouts.includes.datatablesActions',
                    compact(
                        'viewGate',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });

            $table->rawColumns(['placeholder', 'actions', 'sales_order_code']);

            return $table->make(true);
        }
        return view('salesReturns.index');
    }


    public function create()
    {
        $salesOrders = SalesOrder::filterDb()->availableSO()->get(['code', 'id'])->pluck('code', 'id')->prepend('- Select Sales Order -', null);

        return view('salesReturns.create', ['salesOrders' => $salesOrders]);
    }

    public function store(SalesReturnStoreRequest $request)
    {
        SalesReturnService::store($request);
        alert()->success('Success', 'Data created successfully');
        return to_route('sales-returns.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(SalesReturn $salesReturn)
    {
        $salesReturn->load('details');
        foreach ($salesReturn->details as $detail) {
            $spDetailperProduct = $salesReturn->salesOrder->details()->where('product_id', $detail->product_id)->first(['uom_id']);
            $productUomName = Uom::find($spDetailperProduct->uom_id);
            $detail->uom_name = $productUomName->name;
        }
        $canAddToStock = $salesReturn->details?->every(fn ($detail) => !$detail->stockHistory) ?? true;
        return view('salesReturns.show', ['salesReturn' => $salesReturn, 'canAddToStock' => $canAddToStock]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SalesReturn $salesReturn)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SalesReturn $salesReturn)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SalesReturn $salesReturn)
    {
        try {
            if ($salesReturn == auth()->user()) {
                return $this->ajaxError('Data failed to delete');
            } else {
                $salesReturn->delete();
            }
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    public function addToStock(SalesReturn $salesReturn)
    {
        $databaseConnections = DatabaseConnection::getInstances();
        return view('salesReturns.add-to-stock', ['salesReturn' => $salesReturn, 'databaseConnections' => $databaseConnections]);
    }

    // public function storeToStock(ReceiveOrder $receiveOrder, StoreToStockRequest $request)
    public function storeToStock(SalesReturn $salesReturn, Request $request)
    {
        DB::beginTransaction();
        try {
            foreach ($salesReturn->details as $detail) {
                $stock = Stock::firstWhere('product_id', $detail->product_id);
                // $poDetailperProduct = PurchaseOrderDetail::query()
                //     ->whereHas('purchaseOrder', fn ($query) => $query->where('receive_order_id', $salesReturn->id))
                //     ->where('product_id', $detail->product_id)
                //     ->first();
                $soDetailperProduct = $salesReturn->salesOrder->details()->where('product_id', $detail->product_id)->first(['product_id', 'uom_id']);
                $productUomQty = ProductUom::where('product_id', $soDetailperProduct->product_id)->where('uom_id', $soDetailperProduct->uom_id)->first(['quantity']);

                if ($stock) {
                    $detail->stockHistory()->create([
                        'user_id' => Auth::user()->id,
                        'stock_id' => $stock->id,
                        'is_increment' => 1,
                        'qty' => $detail->qty * $productUomQty->quantity,
                    ]);
                }
            }
            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            return $request->wantsJson()
                ? new JsonResponse(['success' => false, 'message' => $th->getMessage()], 400)
                : to_route('sales-returns.show', $salesReturn);
        }

        return $request->wantsJson()
            ? new JsonResponse(['success' => true, 'message' => 'Success return to stock'], 201)
            : to_route('sales-returns.show', $salesReturn);
    }
}
