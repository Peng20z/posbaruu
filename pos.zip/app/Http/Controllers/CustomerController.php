<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Enums\UserType;
use App\Http\Requests\CustomerStoreRequest;
use App\Imports\CustomersImport;
use App\Models\CustomerGroup;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Yajra\DataTables\Facades\DataTables;

class CustomerController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:customers_access', ['only' => 'index']);
        $this->middleware('permission:customers_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:customers_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:customers_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = User::select(sprintf('%s.*', (new User())->getTable()))->where('type', UserType::CUSTOMER())->with(['customerGroup']);
            $table = DataTables::eloquent($query);

            $table->addColumn('customer_group_name', function ($row) {
                return $row->customerGroup?->name ?? '';
            });
            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $viewGate      = 'customers_access';
                $editGate      = 'customers_edit';
                $deleteGate    = 'customers_delete';
                $crudRoutePart = 'customers';

                return view('layouts.includes.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('customers.index');
    }

    public function show(User $customer)
    {
        return view('customers.show', ['customer' => $customer]);
    }

    public function create()
    {
        $roles = Role::all()->pluck('name', 'id')->prepend('- Select Role -', null);
        $customerGroups = CustomerGroup::all()->pluck('name', 'id')->prepend('- Select Customer Group -', null);
        return view('customers.create', ['roles' => $roles, 'customerGroups' => $customerGroups]);
    }

    public function store(CustomerStoreRequest $request)
    {
        $data = $request->validated();
        $data['type'] = UserType::CUSTOMER;

        DB::transaction(function () use ($request, $data) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $customer = User::on($db->value)->create($data);
                $customer->roles()->sync($request->role_id);
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('customers.index');
    }

    public function edit(User $customer)
    {
        $customer->load('roles');
        $customerRoleId = $customer->roles->count() > 0 ? $customer->roles[0]->id : null;
        $roles = Role::all()->pluck('name', 'id')->prepend('- Select Role -', null);
        $customerGroups = CustomerGroup::all()->pluck('name', 'id')->prepend('- Select Customer Group -', null);
        return view('customers.edit', ['customer' => $customer, 'customerRoleId' => $customerRoleId, 'roles' => $roles, 'customerGroups' => $customerGroups]);
    }

    public function update(CustomerStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $customer = User::on($db->value)->findOrFail($id);
                $customer->update($request->validated());
                $customer->roles()->sync($request->role_id);
            }
        });

        alert()->success('Success', 'Data updated successfully');
        return to_route('customers.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $customer = User::on($db->value)->find($id);
                    if ($customer == auth()->user()) {
                        return $this->ajaxError('Data failed to delete');
                    } else {
                        $customer->delete();
                    }

                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    public function importExcel(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:csv,xls,xlsx'
        ]);

        Excel::import(new CustomersImport, request()->file('file'));

        return to_route('customers.index');
    }
}

