<?php

namespace App\Http\Controllers;

use App\Http\Requests\StockUpdateRequest;
use App\Models\Stock;
use App\Models\StockHistory;
use App\Services\CoreService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\Facades\DataTables;

class StockController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:stocks_access', ['only' => 'index']);
        $this->middleware('permission:stocks_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:stocks_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:stocks_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            if ($request->minimum_stock == 'white') {
                $query = Stock::select(sprintf('%s.*', (new Stock())->table))->with('product')->join('products', function ($join) {
                    $join->on('products.id', '=', 'stocks.product_id');
                    $join->where(function ($q) {
                        $q->where('products.min_stock_reminder', '<=', 'stocks.qty');
                        $q->orWhereNull('products.min_stock_reminder');
                    });
                });
            } elseif ($request->minimum_stock == 'red') {
                $query = Stock::select(sprintf('%s.*', (new Stock())->table))->with('product')->join('products', function ($join) {
                    $join->on('products.id', '=', 'stocks.product_id');
                    $join->on('stocks.qty', '<', 'products.min_stock_reminder');
                });
            } else {
                $query = Stock::select(sprintf('%s.*', (new Stock())->table))->with('product');
            }
            $table = Datatables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('product_code', fn ($row) => $row->product?->id ?? '');
            $table->addColumn('product_name', fn ($row) => $row->product?->name ?? '');
            $table->addColumn('default_uom', fn ($row) => $row->product?->defaultUom?->name ?? '');
            $table->addColumn('default_qty', fn ($row) => floor($row->qty / $row->product->uoms()->where('uom_id', $row->product->default_uom_id)->first()->pivot->quantity));
            $table->addColumn('base_uom', fn ($row) => $row->product?->baseUom?->name ?? '');
            $table->addColumn('base_qty', fn ($row) => $row->qty % $row->product->uoms()->where('uom_id', $row->product->default_uom_id)->first()->pivot->quantity);
            $table->editColumn('actions', function ($row) {
                $extraActions  = '<a class="btn btn-sm btn-success" href="' . route('products.uoms.index', $row->product->id) . '">Product Uom</a>';
                $extraActions .= ' <a class="btn btn-sm btn-info" href="' . route('stocks.histories', $row->id) . '">History</a>';
                $extraActions .= ' <a class="btn btn-sm btn-warning" href="' . route('stocks.edit', $row->id) . '">Adjust</a>';
                if (CoreService::getCookieDbConnection() == 'mysql_secondary') {
                    $extraActions .= ' <a class="btn btn-sm btn-secondary" href="' . route('stocks.move', $row->id) . '">Move Stock</a>';
                }
                $viewGate      = 'stocks_view';
                $crudRoutePart = 'stocks';

                return view('layouts.includes.datatablesActions', compact(
                    'extraActions',
                    'viewGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('stocks.index');
    }

    public function histories(Stock $stock)
    {
        $stock->load(['product', 'histories' => fn($q) => $q->orderByDesc('created_at')]);

        return view('stocks.history', ['stock' => $stock]);
    }

    public function show(Stock $stock)
    {
        return view('stocks.show', ['stock' => $stock]);
    }

    public function edit(Stock $stock)
    {
        return view('stocks.edit', ['stock' => $stock]);
    }

    public function update(Stock $stock, StockUpdateRequest $request)
    {
        StockHistory::create([
            'user_id' => Auth::user()->id,
            'stock_id' => $stock->id,
            'model_type' => 'App\Models\Stock',
            'model_id' => $stock->id,
            'is_increment' => ($request->changes == 'increase') ? true : false,
            'qty' => $request->amount,
            'description' => 'Stock Edit Changes'
        ]);

        alert()->success('Success', 'Data updated successfully');
        return to_route('stocks.index');
    }

    public function move(Stock $stock)
    {
        $stock1 = Stock::on('mysql')->find($stock->id);
        $stock2 = Stock::on('mysql_secondary')->find($stock->id);

        return view('stocks.move', ['stock1' => $stock1, 'stock2' => $stock2]);
    }

    public function updateMove(Stock $stock, Request $request)
    {
        StockHistory::on('mysql')->create([
            'user_id' => Auth::user()->id,
            'stock_id' => $stock->id,
            'model_type' => 'App\Models\Stock',
            'model_id' => $stock->id,
            'is_increment' => ($request->stock1 > 0) ? true : false,
            'qty' => str_replace('-', '', $request->stock1),
        ]);

        StockHistory::on('mysql_secondary')->create([
            'user_id' => Auth::user()->id,
            'stock_id' => $stock->id,
            'model_type' => 'App\Models\Stock',
            'model_id' => $stock->id,
            'is_increment' => ($request->stock2 > 0) ? true : false,
            'qty' => str_replace('-', '', $request->stock2),
        ]);

        return to_route('stocks.index');
    }
}
