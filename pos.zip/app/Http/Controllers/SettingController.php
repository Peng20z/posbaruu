<?php

namespace App\Http\Controllers;

use App\Http\Requests\SettingStoreRequest;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:settings_access', ['only' => 'index']);
        $this->middleware('permission:settings_edit', ['only' => 'update']);
    }

    public function index(Request $request)
    {
        $settings = Setting::all();
        return view('settings.index', ['settings' => $settings]);
    }

    public function update(SettingStoreRequest $request, Setting $setting)
    {
        ($setting->value == 'true' ? $setting->value = true : ($setting->value == 'false' ? $setting->value = false : $setting->value));
        $setting->value = $request->value;
        $setting->save();

        alert()->success('Success', 'Data updated successfully');
        return to_route('settings.index');
    }
}
