<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\SupplierStoreRequest;
use App\Imports\SuppliersImport;
use App\Models\Supplier;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class SupplierController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        if (request()->ajax()) {
            $suppliers = Supplier::query();
            return DataTables::eloquent($suppliers)
                ->editColumn('created_at', function ($row) {
                    return date('d-m-Y H:i', strtotime($row->created_at));
                })
                ->addColumn('actions', function ($row) {
                    $extraActions = '';
                    $editGate      = 'supplier_edit';
                    $deleteGate    = 'supplier_delete';
                    $crudRoutePart = 'suppliers';

                    return view('layouts.includes.datatablesActions', compact(
                        'extraActions',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    ));
                })
                ->rawColumns(['actions'])
                ->make(true);
        }
        return view('suppliers.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('suppliers.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(SupplierStoreRequest $request)
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                Supplier::on($db->value)->create($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('suppliers.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Supplier $supplier)
    {
        return view('suppliers.edit', ['supplier' => $supplier]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(SupplierStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $supplier = Supplier::on($db->value)->findOrFail($id);
                $supplier->update($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('suppliers.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $supplier = Supplier::on($db->value)->find($id);
                    $supplier->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    public function importExcel(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:csv,xls,xlsx'
        ]);

        Excel::import(new SuppliersImport, request()->file('file'));

        return to_route('suppliers.index');
    }
}
