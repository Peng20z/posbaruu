<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Http\Requests\ProductCategoryStoreRequest;
use App\Http\Requests\ProductCategoryUpdateRequest;
use App\Models\ProductCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class ProductCategoryController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:product_categories_access', ['only' => 'index']);
        $this->middleware('permission:product_categories_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:product_categories_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:product_categories_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = ProductCategory::query();
            $table = DataTables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $editGate = 'product_categories_edit';
                $deleteGate = 'product_categories_delete';
                $crudRoutePart = 'product-categories';

                return view(
                    'layouts.includes.datatablesActions',
                    compact(
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('productCategories.index');
    }

    public function show(ProductCategory $productCategory)
    {
        return view('productCategories.show', ['productCategory' => $productCategory]);
    }

    public function create(Request $request)
    {
        return view('productCategories.create');
    }

    public function store(ProductCategoryStoreRequest $request)
    {
        DB::transaction(function () use ($request) {
            foreach (DatabaseConnection::getInstances() as $db) {
                ProductCategory::on($db->value)->create($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('product-categories.index');
    }

    public function edit(ProductCategory $productCategory)
    {
        return view('productCategories.edit', ['productCategory' => $productCategory]);
    }

    public function update(ProductCategoryUpdateRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $productCategory = ProductCategory::on($db->value)->findOrFail($id);
                $productCategory->update($request->validated());
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('product-categories.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $productCategory = ProductCategory::on($db->value)->find($id);
                    $productCategory->delete();
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
