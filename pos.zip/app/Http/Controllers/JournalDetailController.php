<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JournalDetailController extends Controller
{
    //
}
