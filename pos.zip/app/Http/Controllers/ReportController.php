<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Supplier;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function salesOrders()
    {
        return view('reports.salesOrders.index');
    }

    public function penjualanPerBarang(Request $request)
    {
        $filter = [];
        $filter['start_date'] = date('Y-m-01');
        $filter['end_date'] = date('Y-m-t');
        $filter['code'] = $request->code ?? null;
        $filter['has_so'] = $request->boolean('has_so');
        $filter['product_ids'] = $request->product_ids && is_array($request->product_ids) && count($request->product_ids) > 0 ? $request->product_ids : [];

        $products = Product::with('salesOrderDetails.salesOrder');
        if ($filter['code']) {
            $products->whereHas('salesOrderDetails.salesOrder', fn($q) => $q->where('code', $filter['code']));
        }

        if ($filter['has_so']) {
            $products->has('salesOrderDetails.salesOrder');
        }

        if (count($filter['product_ids']) > 0) {
            $filter['selected_products'] = Product::whereIn('id', $filter['product_ids'])->get(['id', 'name'])->pluck('name', 'id');
            $products->whereIn('id', $request->product_ids ?? []);
        }

        if ($request->date_range) {
            list($startDate, $endDate) = explode(' - ', $request->date_range);
            $filter['start_date'] = date('Y-m-d', strtotime($startDate));
            $filter['end_date'] = date('Y-m-d', strtotime($endDate));
        }

        $products = $products->whereHas('salesOrderDetails.salesOrder', fn($q) => $q->transactionDatetimeRange($filter['start_date'], $filter['end_date']))->get();

        if ($request->is_download_pdf == 1) {
            $pdf = \Pdf::loadView('pdf.reports.salesOrders.penjualanPerBarang', ['products' => $products, 'filter' => $filter])->setPaper('a4', 'potrait');
            return $pdf->download('penjualan-per-barang.pdf');
        }

        return view('reports.salesOrders.penjualanPerBarang', ['products' => $products, 'filter' => $filter]);
    }

    public function purchaseOrders()
    {
        return view('reports.purchaseOrders.index');
    }

    public function pembelianPerBarang(Request $request)
    {
        $filter = [];
        $filter['start_date'] = date('Y-m-01');
        $filter['end_date'] = date('Y-m-t');
        $filter['code'] = $request->code ?? null;
        $filter['has_po'] = $request->boolean('has_po');
        $filter['product_ids'] = $request->product_ids && is_array($request->product_ids) && count($request->product_ids) > 0 ? $request->product_ids : [];
        $filter['supplier_ids'] = $request->supplier_ids && is_array($request->supplier_ids) && count($request->supplier_ids) > 0 ? $request->supplier_ids : [];

        $products = Product::with('purchaseOrderDetails.purchaseOrder.supplier');
        if ($filter['code']) {
            $products->whereHas('purchaseOrderDetails.purchaseOrder', fn($q) => $q->where('code', $filter['code']));
        }

        if ($filter['has_po']) {
            $products->has('purchaseOrderDetails.purchaseOrder');
        }

        if (count($filter['product_ids']) > 0) {
            $filter['selected_products'] = Product::whereIn('id', $filter['product_ids'])->get(['id', 'name'])->pluck('name', 'id');
            $products->whereIn('id', $request->product_ids ?? []);
        }

        if (count($filter['supplier_ids']) > 0) {
            $filter['selected_suppliers'] = Supplier::whereIn('id', $filter['supplier_ids'])->get(['id', 'name'])->pluck('name', 'id');
            $products->whereHas('purchaseOrderDetails.purchaseOrder', fn($q) => $q->where('supplier_id',$request->supplier_ids ?? []));
        }

        if ($request->date_range) {
            list($startDate, $endDate) = explode(' - ', $request->date_range);
            $filter['start_date'] = date('Y-m-d', strtotime($startDate));
            $filter['end_date'] = date('Y-m-d', strtotime($endDate));
        }

        $products = $products->whereHas('purchaseOrderDetails.purchaseOrder', fn($q) => $q->createdDateRange($filter['start_date'], $filter['end_date']))->get();

        if ($request->is_download_pdf == 1) {
            $pdf = \Pdf::loadView('pdf.reports.purchaseOrders.pembelianPerBarang', ['products' => $products, 'filter' => $filter])->setPaper('a4', 'potrait');
            return $pdf->download('pembelian-per-barang.pdf');
        }

        return view('reports.purchaseOrders.pembelianPerBarang', ['products' => $products, 'filter' => $filter]);
    }
}
