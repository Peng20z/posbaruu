<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Enums\SettingEnum;
use App\Http\Requests\ReceiveOrderStoreRequest;
use App\Models\ProductUom;
use App\Models\PurchaseOrder;
use App\Models\ReceiveOrder;
use App\Models\Stock;
use App\Models\Uom;
use App\Services\ReceiveOrderService;
use App\Services\SettingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class ReceiveOrderController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:receive_orders_access', ['only' => 'index']);
        $this->middleware('permission:receive_orders_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:receive_orders_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:receive_orders_delete', ['only' => ['destroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = ReceiveOrder::select(sprintf('%s.*', (new ReceiveOrder())->table))->with(['user', 'purchaseOrder']);
            $table = Datatables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->addColumn('user_name', fn ($row) => $row->user?->name ?? '');
            $table->addColumn('purchase_order_code', function ($row) {
                if ($row->purchaseOrder) {
                    return '<a href="' . route('purchase-orders.show', $row->purchaseOrder) . '" target="_blank">' . $row->purchaseOrder?->code . ' <i class="fa fa-link"></i></a>';
                }
                return '';
            });
            $table->addColumn('is_completed', function ($row){
                $isCompleted = true;

                foreach ($row->details as $detail) {
                    $detail->stockHistory ?? $isCompleted = false;
                }

                if ($isCompleted) {
                    $html = '<span class="badge badge-success">COMPLETED</span>';
                }else{
                    $html = '<span class="badge badge-secondary">PROCESS</span>';
                }
                return $html;
            });
            $table->editColumn('total_price', function ($row){
                return rupiah($row->total_price, true);
            });
            $table->editColumn('actions', function ($row) {
                $viewGate = 'receive_orders_access';
                $editGate = 'receive_orders_edit';
                $deleteGate = 'receive_orders_delete';
                $crudRoutePart = 'receive-orders';

                return view(
                    'layouts.includes.datatablesActions',
                    compact(
                        'viewGate',
                        'editGate',
                        'deleteGate',
                        'crudRoutePart',
                        'row'
                    )
                );
            });

            $table->rawColumns(['placeholder', 'actions', 'purchase_order_code', 'is_completed']);

            return $table->make(true);
        }
        return view('receiveOrders.index');
    }

    public function show(ReceiveOrder $receiveOrder)
    {
        $receiveOrder->load('details');
        foreach ($receiveOrder->details as $detail) {
            $poDetailperProduct = $receiveOrder->purchaseOrder->details()->where('product_id', $detail->product_id)->first(['uom_id']);
            $productUomName = Uom::find($poDetailperProduct->uom_id);
            $detail->uom_name = $productUomName->name;
        }
        $canAddToStock = $receiveOrder->details?->every(fn ($detail) => !$detail->stockHistory) ?? true;
        return view('receiveOrders.show', ['receiveOrder' => $receiveOrder, 'canAddToStock' => $canAddToStock]);
    }

    public function create()
    {
        $purchaseOrders = PurchaseOrder::filterDb()->availablePO()->get(['code', 'id'])->pluck('code', 'id')->prepend('- Select Purchase Order -', null);
        $code = SettingService::getCurrentValue(SettingEnum::RO_NUMBER);
        return view('receiveOrders.create', ['purchaseOrders' => $purchaseOrders, 'code' => $code]);
    }

    public function store(ReceiveOrderStoreRequest $request)
    {
        ReceiveOrderService::store($request);
        alert()->success('Success', 'Data created successfully');
        return to_route('receive-orders.index');
    }

    public function edit(ReceiveOrder $receiveOrder)
    {
        return view('receiveOrders.edit', ['receiveOrder' => $receiveOrder]);
    }

    public function update(ReceiveOrder $receiveOrder, ReceiveOrderStoreRequest $request)
    {
        $receiveOrder->update($request->validated());
        $receiveOrder->roles()->sync($request->role_id);

        alert()->success('Success', 'Data updated successfully');
        return to_route('receive-orders.index');
    }

    public function destroy(ReceiveOrder $receiveOrder)
    {
        try {
            if ($receiveOrder == auth()->user()) {
                return $this->ajaxError('Data failed to delete');
            } else {
                $receiveOrder->delete();
            }
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }

    public function addToStock(ReceiveOrder $receiveOrder)
    {
        $databaseConnections = DatabaseConnection::getInstances();
        return view('receiveOrders.add-to-stock', ['receiveOrder' => $receiveOrder, 'databaseConnections' => $databaseConnections]);
    }

    // public function storeToStock(ReceiveOrder $receiveOrder, StoreToStockRequest $request)
    public function storeToStock(ReceiveOrder $receiveOrder, Request $request)
    {
        DB::beginTransaction();
        try {
            foreach ($receiveOrder->details as $detail) {
                $stock = Stock::firstWhere('product_id', $detail->product_id);

                // $poDetailperProduct = PurchaseOrderDetail::query()
                //     ->whereHas('purchaseOrder', fn ($query) => $query->where('receive_order_id', $receiveOrder->id))
                //     ->where('product_id', $detail->product_id)
                //     ->first();
                $poDetailperProduct = $receiveOrder->purchaseOrder->details()->where('product_id', $detail->product_id)->first(['product_id', 'uom_id']);
                $productUomQty = ProductUom::where('product_id', $poDetailperProduct->product_id)->where('uom_id', $poDetailperProduct->uom_id)->first(['quantity']);

                if ($stock) {
                    $detail->stockHistory()->create([
                        'user_id' => Auth::user()->id,
                        'stock_id' => $stock->id,
                        'is_increment' => 1,
                        'qty' => $detail->qty * $productUomQty->quantity,
                    ]);
                }
            }
            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            return $request->wantsJson()
                ? new JsonResponse(['success' => false, 'message' => $th->getMessage()], 400)
                : to_route('receive-orders.show', $receiveOrder);
        }

        return $request->wantsJson()
            ? new JsonResponse(['success' => true, 'message' => 'Success add to stock'], 201)
            : to_route('receive-orders.show', $receiveOrder);
    }
}
