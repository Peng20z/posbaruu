<?php

namespace App\Http\Controllers;

use App\Enums\DatabaseConnection;
use App\Enums\UserType;
use App\Http\Requests\UserStoreRequest;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class UserController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:users_access', ['only' => 'index']);
        $this->middleware('permission:users_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:users_edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:users_delete', ['only' => ['destroy', 'massDestroy']]);
    }

    public function index(Request $request)
    {
        if ($request->ajax()) {
            $query = User::where('type', UserType::USER);
            $table = Datatables::eloquent($query);

            $table->addColumn('placeholder', '&nbsp;');
            $table->editColumn('actions', function ($row) {
                $viewGate      = 'users_access';
                $editGate      = 'users_edit';
                $deleteGate    = 'users_delete';
                $crudRoutePart = 'users';

                return view('layouts.includes.datatablesActions', compact(
                    'viewGate',
                    'editGate',
                    'deleteGate',
                    'crudRoutePart',
                    'row'
                ));
            });

            $table->rawColumns(['placeholder', 'actions']);

            return $table->make(true);
        }
        return view('users.index');
    }

    public function show(User $user)
    {
        return view('users.show', ['user' => $user]);
    }

    public function create(Request $request)
    {
        $roles = Role::all()->pluck('name', 'id')->prepend('- Select Role -', null);
        return view('users.create', ['roles' => $roles]);
    }

    public function store(UserStoreRequest $request)
    {
        $data = $request->validated();
        $data['type'] = UserType::USER;

        DB::transaction(function () use ($request, $data) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $user = User::on($db->value)->create($data);
                $user->roles()->sync($request->role_id);
            }
        });

        alert()->success('Success', 'Data created successfully');
        return to_route('users.index');
    }

    public function edit(User $user)
    {
        $user->load('roles');
        $userRoleId = $user->roles->count() > 0 ? $user->roles[0]->id : null;
        $roles = Role::all()->pluck('name', 'id')->prepend('- Select Role -', null);
        return view('users.edit', ['user' => $user, 'userRoleId' => $userRoleId, 'roles' => $roles]);
    }

    public function update(UserStoreRequest $request, $id)
    {
        DB::transaction(function () use ($request, $id) {
            foreach (DatabaseConnection::getInstances() as $db) {
                $user = User::on($db->value)->findOrFail($id);
                $user->update($request->validated());
                $user->roles()->sync($request->role_id);
            }
        });
        alert()->success('Success', 'Data updated successfully');
        return to_route('users.index');
    }

    public function destroy($id)
    {
        try {
            DB::transaction(function () use ($id) {
                foreach (DatabaseConnection::getInstances() as $db) {
                    $user = User::on($db->value)->find($id);
                    if ($user == auth()->user()) {
                        return $this->ajaxError('Data failed to delete');
                    } else {
                        $user->delete();
                    }
                }
            });
        } catch (\Exception $e) {
            return $this->ajaxError($e->getMessage());
        }
        return $this->ajaxSuccess('Data deleted successfully');
    }
}
