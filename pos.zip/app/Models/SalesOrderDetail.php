<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\MorphOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Crypt;

class SalesOrderDetail extends BaseModel
{
    public $table = 'sales_order_details';

    protected $guarded = [];

    protected $appends = ['code_decrypt'];

    public static function boot()
    {
        parent::boot();
        self::deleting(function (self $model) {
            // Stock::where('product_id', $model->product_id)->increment('qty', $model->stockHistory->qty);
            // $model->stockHistory->delete();
        });
    }

    public function salesOrder(): BelongsTo
    {
        return $this->belongsTo(SalesOrder::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function stockHistory(): MorphOne
    {
        return $this->morphOne(StockHistory::class, 'model');
    }

    public function uom(): BelongsTo
    {
        return $this->belongsTo(Uom::class);
    }

    protected function codeDecrypt(): Attribute
    {
        return new Attribute(
            get: fn () => Crypt::decrypt($this->code),
        );
    }
}
