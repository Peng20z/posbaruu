<?php

namespace App\Models;

use App\Services\ReceiveOrderService;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ReceiveOrder extends BaseModel
{
    public $table = 'receive_orders';

    protected $fillable = [
        'user_id',
        'purchase_order_id',
        'code',
        'total_price',
        'description',
        'received_at',
    ];

    protected static function booted(): void
    {
        static::saving(function (self $model) {
            $model->user_id = auth()->user()->id;
        });

        static::created(function (self $model) {
            if (empty($model->code)) $model->update(['code' => ReceiveOrderService::getCode($model->connection)]);
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function purchaseOrder(): BelongsTo
    {
        return $this->belongsTo(PurchaseOrder::class);
    }

    public function details(): HasMany
    {
        return $this->hasMany(ReceiveOrderDetail::class);
    }

    // public static function createReceiveOrderDetails(self $model): void
    // {
    //     $purchaseOrderDetails = $model->purchaseOrder?->details ?? collect([]);
    //     $purchaseOrderDetails->each(function ($detail) use ($model) {
    //         $model->details()->create([
    //             'product_id' => $detail->product_id,
    //             'qty' => $detail->qty,
    //             'unit_price' => $detail->unit_price,
    //             'total_price' => $detail->total_price,
    //         ]);
    //     });

    //     $model->update([
    //         'total_price' => $model->details->sum('total_price')
    //     ]);
    // }
}
