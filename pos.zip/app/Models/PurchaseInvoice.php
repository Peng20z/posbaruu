<?php

namespace App\Models;

use App\Enums\DatabaseConnection;
use App\Enums\PaymentStatus;
use App\Services\PurchaseInvoiceService;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

class PurchaseInvoice extends BaseModel
{
    use SoftDeletes;

    public $table = 'purchase_invoices';

    protected $guarded = [];

    protected $casts = [
        'amount' => 'float',
        'status' => PaymentStatus::class,
    ];

    public static function booted(): void
    {
        static::saving(function ($model) {
            if (empty($model->user_id))
                $model->user_id = auth()->user()?->id;
        });

        static::saved(function ($model) {
            PurchaseInvoiceService::refreshPayment($model);
        });

        static::deleted(function ($model) {
            if ($model->status->is(PaymentStatus::APPROVED)) {
                $purchaseOrder = $model->purchaseOrder;
                $purchaseOrder->total_paid -= $model->amount;
                $purchaseOrder->save();
            }
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function purchaseOrder(): BelongsTo
    {
        return $this->belongsTo(PurchaseOrder::class, 'purchase_order_id', 'code');
    }

    public function scopeWhereApproved(Builder $query)
    {
        $query->where('status', PaymentStatus::APPROVED);
    }
}
