<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CustomerGroupProduct extends BaseModel
{
    public $table = 'customer_group_products';

    protected $fillable = [
        'customer_group_id',
        'product_id',
        'uom_id',
        'sell_price',
        'discounts',
    ];


    protected $casts = [
        'sell_price' => 'float',
        'discounts' => 'array',
    ];

    public function customerGroup(): BelongsTo
    {
        return $this->belongsTo(CustomerGroup::class);
    }

    public function uom(): BelongsTo
    {
        return $this->belongsTo(Uom::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
