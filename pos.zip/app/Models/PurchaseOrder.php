<?php

namespace App\Models;

use App\Enums\POStatus;
use App\Enums\POTerms;
use App\Http\Controllers\ProductController;
use App\Services\PurchaseOrderService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class PurchaseOrder extends BaseModel
{
    public $table = 'purchase_orders';

    protected $fillable = [
        'user_id',
        'supplier_id',
        'code',
        'po_number',
        'terms',
        'additional_discount',
        'total_price',
        'description',
        'status',
    ];

    protected $casts = [
        'status' => POStatus::class,
        'terms' => POTerms::class,
    ];

    protected static function booted(): void
    {
        static::creating(function (self $model) {
            $model->user_id = auth()->user()->id;
            $model->status = POStatus::PROCESS;
        });

        static::created(function (self $model) {
            if (empty($model->code)) $model->update(['code' => PurchaseOrderService::getCode($model->connection)]);
        });

        static::deleted(function ($model) {
            $details = PurchaseOrderDetail::where('purchase_order_id', $model->id)->get();
            if (count($details) > 0) {
                foreach ($details as $detail) {
                    $detail->delete();
                    ProductController::recalculateCapital($detail->product);
                }
            }
        });
    }

    public function receiveOrder(): HasMany
    {
        return $this->hasMany(ReceiveOrder::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class);
    }

    public function details(): HasMany
    {
        return $this->hasMany(PurchaseOrderDetail::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(PurchaseInvoice::class, 'purchase_order_id', 'code');
    }

    public function scopeFilterDb(Builder $query): void
    {
        if ($query->getConnection()->getConfig()['database'] === env('DB_SECONDARY_DATABASE', 'anonymous_secondary')) {
            $query->where('code', 'not like', '%AA%');
        }
    }

    public function scopeDoesntHaveRo(Builder $query): void
    {
        $query->doesntHave('receiveOrder');
    }

    public function scopeAvailablePO(Builder $query): void
    {
        $query->where('status', 'process')->orWhere('status', 'partial');
    }

    public function scopeCreatedDateRange(Builder $query, $startDate = null, $endDate = null): void
    {
        if (!is_null($startDate)) {
            $query->whereDate('purchase_orders.created_at', '>=', date('Y-m-d', strtotime($startDate)));
        }

        if (!is_null($startDate)) {
            $query->whereDate('purchase_orders.created_at', '<=', date('Y-m-d', strtotime($endDate)));
        }
    }

    public function scopeWhereNotPaid(Builder $query)
    {
        $query->whereRaw('total_paid < total_price');
    }
}
