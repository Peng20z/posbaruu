<?php

namespace App\Models;

class ProductCategory extends BaseModel
{
    public $table = 'product_categories';

    protected $guarded = [];
}
