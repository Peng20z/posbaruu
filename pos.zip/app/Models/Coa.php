<?php

namespace App\Models;

use App\Enums\NormalBalance;
use App\Traits\CustomSoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Coa extends BaseModel
{
    use CustomSoftDeletes;

    protected $fillable = [
        'parent_id',
        'account_number',
        'account_name',
        'normal_balance',
    ];

    protected $append = [
        'name',
    ];

    protected $casts = [
        'normal_balance' => NormalBalance::class
    ];

    public static function booted(): void
    {
        static::saving(function (self $model) {
            if (empty($model->normal_balance) && $model->parent) {
                $model->normal_balance = $model->parent->normal_balance;
            }
        });
    }

    public function getNameAttribute(): string
    {
        return $this->account_number . ' : ' . $this->account_name;
    }

    public static function getChildsSelections(array $parentIds = [], callable $closure = null)
    {
        $query = self::selectRaw('id, CONCAT(account_number," : ",account_name) as account_name')->whereNotNull('parent_id');

        if (!is_null($closure)) {
            $query = $closure($query);
        }

        if (count($parentIds) > 0) {
            $query->whereIn('parent_id', $parentIds);
        }

        // if ($tenantId) {
        //     $query->orWhere('tenant_id', $tenantId);
        // }

        return $query->pluck('account_name', 'id');
    }

    public function childs(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id', 'id');
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id', 'id');
    }
}
