<?php

namespace App\Models;

use App\Traits\BelongsToUser;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Journal extends BaseModel
{
    use BelongsToUser;

    protected $fillable = [
        'user_id',
        'code',
        'transaction_date',
        'description',
    ];

    protected $appends = [
        'total_amount',
    ];

    public static function booted(): void
    {
        static::creating(function (self $model) {
            if (empty($model->user_id)) $model->user_id = auth()->id();
        });
    }

    public function getTotalAmountAttribute()
    {
        return $this->details->sum('debit') ?? 0;
    }

    public function details(): HasMany
    {
        return $this->hasMany(JournalDetail::class);
    }

    public function scopeTransactionDateRange(Builder $query, $startDate = null, $endDate = null): void
    {
        if (!is_null($startDate)) {
            $query->whereDate('journals.transaction_date', '>=', date('Y-m-d', strtotime($startDate)));
        }

        if (!is_null($startDate)) {
            $query->whereDate('journals.transaction_date', '<=', date('Y-m-d', strtotime($endDate)));
        }
    }
}
