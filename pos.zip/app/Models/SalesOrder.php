<?php

namespace App\Models;

use App\Services\SalesOrderService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class SalesOrder extends BaseModel
{
    use SoftDeletes;

    public $table = 'sales_orders';

    protected $fillable = [
        'user_id',
        'customer_id',
        'code',
        'additional_discount',
        'total_price',
        'description',
        'transaction_datetime',
    ];

    protected static function booted(): void
    {
        static::saving(function (self $model) {
            $model->user_id = auth()->user()->id;
        });

        static::created(function (self $model) {
            if (empty($model->code))
                $model->update(['code' => SalesOrderService::getCode($model->connection)]);
        });
    }

    public function details(): HasMany
    {
        return $this->hasMany(SalesOrderDetail::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id', 'id');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class, 'sales_order_id', 'code');
    }

    public function salesReturn(): HasOne
    {
        return $this->hasOne(SalesReturn::class);
    }

    public function scopeFilterDb(Builder $query): void
    {
        if ($query->getConnection()->getConfig()['database'] === env('DB_SECONDARY_DATABASE', 'anonymous_secondary')) {
            $query->where('code', 'not like', '%AA%');
        }
    }

    public function scopeWhereNotPaid(Builder $query)
    {
        $query->whereRaw('total_paid < total_price');
    }

    public function scopeAvailableSO(Builder $query): void
    {
        $query->where('created_at', '>=', date('c', strtotime('-30 days')))->doesntHave('salesReturn');
    }

    public function scopeTransactionDatetimeRange(Builder $query, $startDate = null, $endDate = null): void
    {
        if (!is_null($startDate)) {
            $query->whereDate('transaction_datetime', '>=', date('Y-m-d', strtotime($startDate)));
        }

        if (!is_null($startDate)) {
            $query->whereDate('transaction_datetime', '<=', date('Y-m-d', strtotime($endDate)));
        }
    }

    public function scopeCreatedDateRange(Builder $query, $startDate = null, $endDate = null): void
    {
        if (!is_null($startDate)) {
            $query->whereDate('sales_orders.created_at', '>=', date('Y-m-d', strtotime($startDate)));
        }

        if (!is_null($startDate)) {
            $query->whereDate('sales_orders.created_at', '<=', date('Y-m-d', strtotime($endDate)));
        }
    }
}
