<?php

namespace App\Models;

class Setting extends BaseModel
{
}
