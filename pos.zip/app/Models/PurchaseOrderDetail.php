<?php

namespace App\Models;

use App\Services\PurchaseOrderService;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphOne;

class PurchaseOrderDetail extends BaseModel
{
    public $table = 'purchase_order_details';

    protected $guarded = [];

    protected static function booted(): void
    {
        static::saved(function (self $model) {
            PurchaseOrderService::recalculateCapital($model->product);
        });
    }

    public function purchaseOrder(): BelongsTo
    {
        return $this->belongsTo(PurchaseOrder::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function uom(): BelongsTo
    {
        return $this->belongsTo(Uom::class);
    }

    public function stockHistory(): MorphOne
    {
        return $this->morphOne(StockHistory::class, 'model');
    }
}
