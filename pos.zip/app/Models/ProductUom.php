<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\Pivot;

class ProductUom extends Pivot
{
    public $table = 'product_uoms';

    protected $fillable = [
        'product_id',
        'uom_id',
        'buy_price',
        'sell_price',
        'quantity',
        'is_default',
        'is_base',
        'discounts',
    ];

    protected $casts = [
        'quantity' => 'integer',
        'is_default' => 'boolean',
        'discounts' => 'array',
    ];

    public static function booted(): void
    {
        static::creating(function ($model) {
            if(empty($model->quantity)) $model->quantity = 1;
        });
    }

    protected function buyPrice(): Attribute
    {
        return Attribute::make(
            set: fn (string $value) => filterPrice($value),
        );
    }

    protected function sellPrice(): Attribute
    {
        return Attribute::make(
            set: fn (string $value) => filterPrice($value),
        );
    }

    public function uom()
    {
        return $this->belongsTo(Uom::class);
    }
}
