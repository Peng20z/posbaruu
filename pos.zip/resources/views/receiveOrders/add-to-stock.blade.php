@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('receive-orders.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Receive Order</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>ID</th>
                                        <td>{{ $receiveOrder->id }}</td>
                                    </tr>
                                    <tr>
                                        <th>User</th>
                                        <td>{{ $receiveOrder->user?->name ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Purhcase Order</th>
                                        <td>{{ $receiveOrder->purchaseOrder?->code ?? '' }}</td>
                                    </tr>
                                    <tr>
                                        <th>Code</th>
                                        <td>{{ $receiveOrder->code }}</td>
                                    </tr>
                                    <tr>
                                        <th>Total Price</th>
                                        <td>{{ $receiveOrder->total_price }}</td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td>{{ $receiveOrder->description }}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <form method="post" action="{{ route('receive-orders.store-to-stock', $receiveOrder) }}"
                            class="form-loading" @if (!Auth::user()->is_admin) onclick="return confirm('Are you sure you want to add to stock?')" @endif>
                            @csrf
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Receive Order Details</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Product Name</th>
                                                    <th>Uom</th>
                                                    <th>Qty</th>
                                                    @if (Auth::user()->is_admin)
                                                        @foreach ($databaseConnections as $db)
                                                            <th>{{ $db->description }}</th>
                                                        @endforeach
                                                    @else
                                                        <th>{{ $databaseConnections['MYSQL']->description }}</th>
                                                    @endif
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($receiveOrder->details as $detail)
                                                    <tr>
                                                        <td>{{ $detail->product?->name ?? '' }}</td>
                                                        <td>{{ $detail->product?->uom?->name ?? '' }}</td>
                                                        <td>{{ $detail->qty }}</td>
                                                        @if (Auth::user()->is_admin)
                                                            @foreach ($databaseConnections as $db)
                                                                <td>
                                                                    <input
                                                                        name="data[{{ $detail->id }}][{{ $db->value }}]"
                                                                        type="number" value="1" min="0"
                                                                        max="{{ $detail->qty }}" step="1" />
                                                                </td>
                                                            @endforeach
                                                        @else
                                                            <td>
                                                                <input
                                                                    name="data[{{ $detail->id }}][{{ $databaseConnections['MYSQL']->value }}]"
                                                                    type="number" value="1" min="0"
                                                                    max="{{ $detail->qty }}" step="1" />

                                                                    <input
                                                                    name="data[{{ $detail->id }}][{{ $databaseConnections['MYSQL_SECONDARY']->value }}]"
                                                                    type="number" value="0" min="0"
                                                                    max="{{ $detail->qty }}" step="0" hidden/>
                                                            </td>
                                                        @endif
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/bootstrap-input-spinner/bootstrap-input-spinner.js') }}"></script>
    <script>
        $(document).ready(function() {
            $("input[type='number']").inputSpinner();
        });
    </script>
@endpush
