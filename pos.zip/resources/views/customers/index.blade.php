@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('customers_create')
                            <a href="{{ route('customers.create') }}" class="btn btn-success" title="Create"><i
                                    class="fa fa-plus"></i>
                                Add
                                Data</a>
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#mdlImportExcel"><i
                                    class="fa fa-plus"></i> Import Data</button>
                            <div class="modal inmodal fade" id="mdlImportExcel" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <form action="{{ route('customers.import-excel') }}" method="post"
                                            enctype="multipart/form-data" class="form-loading">
                                            @csrf
                                            @method('post')
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="file">Add File</label> <br>
                                                    <input type="file" name="file">
                                                </div>
                                                <button type="submit" class="btn btn-success"><i class="fa fa-paper-plane"></i>
                                                    Submit</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Customers List</h3>
                            </div>
                            <div class="card-body">
                                <table id="customers-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Customer Group</th>
                                            <th>Phone</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script>
        var table = $('#customers-datatable').DataTable({
            processing: true,
            serverSide: true,
            searching: true,
            responsive: true,
            ajax: '{{ route('customers.index') }}',
            columns: [{
                    data: 'code',
                    name: 'code',
                },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'customer_group_name',
                    name: 'customerGroup.name'
                },
                {
                    data: 'phone',
                    name: 'phone'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            orderCellsTop: true,
            order: [
                [0, 'desc']
            ],
            pageLength: 25,
        });

        function deleteData(id) {
            if (confirm('Delete data?')) {
                $.post(`{{ url('customers') }}/` + id, {
                    _method: 'delete'
                }, function(res) {
                    if (res.success) {
                        table.ajax.reload();
                        toastr.success(res.message);
                    } else {
                        toastr.error(res.message);
                    }
                }, 'json');
            }
        }
    </script>
@endpush
