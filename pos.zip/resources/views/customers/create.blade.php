@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('customers.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('customers.store') }}" class="form-loading">
                                @csrf
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Name</label>
                                        <input name="name" type="text" value="{{ old('name') }}"
                                            class="form-control @error('name') is-invalid @enderror" placeholder="Name"
                                            required>
                                        @error('name')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Customer Group</label>
                                        <select name="customer_group_id" id="customer_group_id"
                                            class="form-control select2 @error('customer_group_id') is-invalid @enderror">
                                            @foreach ($customerGroups as $id => $name)
                                                <option value="{{ $id }}">{{ $name }}</option>
                                            @endforeach
                                        </select>
                                        @error('customer_group_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Email</label>
                                        <input name="email" type="email" value="{{ old('email') }}"
                                            class="form-control @error('email') is-invalid @enderror" placeholder="Email"
                                            required>
                                        @error('email')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Password</label>
                                        <input name="password" type="password"
                                            class="form-control @error('password') is-invalid @enderror"
                                            placeholder="Password" required>
                                        @error('password')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Role</label>
                                        <select name="role_id" id="role_id"
                                            class="form-control select2 @error('role_id') is-invalid @enderror" required>
                                            @foreach ($roles as $id => $name)
                                                <option value="{{ $id }}">{{ $name }}</option>
                                            @endforeach
                                        </select>
                                        @error('role_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Address</label>
                                        <input name="address" type="address" value="{{ old('address') }}"
                                            class="form-control @error('address') is-invalid @enderror" placeholder="Address">
                                        @error('address')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Tax Address</label>
                                        <input name="tax_address" type="tax_address" value="{{ old('tax_address') }}"
                                            class="form-control @error('tax_address') is-invalid @enderror" placeholder="Tax Address">
                                        @error('tax_address')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">City</label>
                                        <input name="city" type="city" value="{{ old('city') }}"
                                            class="form-control @error('city') is-invalid @enderror" placeholder="City">
                                        @error('city')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Province</label>
                                        <input name="province" type="province" value="{{ old('province') }}"
                                            class="form-control @error('province') is-invalid @enderror" placeholder="Province">
                                        @error('province')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Zip Code</label>
                                        <input name="zip_code" type="zip_code" value="{{ old('zip_code') }}"
                                            class="form-control @error('zip_code') is-invalid @enderror" placeholder="Zip Code">
                                        @error('zip_code')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Country</label>
                                        <input name="country" type="country" value="{{ old('country') }}"
                                            class="form-control @error('country') is-invalid @enderror" placeholder="Country">
                                        @error('country')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Phone</label>
                                        <input name="phone" type="phone" value="{{ old('phone') }}"
                                            class="form-control @error('phone') is-invalid @enderror" placeholder="Phone">
                                        @error('phone')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Contact Person</label>
                                        <input name="contact_person" type="contact_person" value="{{ old('contact_person') }}"
                                            class="form-control @error('contact_person') is-invalid @enderror" placeholder="Contact Person">
                                        @error('contact_person')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
