@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('sales-returns.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <form method="post" action="{{ route('sales-returns.store') }}" class="form-loading">
                            @csrf
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Sales Return</h3>
                                </div>
                                @csrf
                                <div class="card-body">

                                    <div class="form-group">
                                        <label class="required">Sales Order</label>
                                        <select name="sales_order_id" id="sales_order_id"
                                            class="form-control select2 @error('sales_order_id') is-invalid @enderror"
                                            required>
                                            @foreach ($salesOrders as $id => $code)
                                                <option value="{{ $id }}"
                                                    @if (old('sales_order_id', null) == $id) selected @endif>{{ $code }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('sales_order_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Returned Date</label>
                                        {{-- <div class="input-group date"  data-target-input="nearest"
                                            data-toggle="datetimepicker"> --}}
                                            <input type="text" name="returned_at" id="filter-date"  data-target-input="nearest"
                                                class="form-control datetimepicker-input input-group date" data-target="#filter-date"  data-toggle="datetimepicker">
                                        {{-- </div> --}}
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Description</label>
                                        <textarea name="description" id="description" rows="5" class="form-control">{{ old('description') }}</textarea>
                                        @error('description')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div id="po-table">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            let selectedProductIds = [];

            $('#filter-date').datetimepicker({
                defaultDate: new Date(),
                timePicker: true,
                timePicker24Hour: true,
                format: 'YYYY-MM-DD HH:mm:ss',

                icons: {
                    time: 'far fa-clock'
                }
            });

            $('#product_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Select product',
                ajax: {
                    url: '{{ route('api.products.index') }}',
                    dataType: 'json',
                    delay: 300,
                    data: function(params) {
                        return {
                            'per_page': 30,
                            'select': 'id,name as text', // select2 only accept return data (id and text)
                            'filter[name]': params.term, // search term
                            page: params.page || params.current_page || 1
                        };
                    },
                    processResults: function(data, params) {
                        params.current_page = params.current_page || 1;
                        return {
                            results: data.data,
                            pagination: {
                                more: (params.current_page * 30) < data.total
                            }
                        };
                    },
                    autoWidth: true,
                    cache: true
                }
            });

            $('body').on('click', '.btn-delete', function() {
                $(this).parent().parent().remove();
            });

            $('#sales_order_id').on('change', async function() {
                let salesOrderId = $('#sales_order_id').val();
                $('#po-table').find('div.card').remove();
                if (salesOrderId) {
                    try {
                        let salesOrderDetails = await getSalesOrderDetails(salesOrderId);

                        let salesOrderTableBody = ``;
                        let totalAccumulation = 0;
                        $.each(salesOrderDetails, function(i, detail) {
                            totalAccumulation += detail.qty * detail.unit_price;
                            salesOrderTableBody +=
                                `<tr>
                                <td>${detail.product.name}</td>
                                <td><input type="number" name="items[${i}][qty]" value="${detail.qty}" class="form-control input-detail-qty" data-price="${detail.unit_price}" min="0" max="${detail.qty}"/></td>
                                <td>${detail.uom.name}</td>
                                <td class="price-format">${customToFixed(detail.unit_price)}</td>
                                <td><input value="${customToFixed(detail.qty * detail.unit_price)}" class="form-control price-format input-ro-total-price" min="0" readonly/></td>
                                <td></td>
                            </tr>`

                        });

                        let html = `
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Sales Return Details</h3>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>Product Name</th>
                                                <th>Qty</th>
                                                <th>Uom</th>
                                                <th>Unit Price</th>
                                                <th>Total Price</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            ${salesOrderTableBody}
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="4">Total Price</th>
                                                <th>
                                                    <input value="${customToFixed(totalAccumulation)}" class="form-control price-format" id="total-price-accumulation"
                                                        readonly>
                                                </th>
                                                <th></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>`;
                        $('#po-table').append(html);
                        setTotalPriceAccumulation();

                        initPriceFormat();
                    } catch (error) {
                        toastr.error(error.message);
                    }
                }
            });

            $('body').on('change', '.input-detail-qty', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            async function setTotalPricePerProduct(parent) {
                let qty = parent.find('.input-detail-qty').val();
                let price = parent.find('.input-detail-qty').data('price');
                let totalPrice = price * qty;
                // set total price nya ke total price per product
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                parent.find('.input-ro-total-price').val(customToFixed(totalPrice));

                setTotalPriceAccumulation();
            }

            function setTotalPriceAccumulation() {
                let totalPrice = 0;
                // looping element total price per product, lalu di sum()
                $('.input-ro-total-price').each(function(i) {
                    totalPrice += unformatPrice($(this).val());
                });

                // set total price nya ke total price keseluruhan
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                $('#total-price-accumulation').val(customToFixed(totalPrice));

                initPriceFormat();
            }

            function getProduct(productId) {
                return new Promise((resolve, reject) => {
                    $.get('{{ url('api/products/') }}/' + productId, function(product) {
                        if (product) {
                            resolve(product);
                        } else {
                            reject(new Error('product not found'))
                        }
                    });
                });
            }

            function getSalesOrderDetails(salesOrderId) {
                return new Promise((resolve, reject) => {
                    $.get('{{ url('api/sales-orders/') }}/' + salesOrderId, function(
                        salesOrderId) {
                        if (salesOrderId) {
                            resolve(salesOrderId);
                        } else {
                            reject(new Error('sales order not found'))
                        }
                    });
                });
            }
        });
    </script>
@endpush
