@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('customer_groups_create')
                            <a href="{{ route('customer-groups.products.create', $customerGroup) }}" class="btn btn-success" title="Create"><i class="fa fa-plus"></i>
                                Add
                                Data</a>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">{{$customerGroup->name}} Products List</h3>
                            </div>
                            <div class="card-body">
                                <table id="customer-group-products-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Product</th>
                                            <th>Uom</th>
                                            <th>Sell Price</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script>
        var table = $('#customer-group-products-datatable').DataTable({
            processing: true,
            serverSide: true,
            searching: true,
            responsive: true,
            ajax: '{{ route('customer-groups.products.index', $customerGroup) }}',
            columns: [{
                    data: 'product_id',
                    name: 'product.id',
                },
                {
                    data: 'product_name',
                    name: 'product.name'
                },
                {
                    data: 'uom_name',
                    name: 'uom.name'
                },
                {
                    data: 'sell_price',
                    name: 'sell_price',
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            orderCellsTop: true,
            order: [
                [0, 'desc']
            ],
            pageLength: 25,
        });

        function deleteData(id) {
            if (confirm('Delete data?')) {
                $.post(`{{ url('customer-groups.products') }}/` + id, {
                    _method: 'delete'
                }, function(res) {
                    if (res.success) {
                        table.ajax.reload();
                        toastr.success(res.message);
                    } else {
                        toastr.error(res.message);
                    }
                }, 'json');
            }
        }
    </script>
@endpush
