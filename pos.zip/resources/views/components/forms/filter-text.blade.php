<td class="px-2">
    <input class="search w-100" type="text" placeholder="{{ $placeholder }}">
</td>
