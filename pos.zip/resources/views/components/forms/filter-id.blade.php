<td class="px-2">
    <input class="search w-100" type="text" strict="true" placeholder="{{ $placeholder }}">
</td>
