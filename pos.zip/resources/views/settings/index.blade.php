@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Settings List</h3>
                            </div>
                            <div class="card-body">
                                <table id="settings-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Key</th>
                                            <th>Value</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($settings as $setting)
                                            <form action="{{ route('settings.update', $setting) }}" method="post">
                                                @csrf
                                                @method('PUT')
                                                @if ($setting->key == 'po_number')
                                                    @continue;
                                                @endif
                                                <tr>
                                                    <td>{{ $setting->id }}</td>
                                                    <td>{{ $setting->key }}</td>
                                                    <td>
                                                        <input type="text" name="value" class="form-control"
                                                            value="{{ $setting->value == 1 ? 'true' : ($setting->value == 0 ? 'false' : $setting->value) }}">
                                                    </td>
                                                    <td>
                                                        <button type="submit" class="btn btn-success btn-sm"><i
                                                                class="fa fa-save"></i> Update</button>
                                                    </td>
                                                </tr>
                                            </form>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
