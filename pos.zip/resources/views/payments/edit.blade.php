@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('payments.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('payments.update', $payment) }}" class="form-loading">
                                @csrf
                                @method('PUT')
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Sales Order</label>
                                        <input type="text" name="sales_order_id" readonly
                                            value="{{ $payment->salesOrder->code }}" required class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Code</label>
                                        <input name="code" id="code" type="text"
                                            class="form-control @error('code') is-invalid @enderror"
                                            value="{{ $payment->code }}" placeholder="code" required>
                                        @error('code')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Payment Type</label>
                                        <select name="payment_type_id" id="payment_type_id"
                                            class="form-control select2 @error('payment_type_id') is-invalid @enderror"
                                            required>
                                            @foreach ($paymentTypes as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('payment_type_id', $payment->payment_type_id) == $id) selected @endif>
                                                    {{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('payment_type_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Unpaid Payment</label>
                                        <input id=payment_left type="text" class="form-control price-format"
                                            value="{{ rupiah($payment->salesOrder->total_price - ($payment->salesOrder->total_paid - $payment->amount)) }}"
                                            placeholder="Payment Left" disabled readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Amount</label>
                                        <input name="amount" type="text"
                                            value="{{ rupiah($payment->amount) }}"
                                            class="form-control price-format @error('amount') is-invalid @enderror"
                                            placeholder="amount" required>
                                        @error('amount')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Status</label>
                                        <select name="status" id="status"
                                            class="form-control select2 @error('status') is-invalid @enderror" required>
                                            @foreach ($paymentStatuses as $paymentStatus)
                                                <option value="{{ $paymentStatus->value }}"
                                                    @if ($payment->status->value == $paymentStatus->value) selected @endif>
                                                    {{ $paymentStatus->description }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('status')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control @error('payment_description') is-invalid @enderror" rows="5" placeholder="Description">{{ $payment->description }}</textarea>
                                        @error('description')
                                            <span class="form-text m-b-none text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            initPriceFormat();

            $('body').on('change', '#sales_order_id', async function() {
                let salesOrder = await getUnpaid($(this).val());
                let amount = customToFixed(salesOrder.total_price - salesOrder.total_paid)

                $('#amount').val(amount);
                $('#payment_left').val(amount);
                
                initPriceFormat();
            });
        });

        function getUnpaid(id) {
            return new Promise((resolve, reject) => {
                $.get('{{ url('api/sales-orders/get-unpaid') }}/' + id,
                    function(res) {
                        if (res) {
                            resolve(res);
                        } else {
                            reject(new Error('Sales Order not found'))
                        }
                    });
            });
        }
    </script>
@endpush
