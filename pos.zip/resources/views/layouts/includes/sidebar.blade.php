<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="../index3.html" class="brand-link">
        <img src="{{asset('image/POS Logo Medicine-02.png')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
            style="opacity: 0.8" />
        <span class="brand-text font-weight-light">POS</span>
    </a>

    <div class="sidebar">
        @if (\App\Services\CoreService::hasAdminCookie())
            <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                <form method="post" action="{{ route('change_database_connection') }}" id="change-database">
                    @csrf
                    <div class="form-group">
                        <select name="database_connection" class="form-control"
                            onchange="document.getElementById('change-database').submit();">
                            @foreach (\App\Enums\DatabaseConnection::getInstances() as $db)
                                <option value="{{ $db->value }}" @if (\App\Services\CoreService::getCookieDbConnection() == $db->value) selected @endif>
                                    {{ $db->description }}</option>
                            @endforeach
                        </select>
                    </div>
                </form>
            </div>
        @endif

        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                @can('dashboard_access')
                    <li class="nav-item">
                        <a href="{{ route('home') }}" class="nav-link">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Dashboard
                            </p>
                        </a>
                    </li>
                @endcan
                @foreach (\App\Services\MenuService::menu() as $menu)
                    @can($menu->permission)
                        @if (count($menu->submenus) > 1)
                            <li
                                class="nav-item has-treeview {{ request()->is($menu->getAllSubmenuRoutes()) ? 'menu-open' : '' }}">
                                <a href="#"
                                    class="nav-link {{ request()->is($menu->getAllSubmenuRoutes()) ? 'active' : '' }}"><i
                                        class="nav-icon {{ $menu->icon }}"></i>
                                    <p>{{ $menu->title }}<i class="right fas fa-angle-left"></i></p>
                                </a>
                                <ul class="nav nav-treeview">
                                    @foreach ($menu->submenus as $submenu)
                                        @can($submenu->permission)
                                            <li class="nav-item">
                                                <a href="{{ url($submenu->url) }}"
                                                    class="nav-link {{ request()->is($submenu->url . '*') ? 'active' : '' }}">
                                                    <i class="far fa-circle nav-icon"></i>
                                                    <p>{{ $submenu->title }}</p>
                                                </a>
                                            </li>
                                        @endcan
                                    @endforeach
                                </ul>
                            </li>
                        @else
                            <li class="nav-item {{ request()->is($menu->submenus[0]->url . '*') ? 'menu-open' : '' }}">
                                <a href="{{ url($menu->submenus[0]->url) }}"
                                    class="nav-link {{ request()->is($menu->submenus[0]->url . '*') ? 'active' : '' }}"><i
                                        class="nav-icon {{ $menu->submenus[0]->icon }}"></i>
                                    <p>{{ $menu->submenus[0]->title }}</p>
                                </a>
                            </li>
                        @endif
                    @endcan
                @endforeach
                <li class="nav-item">
                    <a href="{{ route('logout') }}" class="nav-link"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                            class="nav-icon fa fa-sign-out-alt"></i>
                        <p>Logout</p>
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                        @csrf
                    </form>
                </li>
            </ul>
        </nav>
    </div>
</aside>
