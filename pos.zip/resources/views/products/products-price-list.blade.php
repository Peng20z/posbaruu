@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <h1>Product Price List</h1>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Search Product">
                            <div class="input-group-append" id="search-product">
                                <div class="btn btn-primary">
                                    <i class="fas fa-search"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card card-primary card-outline shadow" id="card">
                            <div class="overlay" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
                            <div class="card-body">
                                <div class="row" id="products-box">
                                    @foreach ($products as $product)
                                        <div class="col-md-3">
                                            <div class="card card-primary">
                                                <div class="card-header">
                                                    <h3 class="card-title">{{ $product->id }} {{ $product->name }}
                                                    </h3>
                                                </div>
                                                <div class="card-body">
                                                    <p>Description : {{ $product->description }}</p>
                                                    @foreach ($product->uoms as $uom)
                                                        <p style="font-weight: bold">Sell Price {{ $uom->name }} :
                                                            {{ rupiah($uom->pivot->sell_price, true) }}</p>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script>
        $(document).ready(function() {

            $('body').keypress(function(e) {
                var key = e.which;
                if (key == 13) // the enter key code
                {
                    $('#search-product').click();
                }
            });

            $('#search-product').click(function() {
                let search = $(this).parent().find(':input').val();
                let html = '';

                $.get('?search=' + search, function(products) {
                    $('.overlay').show();

                    if (products.length == 0) {
                        html +=
                            '<div class="alert alert-warning"><i class="fa fa-warning"></i> Product not found</div>'
                    } else {
                        products.forEach(product => {
                            let htmlProductUoms = '';
                            if (typeof product.uoms !== 'undefined') {
                                product.uoms.forEach(uom => {
                                    price = uom.pivot.sell_price.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
                                    htmlProductUoms +=
                                        `<p style="font-weight: bold">Sell Price ${uom.name} : Rp ${price}</p>`;
                                });
                            }

                            html += `<div class="col-md-3">
                                        <div class="card card-primary">
                                            <div class="card-header">
                                                <h3 class="card-title">${product.id} ${product.name}</h3>
                                            </div>
                                            <div class="card-body">
                                                <p>Description : ${product.description}</p>
                                                ${htmlProductUoms}
                                            </div>
                                        </div>
                                    </div>`;
                        });
                    }

                    $('#products-box').html(html);
                    $('.overlay').hide();
                })
            });
        });
    </script>
@endpush
