@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('products.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('products.update', $product) }}" class="form-loading">
                                @csrf
                                @method('PUT')
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Code</label>
                                        <input name="id" type="text" value="{{ $product->id }}"
                                            class="form-control @error('id') is-invalid @enderror" placeholder="code"
                                            required>
                                        @error('id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Product Brand</label>
                                        <select name="product_brand_id" id="product_brand_id"
                                            class="form-control select2 @error('product_brand_id') is-invalid @enderror"
                                            required>
                                            @foreach ($productBrands as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if ($product->product_brand_id == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('product_brand_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Product Category</label>
                                        <select name="product_category_id" id="product_category_id"
                                            class="form-control select2 @error('product_category_id') is-invalid @enderror"
                                            required>
                                            @foreach ($productCategories as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if ($product->product_category_id == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('product_category_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Name</label>
                                        <input name="name" type="text" value="{{ $product->name }}"
                                            class="form-control @error('name') is-invalid @enderror" placeholder="Name"
                                            required>
                                        @error('name')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="">Capital Price</label>
                                        <div class="d-flex">
                                            <input name="capital_price" type="text" value="{{ number_format($product->capital_price, 2) }}"
                                                class="form-control @error('capital_price') is-invalid @enderror" placeholder="Capital Price" disabled readonly>
                                            <button class="btn btn-primary"><a href="{{ route('products.recalculate-capital', $product->id)}}" class="text-white text-nowrap">Recalculate Price</a></button>
                                            @error('capital_price')
                                                <span class="error invalid-feedback">{{ $message }}</span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="">Minimum Stock Reminder</label>
                                        <input name="min_stock_reminder" type="number" value="{{ $product->min_stock_reminder }}"
                                            class="form-control @error('min_stock_reminder') is-invalid @enderror" placeholder="Minimum Stock Reminder">
                                        @error('min_stock_reminder')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label> <input type="checkbox" name="is_active" value="1"
                                                @if ($product->is_active) checked @endif> Is Active </label>
                                        {{-- &nbsp;
                                        <label> <input type="checkbox" name="is_active" value="1"> Update only on this
                                            db
                                        </label> --}}
                                    </div>
                                    <div class="form-group @error('description') has-error @enderror">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control" rows="5" placeholder="Description">{{ $product->description }}</textarea>
                                        @error('description')
                                            <span class="form-text m-b-none text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
        </section>
    </div>
@endsection
