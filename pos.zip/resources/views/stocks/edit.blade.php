@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('stocks.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('stocks.update', $stock) }}" class="form-loading">
                                @csrf
                                @method('PUT')
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Name</label>
                                        <input name="name" type="text" value="{{ $stock->product?->name }}"
                                            class="form-control @error('name') is-invalid @enderror" placeholder="Name"
                                            required readonly>
                                        @error('name')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Current Stock</label>
                                        <input name="stock" type="stock" value="{{ $stock->qty }}"
                                            class="form-control @error('stock') is-invalid @enderror" placeholder="Stock"
                                            required readonly>
                                        @error('stock')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Action Type</label>
                                        <select name="changes" id="changes"
                                            class="form-control select2 @error('changes') is-invalid @enderror" required>
                                                <option value= 'null'>-- Select Action --</option>
                                                <option value="increase">Increase</option>
                                                <option value="decrease">Decrease</option>
                                        </select>
                                        @error('changes')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Action Value</label>
                                        <input name="amount" type="amount"
                                            class="form-control @error('amount') is-invalid @enderror" placeholder="Action Value"
                                            required>
                                        @error('amount')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
