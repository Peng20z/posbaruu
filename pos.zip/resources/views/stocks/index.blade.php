@extends('layouts.app')
@push('css')
    <style>
        .select {
            width: 50px;
        }

        .select option {
            width: auto;
        }
    </style>
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            {{-- <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('stocks_create')
                            <a href="{{ route('stocks.create') }}" class="btn btn-success" title="Create"><i class="fa fa-plus"></i>
                                Add
                                Data</a>
                        @endcan
                    </div>
                </div>
            </div> --}}
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Stocks List</h3>
                            </div>
                            <div class="card-body">
                                <div class="form-inline">
                                    <form action="">
                                        Show
                                        <select class="form-control form-control-sm select mb-2" id="select-shown-stock" name="minimum_stock">
                                            <option value="all" {{ request()->minimum_stock == 'all' ? 'selected' : null }}>All</option>
                                            <option value="white" {{ request()->minimum_stock == 'white' ? 'selected' : null }}>Above Stock Minimum</option>
                                            <option value="red" {{ request()->minimum_stock == 'red' ? 'selected' : null }}>Below Stock Minimum</option>
                                        </select>
                                        entries
                                    </form>
                                </div>
                                <table id="stocks-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th rowspan="2" style="vertical-align: middle">Code</th>
                                            <th rowspan="2" style="vertical-align: middle">Product</th>
                                            <th colspan="2" style="text-align: center">Quantity</th>
                                            <th rowspan="2" style="vertical-align: middle">Updated At</th>
                                            <th rowspan="2" style="vertical-align: middle"></th>
                                        </tr>
                                        <tr>
                                            <th>Qty</th>
                                            <th>UOM</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script>
        $('#select-shown-stock').change(function() {
            table.ajax.reload();
        })

        var table = $('#stocks-datatable').DataTable({
            processing: true,
            serverSide: true,
            searching: true,
            responsive: true,
            ajax: {
                url: '{{ route('stocks.index') }}',
                data: function(params) {
                    params.minimum_stock =  $('#select-shown-stock').val();
                },
            },
            columns: [{
                    data: 'product_code',
                    name: 'product.id',
                },
                {
                    data: 'product_name',
                    name: 'product.name'
                },
                {
                    data: 'default_qty',
                    name: 'default_qty'
                },
                {
                    data: 'default_uom',
                    name: 'default_uom'
                },
                {
                    data: 'updated_at',
                    name: 'updated_at'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            orderCellsTop: true,
            order: [
                // [0, 'desc']
            ],
            pageLength: 25,
            rowCallback: function(row, data) {
                if (data.qty < data.product.min_stock_reminder) {
                    $(row).css('background-color', 'rgba(255,209,209,1)');
                }
            },
        });

        function deleteData(id) {
            if (confirm('Delete data?')) {
                $.post(`{{ url('stocks') }}/` + id, {
                    _method: 'delete'
                }, function(res) {
                    if (res.success) {
                        table.ajax.reload();
                        toastr.success(res.message);
                    } else {
                        toastr.error(res.message);
                    }
                }, 'json');
            }
        }
    </script>
@endpush
