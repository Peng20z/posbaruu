@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('stocks.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">{{ $stock->product?->name }} Stock History</h3>
                                {{-- <a href="{{ route('stocks.index') }}" class="btn btn-primary btn-sm float-right"><i
                                        class="fa fa-arrow-left"></i> Back</a> --}}
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>Date</th>
                                        <th>Actor</th>
                                        <th>Description</th>
                                        <th>Invoice No</th>
                                        <th>In</th>
                                        <th>Out</th>
                                        <th>Unit Price</th>
                                        <th>Total Price</th>
                                        <th>Quantity</th>
                                    </tr>
                                    @php
                                        $quantity = $stock->qty;
                                    @endphp
                                    @foreach ($stock->histories as $history)
                                        <tr>
                                            <td>{{ $history->created_at->format('d-m-Y H:i') }}</td>
                                            <td>{{ $history->user?->name }}</td>
                                            <td>{{ $history->description }}</td>
                                            @if ($history->model?->purchaseOrder)
                                                <td><a
                                                        href="{{ url('purchase-orders/' . $history->model->purchase_order_id .'/edit') }}"><i
                                                            class="fa fa-link"></i>{{ $history->model->purchaseOrder->po_number }}</a>
                                                </td>
                                            @elseif ($history->model?->salesOrder)
                                                <td><a href="{{ url('sales-orders/' . $history->model->sales_order_id .'/edit') }}"><i
                                                            class="fa fa-link"></i>{{ $history->model->salesOrder->code }}</a>
                                                </td>
                                            @else
                                                <td></td>
                                            @endif
                                            @if ($history->is_increment == true)
                                                <td>{{ $history->qty }}</td>
                                                <td></td>
                                            @else
                                                <td></td>
                                                <td>{{ $history->qty }}</td>
                                            @endif
                                            @if ($history->model?->purchaseOrder)
                                                <td>{{ $history->model->unit_price }}</a>
                                                </td>
                                            @elseif ($history->model?->salesOrder)
                                                <td>{{ $history->model->unit_price }}</a>
                                                </td>
                                            @else
                                                <td></td>
                                            @endif
                                            @if ($history->model?->purchaseOrder)
                                                <td>{{ $history->model->total_price }}</a>
                                                </td>
                                            @elseif ($history->model?->salesOrder)
                                                <td>{{ $history->model->total_price }}</a>
                                                </td>
                                            @else
                                                <td></td>
                                            @endif
                                            <td>{{ $quantity }}</td>
                                        </tr>
                                        @php
                                            if ($history->is_increment == true) {
                                                $quantity -= $history->qty;
                                            } else {
                                                $quantity += $history->qty;
                                            }
                                        @endphp
                                    @endforeach
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
