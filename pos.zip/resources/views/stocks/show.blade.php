@extends('layouts.app')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('stocks.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">{{ $stock->product?->name }} Stock Detail</h3>
                                {{-- <a href="{{ route('stocks.index') }}" class="btn btn-primary btn-sm float-right"><i
                                        class="fa fa-arrow-left"></i> Back</a> --}}
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>Code</th>
                                        <td colspan="2">{{ $stock->product->id }}</td>
                                    </tr>
                                    <tr>
                                        <th>Name</th>
                                        <td colspan="2">{{ $stock->product->name }}</td>
                                    </tr>
                                    <tr>
                                        <th rowspan="2">Qty</th>
                                        <td>{{ floor($stock->qty /$stock->product->uoms()->where('uom_id', $stock->product->default_uom_id)->first()->pivot->quantity) }}
                                        </td>
                                        <td>{{ Str::ucfirst($stock->product?->defaultUom?->name) }}</td>
                                    </tr>
                                    @if ($stock->product?->defaultUom?->id != $stock->product?->baseUom?->id)
                                        <tr>
                                            <td>{{ $stock->qty %$stock->product->uoms()->where('uom_id', $stock->product->default_uom_id)->first()->pivot->quantity }}
                                            </td>
                                            <td>{{ Str::ucfirst($stock->product?->baseUom?->name ?? '') }}</td>
                                        </tr>
                                        <tr>
                                            <th>Total Qty</th>
                                            <td>{{$stock->qty}}</td>
                                            <td>{{ Str::ucfirst($stock->product?->baseUom?->name ?? '') }}</td>
                                        </tr>
                                    @endif
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
