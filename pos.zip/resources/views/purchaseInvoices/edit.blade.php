@extends('layouts.app')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('purchase-invoices.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('purchase-invoices.update', $purchaseInvoice) }}" class="form-loading">
                                @csrf
                                @method('PUT')
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Purchase Invoice</label>
                                        <input type="text" name="purchase_order_id" readonly
                                            value="{{ $purchaseInvoice->purchase_order_id }}" required class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Code</label>
                                        <input name="code" id="code" type="text"
                                            class="form-control @error('code') is-invalid @enderror"
                                            value="{{ $purchaseInvoice->code }}" placeholder="code" required>
                                        @error('code')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Payment Type</label>
                                        <select name="payment_type_id" id="payment_type_id"
                                            class="form-control select2 @error('payment_type_id') is-invalid @enderror"
                                            required>
                                            @foreach ($paymentTypes as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('payment_type_id', $purchaseInvoice->payment_type_id) == $id) selected @endif>
                                                    {{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('payment_type_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Unpaid Payment</label>
                                        <input id=payment_left type="text" class="form-control price-format"
                                            value="{{ rupiah($purchaseInvoice->purchaseOrder->total_price - ($purchaseInvoice->purchaseOrder->total_paid - $purchaseInvoice->amount)) }}"
                                            placeholder="Payment Left" disabled readonly>
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Amount</label>
                                        <input name="amount" type="text"
                                            value="{{ rupiah($purchaseInvoice->amount) }}"
                                            class="form-control price-format @error('amount') is-invalid @enderror"
                                            placeholder="amount" required>
                                        @error('amount')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Status</label>
                                        <select name="status" id="status"
                                            class="form-control select2 @error('status') is-invalid @enderror" required>
                                            @foreach ($paymentStatuses as $paymentStatus)
                                                <option value="{{ $paymentStatus->value }}"
                                                    @if ($purchaseInvoice->status->value == $paymentStatus->value) selected @endif>
                                                    {{ $paymentStatus->description }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('status')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group @error('description') has-error @enderror">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control" rows="5" placeholder="Description">{{ $purchaseInvoice->description }}</textarea>
                                        @error('description')
                                            <span class="form-text m-b-none text-danger">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            initPriceFormat();

            $('body').on('change', '#purchase_order_id', async function() {
                let purchaseOrder = await getUnpaid($(this).val());
                let amount = customToFixed(purchaseOrder.total_price - purchaseOrder.total_paid)

                $('#amount').val(amount);
                $('#payment_left').val(amount);
                
                initPriceFormat();
            });
        });

        function getUnpaid(id) {
            return new Promise((resolve, reject) => {
                $.get('{{ url('api/pruchase-orders/get-unpaid') }}/' + id,
                    function(res) {
                        if (res) {
                            resolve(res);
                        } else {
                            reject(new Error('Purchase Invoice not found'))
                        }
                    });
            });
        }
    </script>
@endpush
