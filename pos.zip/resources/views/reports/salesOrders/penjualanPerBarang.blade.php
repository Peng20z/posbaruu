@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col">
                        <h1>Report Sales Orders</h1>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="card card-primary card-outline shadow">
                    <div class="card-header">
                        <h3 class="card-title">Penjualan per Barang</h3>
                        <a href="?is_download_pdf=1" class="btn btn-primary float-right"><i class="fa fa-file-pdf"></i>
                            Download PDF</a>
                    </div>
                    <div class="card-body">
                        <form action="">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>No. Faktur</label>
                                        <input name="code" type="text" class="form-control" placeholder="No. Faktur"
                                            value="{{ $filter['code'] }}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Date range:</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="far fa-calendar-alt"></i>
                                                </span>
                                            </div>
                                            <input type="text" name="date_range" class="form-control float-right"
                                                id="date-range"
                                                value="{{ date('m/d/Y', strtotime($filter['start_date'])) . ' - ' . date('m/d/Y', strtotime($filter['end_date'])) }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Product</label>
                                        <select name="product_ids[]" id="product_ids" class="form-control" multiple>
                                            @if (isset($filter['selected_products']) && count($filter['selected_products']))
                                                @foreach ($filter['selected_products'] as $id => $name)
                                                    <option value="{{ $id }}" selected>{{ $name }}
                                                    </option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>&nbsp;</label>
                                        <div class="custom-control custom-checkbox">
                                            <input name="has_so" class="custom-control-input" type="checkbox"
                                                value="1" id="has_so" @checked($filter['has_so'])>
                                            <label for="has_so" class="custom-control-label">Only has SO</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <button type="submit" class="btn btn-primary float-right"><i class="fa fa-filter"></i>
                                        Filter</button>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No. Faktur</th>
                                        <th>Tgl. Faktur</th>
                                        <th>Keterangan</th>
                                        <th>Qty</th>
                                        <th>Unit</th>
                                        <th>Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($products as $product)
                                        <tr>
                                            <th>{{ $product->id }}</th>
                                            <th>{{ $product->name }}</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                        @foreach ($product->salesOrderDetails as $salesOrderDetail)
                                            <tr>
                                                <td><span class="pl-3">{{ $salesOrderDetail->salesOrder->code }}</span>
                                                </td>
                                                <td><span
                                                        class="pl-3">{{ date('d M Y', strtotime($salesOrderDetail->salesOrder->transaction_datetime)) }}</span>
                                                </td>
                                                <td><span
                                                        class="pl-3">{{ $salesOrderDetail->salesOrder->description }}</span>
                                                </td>
                                                <td><span class="pl-3">{{ $salesOrderDetail->qty }}</span></td>
                                                <td><span class="pl-3">{{ $salesOrderDetail->uom->name }}</span></td>
                                                <td><span class="pl-3">{{ $salesOrderDetail->total_price }}</span></td>
                                            </tr>
                                        @endforeach
                                        <tr>
                                            <th colspan="3"></th>
                                            <th><span class="pl-3">{{ $product->salesOrderDetails->sum('qty') }}</span>
                                            </th>
                                            <th></th>
                                            <th><span
                                                    class="pl-3">{{ $product->salesOrderDetails->sum('total_price') }}</span>
                                            </th>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('#date-range').daterangepicker().on('apply.daterangepicker', function(ev, picker) {
                startDate = picker.startDate.format('YYYY-MM-DD');
                endDate = picker.endDate.format('YYYY-MM-DD');
                table.ajax.reload();
            });

            let selectedProductIds = @json($filter['product_ids'] ?? []); // buat nampung id product yg sudah terpilih
            $('#product_ids').select2({
                theme: 'bootstrap4',
                multiple: true,
                placeholder: 'Select product',
                ajax: {
                    url: '{{ route('api.products.index') }}',
                    dataType: 'json',
                    delay: 300,
                    data: function(params) {
                        return {
                            'per_page': 30,
                            'select': 'id,name as text', // select2 only accept return data (id and text)
                            'filter[name]': params.term, // search term / search by nama product
                            'filter[ids]': selectedProductIds
                                .toString(), // search where id product not in
                            page: params.page || params.current_page || 1
                        };
                    },
                    processResults: function(data, params) {
                        params.current_page = params.current_page || 1;
                        return {
                            results: data.data,
                            pagination: {
                                more: (params.current_page * 30) < data.total
                            }
                        };
                    },
                    autoWidth: true,
                    cache: true
                }
            }).on('change', function() {
                selectedProductIds = $(this).val();
            });

            $(document).on('select2:open', () => {
                let el = document.querySelector('.select2-search__field');
                el.focus();
                el.placeholder = 'search'
                el.style.width = 'unset'
            });
        })
    </script>
@endpush
