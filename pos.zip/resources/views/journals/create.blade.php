@extends('layouts.app')
@push('css')
    <style>
        .select2-container .select2-selection--single {
            height: unset;
        }

        .w-300 {
            width: 300px !important
        }
    </style>
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('journals.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <form method="post" action="{{ route('journals.store') }}" class="form-loading">
                                @csrf
                                <div class="card-body">
                                    @if ($errors->any())
                                        <div class="alert alert-danger">
                                            <ul>
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @endif
                                    <div class="form-group">
                                        <label class="required">Code</label>
                                        <input name="code" type="text" value="{{ old('code') }}"
                                            class="form-control @error('code') is-invalid @enderror" placeholder="Code"
                                            required>
                                        @error('code')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Transaction Date</label>
                                        <input name="transaction_date" type="date" value="{{ old('transaction_date') }}"
                                            class="form-control @error('transaction_date') is-invalid @enderror"
                                            placeholder="Transaction Date" required>
                                        @error('transaction_date')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control @error('description') is-invalid @enderror" rows="3">{{ old('description') }}</textarea>
                                        @error('description')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="table table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th class="w-300">COA</th>
                                                    <th>Debit</th>
                                                    <th>Credit</th>
                                                    <th>Memo</th>
                                                    <th>Subsidiary Ledger</th>
                                                    <th>Dept</th>
                                                    <th>Event</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="form-box">
                                                @if (old('details'))
                                                    @foreach (old('details') as $i => $detail)
                                                        <tr>
                                                            <td class="w-300">
                                                                <div class="form-group">
                                                                    <select name="details[{{ $i }}][coa_id]"
                                                                        class="form-control select2 @isset($errors->getMessages()['details.' . $i . '.coa_id']) is-invalid @endisset">
                                                                        @foreach ($coas as $id => $name)
                                                                            <option value="{{ $id }}"
                                                                                {{ $detail['coa_id'] == $id ? 'selected' : '' }}>
                                                                                {{ $name }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                    @isset($errors->getMessages()['details.' . $i . '.coa_id'])
                                                                        @foreach ($errors->getMessages()['details.' . $i . '.coa_id'] as $msg)
                                                                            <span
                                                                                class="error invalid-feedback">{{ $msg }}</span>
                                                                        @endforeach
                                                                    @endisset
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="form-group">
                                                                    <input name="details[{{ $i }}][debit]"
                                                                        type="text" value="{{ $detail['debit'] }}"
                                                                        class="form-control price-format @if (isset($errors->getMessages()['details.' . $i . '.debit']) || isset($errors->getMessages()['balance_not_match'])) is-invalid @endif">
                                                                    @isset($errors->getMessages()['details.' . $i . '.debit'])
                                                                        @foreach ($errors->getMessages()['details.' . $i . '.debit'] as $msg)
                                                                            <span
                                                                                class="error invalid-feedback">{{ $msg }}</span>
                                                                        @endforeach
                                                                    @endisset
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="form-group">
                                                                    <input name="details[{{ $i }}][credit]"
                                                                        type="text" value="{{ $detail['credit'] }}"
                                                                        class="form-control price-format @if (isset($errors->getMessages()['details.' . $i . '.credit']) || isset($errors->getMessages()['balance_not_match'])) is-invalid @endif">
                                                                    @isset($errors->getMessages()['details.' . $i . '.credit'])
                                                                        @foreach ($errors->getMessages()['details.' . $i . '.credit'] as $msg)
                                                                            <span
                                                                                class="error invalid-feedback">{{ $msg }}</span>
                                                                        @endforeach
                                                                    @endisset
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="form-group">
                                                                    <input name="details[{{ $i }}][memo]"
                                                                        type="text" value="{{ $detail['memo'] }}"
                                                                        class="form-control @isset($errors->getMessages()['details.' . $i . '.memo']) is-invalid @endisset">
                                                                    @isset($errors->getMessages()['details.' . $i . '.memo'])
                                                                        @foreach ($errors->getMessages()['details.' . $i . '.memo'] as $msg)
                                                                            <span
                                                                                class="error invalid-feedback">{{ $msg }}</span>
                                                                        @endforeach
                                                                    @endisset
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="form-group">
                                                                    <input
                                                                        name="details[{{ $i }}][subsidiary_ledger]"
                                                                        type="text"
                                                                        value="{{ $detail['subsidiary_ledger'] }}"
                                                                        class="form-control @isset($errors->getMessages()['details.' . $i . '.subsidiary_ledger']) is-invalid @endisset">
                                                                    @isset($errors->getMessages()['details.' . $i . '.subsidiary_ledger'])
                                                                        @foreach ($errors->getMessages()['details.' . $i . '.subsidiary_ledger'] as $msg)
                                                                            <span
                                                                                class="error invalid-feedback">{{ $msg }}</span>
                                                                        @endforeach
                                                                    @endisset
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="form-group">
                                                                    <input name="details[{{ $i }}][dept]"
                                                                        type="text" value="{{ $detail['dept'] }}"
                                                                        class="form-control @isset($errors->getMessages()['details.' . $i . '.dept']) is-invalid @endisset">
                                                                    @isset($errors->getMessages()['details.' . $i . '.dept'])
                                                                        @foreach ($errors->getMessages()['details.' . $i . '.dept'] as $msg)
                                                                            <span
                                                                                class="error invalid-feedback">{{ $msg }}</span>
                                                                        @endforeach
                                                                    @endisset
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="form-group">
                                                                    <input name="details[{{ $i }}][event]"
                                                                        type="text" value="{{ $detail['event'] }}"
                                                                        class="form-control @isset($errors->getMessages()['details.' . $i . '.event']) is-invalid @endisset">
                                                                    @isset($errors->getMessages()['details.' . $i . '.event'])
                                                                        @foreach ($errors->getMessages()['details.' . $i . '.event'] as $msg)
                                                                            <span
                                                                                class="error invalid-feedback">{{ $msg }}</span>
                                                                        @endforeach
                                                                    @endisset
                                                                </div>
                                                            </td>
                                                            <td>
                                                                @if ($i > 0)
                                                                    <button type="button"
                                                                        class="btn btn-danger btn-sm btn-delete"><i
                                                                            class="fa fa-trash"></i></button>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                @else
                                                    <tr>
                                                        <td class="w-300">
                                                            <div class="form-group">
                                                                <select name="details[0][coa_id]"
                                                                    class="form-control select2 @error('coa_id') is-invalid @enderror">
                                                                    @foreach ($coas as $id => $name)
                                                                        <option value="{{ $id }}">
                                                                            {{ $name }}</option>
                                                                    @endforeach
                                                                </select>
                                                                @error('coa_id')
                                                                    <span
                                                                        class="error invalid-feedback">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-group">
                                                                <input name="details[0][debit]" type="text"
                                                                    value="0"
                                                                    class="form-control price-format @error('debit') is-invalid @enderror">
                                                                @error('debit')
                                                                    <span
                                                                        class="error invalid-feedback">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-group">
                                                                <input name="details[0][credit]" type="text"
                                                                    value="0"
                                                                    class="form-control price-format @error('credit') is-invalid @enderror">
                                                                @error('credit')
                                                                    <span
                                                                        class="error invalid-feedback">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-group">
                                                                <input name="details[0][memo]" type="text"
                                                                    class="form-control @error('memo') is-invalid @enderror">
                                                                @error('memo')
                                                                    <span
                                                                        class="error invalid-feedback">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-group">
                                                                <input name="details[0][subsidiary_ledger]" type="text"
                                                                    class="form-control @error('subsidiary_ledger') is-invalid @enderror">
                                                                @error('subsidiary_ledger')
                                                                    <span
                                                                        class="error invalid-feedback">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-group">
                                                                <input name="details[0][dept]" type="text"
                                                                    class="form-control @error('dept') is-invalid @enderror">
                                                                @error('dept')
                                                                    <span
                                                                        class="error invalid-feedback">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="form-group">
                                                                <input name="details[0][event]" type="text"
                                                                    class="form-control @error('event') is-invalid @enderror">
                                                                @error('event')
                                                                    <span
                                                                        class="error invalid-feedback">{{ $message }}</span>
                                                                @enderror
                                                            </div>
                                                        </td>
                                                        <td>
                                                        </td>
                                                    </tr>
                                                @endif
                                            </tbody>
                                        </table>
                                        <button type="button" id="btn-add" class="btn btn-info"><i
                                                class="fa fa-plus"></i></button>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection

@push('js')
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        let i = 1;
        @if (old('details'))
            i = {{ count(old('details')) }};
        @endif ()

        function initPriceFormat() {
            $('.price-format').priceFormat({
                prefix: '',
                centsLimit: 0,
                thousandsSeparator: ','
            });
        }
        $(document).ready(function() {
            initPriceFormat();
            $("#btn-add").on("click", function() {
                let html = `
            <tr>
                <td class="w-300">
                    <div class="form-group">
                        <select name="details[${i}][coa_id]"
                            class="form-control select2">
                            @foreach ($coas as $id => $name)
                                <option value="{{ $id }}">
                                    {{ $name }}</option>
                            @endforeach
                        </select>
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input name="details[${i}][debit]" value="0" type="text"
                            class="form-control price-format">
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input name="details[${i}][credit]" value="0" type="text"
                            class="form-control price-format">
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input name="details[${i}][memo]" type="text"
                            class="form-control">
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input name="details[${i}][subsidiary_ledger]" type="text"
                            class="form-control">
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input name="details[${i}][dept]" type="text"
                            class="form-control">
                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <input name="details[${i}][event]" type="text"
                            class="form-control">
                    </div>
                </td>
                <td>
                    <button type="button" class="btn btn-danger btn-sm btn-delete"><i class="fa fa-trash"></i></button>
                </td>
            </tr>`;
                $('#form-box').append(html)
                initPriceFormat();
                $('.select2').select2()
                i++;
            });

            $("body").on("click", ".btn-delete", function() {
                $(this).parent().parent().remove();
            });
        });
    </script>
@endpush
