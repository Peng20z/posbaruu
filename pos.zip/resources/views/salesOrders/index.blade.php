@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        @can('sales_orders_create')
                            <a href="{{ route('sales-orders.create-admin') }}" class="btn btn-success" title="Create"><i
                                    class="fa fa-plus"></i>
                                Add
                                Data</a>
                        @endcan
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card card-primary card-outline shadow">
                            <div class="card-header">
                                <h3 class="card-title">Sales Orders List {{ session('db_connection') }}</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Date range:</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text">
                                                        <i class="far fa-calendar-alt"></i>
                                                    </span>
                                                </div>
                                                <input type="text" class="form-control float-right" id="date-range">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <table id="sales-orders-datatable" class="datatable table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Transaction Datetime</th>
                                            <th>User</th>
                                            <th>Customer</th>
                                            <th>Code</th>
                                            <th>Total Price</th>
                                            <th>Payment Status</th>
                                            <th></th>
                                        </tr>
                                        <tr>
                                            <x-forms.filter-id />
                                            <x-forms.filter-text />
                                            <x-forms.filter-text />
                                            <x-forms.filter-text />
                                            <x-forms.filter-text />
                                            <x-forms.filter-text />
                                            <x-forms.filter-text />
                                            <td></td>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script>
        let date = new Date();
        let startDate = moment().startOf('month').format('YYYY-MM-DD');
        let endDate = moment().endOf('month').format('YYYY-MM-DD');

        $('#date-range').daterangepicker().on('apply.daterangepicker', function(ev, picker) {
            startDate = picker.startDate.format('YYYY-MM-DD');
            endDate = picker.endDate.format('YYYY-MM-DD');
            table.ajax.reload();
        });
        var table = $('#sales-orders-datatable').DataTable({
            processing: true,
            serverSide: true,
            searching: true,
            responsive: true,
            ajax: {
                url: '{{ route('sales-orders.index') }}',
                data: function(params) {
                    params.start_date = startDate;
                    params.end_date = endDate;
                },
            },
            columns: [{
                    data: 'id',
                    name: 'id',
                },
                {
                    data: 'transaction_datetime',
                    name: 'transaction_datetime'
                },
                {
                    data: 'user_name',
                    name: 'user.name'
                },
                {
                    data: 'customer_name',
                    name: 'user.name'
                },
                {
                    data: 'code',
                    name: 'code'
                },
                {
                    data: 'total_price',
                    name: 'total_price'
                },
                {
                    data: 'payment_status',
                    name: 'payment_status'
                },
                {
                    data: 'actions',
                    name: 'actions',
                    orderable: false,
                    searchable: false
                }
            ],
            orderCellsTop: true,
            order: [
                [0, 'desc']
            ],
            pageLength: 25,
        });

        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
            alert('tab clicked')
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });

        let visibleColumnsIndexes = null;
        $('.datatable thead').on('input', '.search', function() {
            let strict = $(this).attr('strict') || false
            let value = strict && this.value ? "^" + this.value + "$" : this.value

            let index = $(this).parent().index()
            if (visibleColumnsIndexes !== null) {
                index = visibleColumnsIndexes[index]
            }

            table
                .column(index)
                .search(value, strict)
                .draw()
        });
        table.on('column-visibility.dt', function(e, settings, column, state) {
            visibleColumnsIndexes = []
            table.columns(":visible").every(function(colIdx) {
                visibleColumnsIndexes.push(colIdx);
            });
        })

        function deleteData(id) {
            if (confirm('Delete data?')) {
                $.post(`{{ url('sales-orders') }}/` + id, {
                    _method: 'delete'
                }, function(res) {
                    if (res.success) {
                        table.ajax.reload();
                        toastr.success(res.message);
                    } else {
                        toastr.error(res.message);
                    }
                }, 'json');
            }
        }
    </script>
@endpush
