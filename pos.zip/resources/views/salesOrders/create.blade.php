@extends('layouts.app')
@push('css')
    <link rel="stylesheet" href="{{ asset('plugins/daterangepicker/daterangepicker.css') }}">
@endpush
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <a href="{{ route('sales-orders.index') }}" class="btn btn-success" title="Back"><i
                                class="fa fa-arrow-left"></i> Back</a>
                    </div>
                </div>
            </div>
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <form method="post" action="{{ route('sales-orders.store') }}" class="form-loading">
                            @csrf
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Sales Order</h3>
                                </div>
                                @csrf
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="required">Transaction Date</label>
                                        <div class="input-group date" id="filter-date" data-target-input="nearest"
                                            data-toggle="datetimepicker">
                                            <input type="text" name="transaction_datetime"
                                                class="form-control datetimepicker-input" data-target="#filter-date" />
                                            <div class="input-group-append" data-target="#filter-date">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Customer</label>
                                        <select name="customer_id" id="customer_id"
                                            class="form-control select2 @error('customer_id') is-invalid @enderror"
                                            required>
                                            @foreach ($customers as $id => $name)
                                                <option value="{{ $id }}"
                                                    @if (old('customer_id', null) == $id) selected @endif>{{ $name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('customer_id')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                    <div class="form-group">
                                        <label class="required">Description</label>
                                        <textarea name="description" id="description" rows="5" class="form-control">{{ old('description') }}</textarea>
                                        @error('description')
                                            <span class="error invalid-feedback">{{ $message }}</span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="card card-primary card-outline shadow">
                                <div class="card-header">
                                    <h3 class="card-title">Sales Order Details</h3>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Code</th>
                                                    <th>Product Name</th>
                                                    <th>Qty</th>
                                                    <th>Uom</th>
                                                    <th style="background-color: #D3D3D3">Stock</th>
                                                    <th>Unit Price</th>
                                                    <th>PPN</th>
                                                    <th>Discount</th>
                                                    <th>Total Price</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="table-body"></tbody>
                                            <tfoot>
                                                <tr>
                                                    <th colspan="8">Total Price</th>
                                                    <th>
                                                        <input class="form-control price-format"
                                                            id="total-price-accumulation" readonly disabled>
                                                    </th>
                                                    <th></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                    <div class="form-group">
                                        <label>Select Product</label>
                                        <div class="d-flex">
                                            <select name="product_id" id="product_id" class="form-control w-75">
                                            </select>
                                            <button class="btn btn-primary ml-2" id="add-product" type="button"><i
                                                    class="fa fa-plus"></i> Add Product</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@push('js')
    <script src="{{ asset('plugins/daterangepicker/daterangepicker.js') }}"></script>
    <script src="{{ asset('plugins/jquery-price-format/jquery.priceformat.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            let selectedProducts = []; // buat nampung products yg sudah terpilih
            let selectedProductIds = []; // buat nampung id product yg sudah terpilih
            let i = 0;

            if ((screen.width < 1440)) {
                $("#customer_id").val(2).change();
            }

            $('#filter-date').datetimepicker({
                defaultDate: new Date(),
                timePicker: true,
                timePicker24Hour: true,
                format: 'YYYY-MM-DD HH:mm:ss',

                icons: {
                    time: 'far fa-clock'
                }
            });

            function initPriceFormat() {
                $('.price-format').priceFormat({
                    prefix: '',
                    centsLimit: 0,
                    thousandsSeparator: '.'
                });
            }

            // fungsi untuk merubah format price(ex: 10.000) menjadi int(ex: 10000)
            function unformatPrice(value = 0) {
                return parseInt(value.replaceAll('.', '') || 0);
            }

            // get products
            $('#product_id').select2({
                theme: 'bootstrap4',
                placeholder: 'Select product',
                ajax: {
                    url: '{{ route('api.products.index') }}',
                    dataType: 'json',
                    delay: 300,
                    data: function(params) {
                        return {
                            'per_page': 30,
                            'select': 'id,name as text', // select2 only accept return data (id and text)
                            'filter[name]': params.term, // search term / search by nama product
                            'filter[ids]': selectedProductIds
                                .toString(), // search where id product not in
                            page: params.page || params.current_page || 1
                        };
                    },
                    processResults: function(data, params) {
                        params.current_page = params.current_page || 1;
                        return {
                            results: data.data,
                            pagination: {
                                more: (params.current_page * 30) < data.total
                            }
                        };
                    },
                    autoWidth: true,
                    cache: true
                }
            });

            // fungsi ketika hapus product
            $('body').on('click', '.btn-delete', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let productId = parent.find('.input-product-id').val(); // get product id

                parent.remove(); // hapus element parent(<tr>) nya

                // hapus id product dari variable selectedProductIds
                selectedProductIds = $.grep(selectedProductIds, function(value) {
                    return value != productId;
                });

                selectedProducts = $.grep(selectedProducts, function(product) {
                    return product.id != productId;
                });

                setTotalPriceAccumulation();
            });

            // ajax get product discount berdasarkan uom dan qty
            function getProductDiscount(product, qty = 1, uomId = null) {
                return new Promise((resolve, reject) => {
                    let discount = 0;

                    let defaultProductUom = product?.uoms.find((uom) => {
                        if (uomId) return uom.id == uomId;

                        return uom.pivot.is_default === true;
                    });

                    if (defaultProductUom) {
                        let discounts = defaultProductUom.pivot?.discounts;
                        if (discounts) {
                            let discountKey = Object.keys(discounts)
                                .filter(key => parseInt(key) <= qty)
                                .pop()

                            if (discounts[discountKey]) discount = discounts[discountKey];
                        }
                    }

                    resolve(discount);
                });
            }

            // fungsi untuk add product
            $('#add-product').on('click', async function() {
                let productId = $('#product_id').val();
                if (productId) {
                    try {
                        let customerId = document.getElementById('customer_id').value;
                        let product = await getProduct(productId,
                            customerId); // get product ke fungsi getProduct()
                        // create element untuk select uoms, nanti di append di table
                        let defaultUomQty = 0;

                        let uomsSelectForm =
                            `<select name="items[${i}][uom_id]" class="form-control select2 input-product-uom_id" required>`;
                        $.each(product.uoms, function(i, uom) {
                            if (uom.id == product.default_uom_id) {
                                defaultUomQty = uom.pivot.quantity;
                            }
                            uomsSelectForm +=
                                `<option value="${uom.id}" ${uom.pivot.is_default && 'selected'} data-product_id="${product.id}">${uom.name}</option>`;
                        });
                        uomsSelectForm += `</select>`;

                        let priceHistories = ``;
                        $.each(product.priceHistory, function(i, history) {
                            priceHistories +=
                                `<option>${history}</option>`
                        });

                        let discount = await getProductDiscount(product);

                        let html = `<tr>
                            <input type="hidden" name="items[${i}][product_id]" class="input-product-id" value="${product.id}"/>
                            <td>${product.id}</td>
                            <td>${product.name}</td>
                            <td>
                                <input type="number" name="items[${i}][qty]" value="1" class="form-control input-product-qty" data-price="${product.sell_price}" min="1" max="${Math.floor(product.stock.qty / defaultUomQty)}"/>
                                </td>
                            <td>${uomsSelectForm}</td>
                            <td class="price-format input-product-stock" style="background-color: #D3D3D3">${Math.floor(product.stock.qty / defaultUomQty)}</td>
                            <td>
                                <input value="${customToFixed(product.sell_price)}" name="items[${i}][unit_price]" class="form-control price-format input-product-price" min="0" list="priceHistories" onmousedown="value = 0;"/>
                                <datalist id="priceHistories">
                                    ${priceHistories}
                                </datalist>
                            </td>
                            <td>
                                <input type="checkbox" name="items[${i}][ppn]" class="form-control input-ppn" value="1"/>
                            </td>
                            <td>
                                <input type="input" name="items[${i}][discount]" class="form-control price-format input-discount" value="${discount}"/>
                            </td>
                            <td>
                                <input value="${customToFixed(product.sell_price)}" class="form-control price-format input-product-total-price" min="0" readonly disabled/>
                            </td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm btn-delete"><i class="fa fa-trash"></i></button>
                            </td>
                        </tr>`;

                        i = i + 1;
                        // cek kalo productnya sudah di insert ke table jangan di insert lagi
                        if (!selectedProductIds.includes(product.id.toString())) {
                            selectedProducts.push(
                                product
                            ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            // selectedProductIds.push(
                            //     productId
                            // ); // simpan id product ke variable selectedProductIds, untuk di cek agar tidak bisa dipilih lagi
                            $('#table-body').append(html).find('.input-product-qty').focus();
                            $('#product_id').val('').change();
                            setTotalPriceAccumulation();

                            initPriceFormat();
                            // $('.price-format').priceFormat({
                            //     prefix: '',
                            //     centsLimit: 0,
                            //     thousandsSeparator: '.'
                            // });
                        }
                    } catch (error) {
                        // handle jika get product nya error
                        toastr.error(error.message);
                    }
                }
            });

            // fungsi untuk handle ketika +/- qty
            $('body').on('change', '.input-product-qty', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            $('body').on('change', '.input-product-price', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table

                setTotalPricePerProduct(parent);
            });

            // fungsi untuk handle ketika ceklist ppn
            $('body').on('change', '.input-ppn', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                setTotalPricePerProduct(parent, false);
            });

            // fungsi untuk handle ketika discount diubah
            $('body').on('keyup', '.input-discount', function() {
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                setTotalPricePerProduct(parent, false);
            });

            $('body').on('change', '.input-product-uom_id', async function() {
                let selectedUomId = $(this).val();
                let productId = $(this).find(':selected').data('product_id');
                let parent = $(this).parent().parent(); // get parent(<tr>) dari current table
                let product = selectedProducts.filter(product => product.id == productId);
                try {
                    let customerId = $('#customer_id').val();
                    let productUom = await getProductUom(productId, selectedUomId, customerId);
                    let stock = Math.floor(product[0].stock.qty / productUom.quantity);

                    parent.find('.input-product-qty').attr({
                        "max": stock,
                    });
                    parent.find('.input-product-stock').text(stock);
                    parent.find('.input-product-price').text(productUom.sell_price);
                    parent.find('.input-product-qty').data('price', productUom.sell_price);

                    setTotalPricePerProduct(parent);
                } catch (error) {
                    // handle jika get product nya error
                    toastr.error(error.message);
                }
            });

            // fungsi untuk hitung total akumulasi harga per product
            // fungsi ini akan dipanggil ketika +/- product, ceklist ppn, dan ganti uom
            async function setTotalPricePerProduct(parent, isCountOriginalDiscount = true) {
                let productId = parent.find('.input-product-id').val();
                let qty = parent.find('.input-product-qty').val();
                let selectedUomId = parent.find('.input-product-uom_id').val();


                if (isCountOriginalDiscount === true) {
                    let product = selectedProducts?.find(product => product.id == productId);
                    if (product) {
                        let discount = await getProductDiscount(product, qty, selectedUomId);
                        parent.find('.input-discount').val(discount)
                    }
                }

                let discount = unformatPrice(parent.find('.input-discount').val());
                let price = unformatPrice(parent.find('.input-product-price').val());
                let totalPrice = (price - discount) * qty;


                // cek kalo pake ppn tambahin 11% dari harga
                if (parent.find('.input-ppn').is(':checked')) totalPrice += totalPrice * 0.11;

                // set total price nya ke total price per product
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                parent.find('.input-product-total-price').val(customToFixed(totalPrice));

                initPriceFormat();
                setTotalPriceAccumulation();
            }

            // fungsi untuk hitung total akumulasi harga keseluruhan
            // fungsi ini akan dipanggil add product, hapus product, dan ketika fungsi setTotalPricePerProduct() dipanggil
            function setTotalPriceAccumulation() {
                let totalPrice = 0;

                // looping element total price per product, lalu di sum()
                $('.input-product-total-price').each(function(i) {
                    totalPrice += unformatPrice($(this).val());
                });

                // set total price nya ke total price keseluruhan
                totalPrice = totalPrice <= 0 ? 0 : totalPrice;
                $('#total-price-accumulation').val(customToFixed(totalPrice));

                initPriceFormat();
            }

            // ajax get product dengan promise
            function getProduct(productId, customerId = null) {
                return new Promise((resolve, reject) => {
                    $.get('{{ url('api/products/') }}/' + productId + '?customerId=' + customerId,
                        function(res) {
                            if (res) {
                                resolve(res);
                            } else {
                                reject(new Error('product not found'))
                            }
                        });
                });
            }

            // ajax get product uom dengan promise
            function getProductUom(productId, uomId, customerId = null) {
                return new Promise((resolve, reject) => {
                    $.get(`{{ url('api/products/get-price') }}/${productId}/${uomId}` + '?customerId=' +
                        customerId,
                        function(res) {
                            if (res) {
                                resolve(res);
                            } else {
                                reject(new Error('product uom not found'))
                            }
                        });
                });
            }
        });
    </script>
@endpush
