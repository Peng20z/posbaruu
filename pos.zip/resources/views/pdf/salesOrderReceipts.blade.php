<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Example 1</title>
    <style>
        @page {
            size: 8.27in 5.85in;
            /* margin: 0; */
        }

        body {
            height: 100%;
            width: 100%;
        }

        .clearfix:after {
            content: "";
            display: table;
            clear: both;
        }

        a {
            color: #5D6975;
            text-decoration: underline;
        }

        body {
            position: relative;
            /* width: 21cm;
            height: 29.7cm; */
            margin: 0 auto;
            color: #001028;
            background: #FFFFFF;
            font-family: Arial, sans-serif;
            font-size: 12px;
            font-family: Arial;
        }

        header {
            /* padding: 10px 0; */
            /* margin-bottom: 30px; */
        }

        #logo {
            text-align: center;
            /* margin-bottom: 10px; */
        }

        #logo img {
            width: 90px;
        }

        h1 {
            border-top: 1px solid #5D6975;
            border-bottom: 1px solid #5D6975;
            color: #5D6975;
            font-size: 2.4em;
            line-height: 1.4em;
            font-weight: normal;
            text-align: center;
            margin: 0 0 20px 0;
            background: url(dimension.png);
        }

        #project {
            float: left;
        }

        #project span {
            color: #5D6975;
            text-align: right;
            width: 52px;
            margin-right: 10px;
            display: inline-block;
            font-size: 0.8em;
        }

        #company {
            padding-right: 10px;
            float: right;
            text-align: left;
        }

        #company span {
            color: #5D6975;
            text-align: right;
            width: 52px;
            margin-right: 10px;
            display: inline-block;
            font-size: 0.8em;
        }

        #project div,
        #company div {
            white-space: nowrap;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border-spacing: 0;
            margin-bottom: 10px;
        }

        table tr:nth-child(2n-1) td {
            background: #F5F5F5;
        }

        table th,
        table td {
            text-align: center;
        }

        table th {
            padding: 5px 10px;
            color: #5D6975;
            border-bottom: 1px solid #C1CED9;
            white-space: nowrap;
            font-weight: normal;
        }

        table .center,
        table .desc {
            text-align: center;
        }

        table td {
            /* padding: 10px; */
            text-align: right;
        }

        table td.service,
        table td.desc {
            vertical-align: top;
        }

        table td.unit,
        table td.qty,
        table td.total {
            font-size: 1.2em;
        }

        table td.grand {
            border-top: 1px solid #5D6975;
            ;
        }

        #notices {
            padding-left: 10px;
        }

        #notices .notice {
            color: #5D6975;
            font-size: 1.2em;
            padding-left: 10px;
        }

        footer {
            color: #5D6975;
            width: 100%;
            height: 30px;
            position: absolute;
            bottom: 0;
            border-top: 1px solid #C1CED9;
            /* padding: 8px 0; */
            text-align: center;
        }
    </style>
</head>

<body>
    <header class="clearfix">
        <h1>INVOICE</h1>
        <div id="company" class="clearfix">
            <div><span>EMAIL</span><a
                    href="mailto:{{ $data['salesOrder']->customer?->email }}">{{ $data['salesOrder']->customer?->email }}</a>
            </div>
            <div><span>DATE</span> {{ $data['salesOrder']->transaction_datetime }}</div>
        </div>
        <div id="project">
            <div><span>CODE</span> {{ $data['salesOrder']->code }}</div>
            <div><span>CLIENT</span> {{ $data['salesOrder']->customer?->name }}</div>
            <div><span>ADDRESS</span> {{ $data['salesOrder']->customer?->address }}</div>
        </div>
    </header>
    <main>
        <table>
            <thead>
                <tr>
                    <th>NO</th>
                    <th>PRODUCT</th>
                    <th>QUANTITY</th>
                    <th>UOM</th>
                    <th>UNIT PRICE</th>
                    <th>DISCOUNT</th>
                    <th>TOTAL PRICE</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $no = 1;
                @endphp
                @foreach ($data['salesOrder']->details as $detail)
                    <tr>
                        <td>{{ $no++ }}.</td>
                        <td class="center">{{ $detail->product?->name }}</td>
                        <td class="center">{{ $detail->qty }}</td>
                        <td class="center">{{ $detail->uom?->name }}</td>
                        <td class="center">{{ rupiah($detail->unit_price, true) }}</td>
                        <td class="center">
                            {{ rupiah($detail->total_discount, true) }}
                        </td>
                        <td>{{ rupiah($detail->total_price, true) }}</td>
                    </tr>
                @endforeach
                <tr>
                    <td colspan="7" class="grand total">GRAND TOTAL</td>
                    <td class="grand total">{{ rupiah($data['salesOrder']->sub_total, true) }}</td>
                </tr>
            </tbody>
        </table>
        <div id="notices">
            <div>NOTICE:</div>
            <div class="notice"> {{ $data['salesOrder']->description }}</div>
        </div>
    </main>
    <footer>
        Invoice was created on a computer and is valid without the signature and seal.
    </footer>
</body>

</html>
