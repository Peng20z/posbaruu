<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Penjualan per Barang</title>
    <style>
        .page-break {
            page-break-after: always;
        }

        .border-bottom{
            border-bottom: 1px solid
        }

        .text-align-center {
            text-align: center;
        }
        .text-align-left {
            text-align: left;
        }
        .text-align-right {
            text-align: right !important;
        }

        .w-100{
            width: 100%;
        }

        .color-blue{
            color: blue;
        }

        .pl-10{
            padding-left: 10px;
        }
    </style>
</head>

<body>
    <div class="text-align-center">
        <h2>Apotik New Harapan</h2>
        <h1>Rincian Penjualan per Barang</h1>
        <h3>Dari {{ date('d M Y', strtotime($filter['start_date'])) .' ke '. date('d M Y', strtotime($filter['end_date'])) }}</h3>
    </div>
    <div>
        <table cellspacing="0" class="w-100">
            <thead>
                <tr>
                    <th class="color-blue">No. Faktur</th>
                    <th class="color-blue">Tgl. Faktur</th>
                    <th class="color-blue">Keterangan</th>
                    <th class="color-blue">Qty</th>
                    <th class="color-blue">Unit</th>
                    <th class="color-blue">Jumlah</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($products as $product)
                    <tr>
                        <th class="text-align-left">{{ $product->id }}</th>
                        <th class="text-align-left">{{ $product->name }}</th>
                        <th class="text-align-left"></th>
                        <th class="text-align-left"></th>
                        <th class="text-align-left"></th>
                        <th class="text-align-left"></th>
                    </tr>
                    @foreach ($product->salesOrderDetails as $salesOrderDetail)
                        <tr>
                            <td class="border-bottom"><span class="pl-10">{{ $salesOrderDetail->salesOrder->code }}</span></td>
                            <td class="border-bottom"><span class="pl-10">{{ date('d M Y', strtotime($salesOrderDetail->salesOrder->transaction_datetime)) }}</span></td>
                            <td class="border-bottom"><span class="pl-10">{{ $salesOrderDetail->salesOrder->description }}</span></td>
                            <td class="border-bottom"><span class="pl-10 text-align-center">{{ $salesOrderDetail->qty }}</span></td>
                            <td class="border-bottom"><span class="pl-10">{{ $salesOrderDetail->uom->name }}</span></td>
                            <td class="border-bottom"><span class="pl-10 text-align-center">{{ number_format($salesOrderDetail->total_price) }}</span></td>
                        </tr>
                    @endforeach
                    <tr>
                        <th colspan="3"></th>
                        <th><span class="pl-10 text-align-right">{{ $product->salesOrderDetails->sum('qty') }}</span></th>
                        <th></th>
                        <th><span class="pl-10 text-align-right">{{ number_format($product->salesOrderDetails->sum('total_price')) }}</span></th>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

</html>
