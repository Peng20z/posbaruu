<?php

namespace Database\Seeders;

use App\Enums\UserType;
use App\Models\CustomerGroup;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CustomerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $customerGroup = CustomerGroup::create([
        //     'id' => 1,
        //     'name' => 'Default',
        // ]);

        // $path = public_path('sql/customers.sql');
        // $sql = file_get_contents($path);
        // DB::unprepared($sql);
    }
}
