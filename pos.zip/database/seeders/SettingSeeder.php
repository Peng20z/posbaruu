<?php

namespace Database\Seeders;

use App\Enums\DatabaseConnection;
use App\Enums\SettingEnum;
use App\Models\Setting;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $databaseConnection = DatabaseConnection::MYSQL();
        $poFormat = sprintf($databaseConnection->getPoCodeFormat() . '001', date('d'), date('m'), date('y'));
        $roFormat = sprintf($databaseConnection->getRoCodeFormat() . '001', date('d'), date('m'), date('y'));
        $soFormat = sprintf($databaseConnection->getSoCodeFormat() . '001', date('d'), date('m'), date('y'));

        if (DB::getDefaultConnection() === DatabaseConnection::MYSQL_SECONDARY) {
            $databaseConnection = DatabaseConnection::MYSQL_SECONDARY();
            $poFormat = sprintf($databaseConnection->getPoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $roFormat = sprintf($databaseConnection->getRoCodeFormat() . '001', date('d'), date('m'), date('y'));
            $soFormat = sprintf($databaseConnection->getSoCodeFormat() . '001', date('d'), date('m'), date('y'));
        }

        Setting::create([
            'key' => SettingEnum::PO_NUMBER,
            'value' => $poFormat
        ]);

        Setting::create([
            'key' => SettingEnum::RO_NUMBER,
            'value' => $roFormat
        ]);

        Setting::create([
            'key' => SettingEnum::SO_NUMBER,
            'value' => $soFormat
        ]);

        Setting::create([
            'key' => SettingEnum::TAX_VALUE,
            'value' => 11
        ]);

        Setting::create([
            'key' => SettingEnum::IS_SKIP_RO,
            'value' => false
        ]);

        Setting::create([
            'key' => SettingEnum::STOCK_LESS_THAN_0,
            'value' => false
        ]);
    }
}
