<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\ProductUom;
use App\Models\Uom;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Product::create([
        //     'product_category_id' => 1,
        //     'product_brand_id' => 1,
        //     'name' => 'Product 1',
        //     'description' => 'Product description 1',
        // ]);

        for ($i = 1; $i < 6; $i++) {
            $buyPrice = $i * 1000;
            $sellPrice = $buyPrice * 2;
            $product = Product::create([
                'id' => 'PRO'.$i,
                'product_category_id' => 1,
                'product_brand_id' => 1,
                'default_uom_id' => 1,
                'base_uom_id' => 1,
                'name' => 'Product ' . $i,
                'description' => 'Product description ' . $i,
                'buy_price' => $buyPrice,
                'sell_price' => $sellPrice,
            ]);

            $product->stock()->increment('qty', 100);

            foreach (Uom::all() as $uom) {
                ProductUom::create([
                    'product_id' => $product->id,
                    'uom_id' => $uom->id,
                    'is_default' => ($uom->id == 1) ? true : false,
                    'is_base' => ($uom->id == 1) ? true : false,
                    'buy_price' => $product->buy_price,
                    'sell_price' => $product->sell_price,
                ]);
            }
        }
    }
}
