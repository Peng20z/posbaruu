<?php

namespace Database\Seeders;

use App\Enums\NormalBalance;
use App\Models\Coa;
use Illuminate\Database\Seeder;

class CoaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Coa::insert([
            [
                'account_number' => '1xxx',
                'account_name' => 'HARTA / KAS',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'account_number' => '2xxx',
                'account_name' => 'KEWAJIBAN / HUTANG',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'account_number' => '3xxx',
                'account_name' => 'MODAL / AKTIVA',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'account_number' => '4xxx',
                'account_name' => 'PENDAPATAN / PENERIMAAN',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'account_number' => '5xxx',
                'account_name' => 'BIAYA / BEBAN',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        // HARTA / KAS
        Coa::insert([
            [
                'parent_id' => 1,
                'account_number' => '1101.1001',
                'account_name' => 'Cash on Hand - IDR',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1002',
                'account_name' => 'Cash on Hand - USD',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1003',
                'account_name' => 'Cash on Hand - SGD',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1004',
                'account_name' => 'Cash on Hand - AUD',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1005',
                'account_name' => 'Cash on Hand - GBP',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1006',
                'account_name' => 'Cash on Hand - NZD',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1007',
                'account_name' => 'Cash on Hand - EUR',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1008',
                'account_name' => 'Cash on Hand - CAD',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1009',
                'account_name' => 'Cash on Hand - MYR',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.1010',
                'account_name' => 'Cash on Hand - CHF',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1101.2011',
                'account_name' => 'Petty Cash HO - IDR',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1102.1010',
                'account_name' => 'Bank BCA',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1102.1021',
                'account_name' => 'BCA 372.146.1678 - IDR',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1102.1032',
                'account_name' => 'BCA 372.303.3353.H - IDR',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 1,
                'account_number' => '1102.6011',
                'account_name' => 'Bank DBS 200016887 - IDR',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
        // HARTA / KAS

        // KEWAJIBAN / HUTANG
        Coa::insert([
            [
                'parent_id' => 2,
                'account_number' => '2001',
                'account_name' => 'Hutang Usaha',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
        // KEWAJIBAN / HUTANG

        // MODAL
        Coa::insert([
            [
                'parent_id' => 3,
                'account_number' => '3001',
                'account_name' => 'Modal Usaha',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
        // MODAL

        // PENDAPATAN
        Coa::insert([
            [
                'parent_id' => 4,
                'account_number' => '4102.0000',
                'account_name' => 'Courses Tuition',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '4302.0000',
                'account_name' => 'Supporting Fee',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1103.6001',
                'account_name' => 'Cash Advance - IDR',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1103.6002',
                'account_name' => 'Cash Advance - USD',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1103.6003',
                'account_name' => 'Cash Advance - SGD',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1103.6004',
                'account_name' => 'Cash Advance - AUD',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1103.6005',
                'account_name' => 'Cash Advance - GBP',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1103.6007',
                'account_name' => 'Cash Advance - CAD',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1103.7001',
                'account_name' => 'A/R Due To Employees - IDR',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '1306.9000',
                'account_name' => 'Fixed Assets Transaction',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '2103.1001',
                'account_name' => 'Customer Deposit',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 4,
                'account_number' => '2103.2001',
                'account_name' => 'Student Deposit',
                'normal_balance' => NormalBalance::CREDIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
        // PENDAPATAN

        // BEBAN / BIAYA
        Coa::insert([
            [
                'parent_id' => 5,
                'account_number' => '6104.0000',
                'account_name' => 'Recruitment Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6201.1000',
                'account_name' => 'Advertising Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6201.5000',
                'account_name' => 'Content Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6202.0000',
                'account_name' => 'Communication Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6202.3000',
                'account_name' => 'Staff Allowance Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6212.0020',
                'account_name' => 'Translation Fee',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6304.0000',
                'account_name' => 'Services Charges',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6303.0000',
                'account_name' => 'Water Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6301.0000',
                'account_name' => 'Electricity Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6305.0000',
                'account_name' => 'General Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6306.0000',
                'account_name' => 'Office Supplies Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6308.0000',
                'account_name' => 'Administration Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6310.0000',
                'account_name' => 'Courier Charges',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6311.0000',
                'account_name' => 'Transportation Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6312.0000',
                'account_name' => 'Business Trip Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6315.2000',
                'account_name' => 'Maintenance & Service Exp. for Building',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6315.3000',
                'account_name' => 'Maintenance & Service Exp. for Fixtures & Furnitures',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6315.4000',
                'account_name' => 'Maintenance & Service Exp. for Equipments',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6315.0000',
                'account_name' => 'Maintenance & Service Exp. for Vehicles',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6320.0000',
                'account_name' => 'Entertainment Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'parent_id' => 5,
                'account_number' => '6324.0000',
                'account_name' => 'IT Supplies Expenses',
                'normal_balance' => NormalBalance::DEBIT,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
        // BEBAN / BIAYA
    }
}
