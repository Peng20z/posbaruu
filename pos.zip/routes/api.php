<?php

use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ProductUomController;
use App\Http\Controllers\Api\PurchaseOrderController;
use App\Http\Controllers\Api\ReceiveOrderController;
use App\Http\Controllers\Api\SalesOrderController;
use App\Http\Controllers\Api\SupplierController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('suppliers', [SupplierController::class, 'index'])->name('suppliers.index');
Route::get('products', [ProductController::class, 'index'])->name('products.index');
Route::get('products/get-price/{productId}/{uomId}', [ProductController::class, 'getPrice'])->name('products.getPrice');
Route::get('products/get-price-by-db/{productId}/{uomId}', [ProductController::class, 'getPricebyDB'])->name('products.getPricebyDB');
Route::get('products/{product}', [ProductController::class, 'show'])->name('products.show');
Route::get('products/get-product-by-db/{product}', [ProductController::class, 'getProductbyDB'])->name('products.getProductbyDB');

Route::get('product-uoms/{product}/{uom}', [ProductUomController::class, 'getProductUom'])->name('product-uoms.get-product-uom');
Route::get('product-uoms/{product}', [ProductUomController::class, 'getProductUoms'])->name('product-uoms.get-product-uoms');

Route::get('purchase-orders/{purchaseOrder}', [PurchaseOrderController::class, 'show'])->name('purchase-orders.show');
Route::post('purchase-orders/get-unpaid', [PurchaseOrderController::class, 'getUnpaid'])->name('purchase-orders.get-unpaid');

Route::get('receive-orders/{receiveOrder}', [ReceiveOrderController::class, 'show'])->name('receive-orders.show');

Route::get('sales-orders/{salesOrder}', [SalesOrderController::class, 'show'])->name('sales-orders.show');
Route::post('sales-orders/get-unpaid', [SalesOrderController::class, 'getUnpaid'])->name('sales-orders.get-unpaid');
